package com.android.camera;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ProgressBar;

/* loaded from: classes.dex */
public class PanoramaWaitDlg extends Dialog {
    private Handler m_cHandler;
    private WaitDlgListener m_cListener;
    private PanoramaCollection m_cMosaic;
    private Runnable m_cPercentUpdate;
    private ProgressBar m_cProgressBar;

    /* loaded from: classes.dex */
    public interface WaitDlgListener {
        void OnUserCancel();
    }

    public PanoramaWaitDlg(Context context, PanoramaCollection cMosaic, WaitDlgListener cListener) {
        super(context, false, null);
        this.m_cMosaic = null;
        this.m_cHandler = new Handler();
        this.m_cListener = null;
        this.m_cProgressBar = null;
        this.m_cPercentUpdate = new Runnable() { // from class: com.android.camera.PanoramaWaitDlg.1
            @Override // java.lang.Runnable
            public void run() {
                PanoramaWaitDlg.this.m_cHandler.removeCallbacks(PanoramaWaitDlg.this.m_cPercentUpdate);
                int nPercent = PanoramaWaitDlg.this.m_cMosaic.ReportProgress();
                PanoramaWaitDlg.this.m_cProgressBar.setProgress(nPercent);
                PanoramaWaitDlg.this.m_cHandler.postDelayed(PanoramaWaitDlg.this.m_cPercentUpdate, 1000L);
            }
        };
        this.m_cMosaic = cMosaic;
        this.m_cListener = cListener;
    }

    @Override // android.app.Dialog
    protected void onStop() {
        super.onStop();
        this.m_cHandler.removeCallbacks(this.m_cPercentUpdate);
    }

    @Override // android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.panorama_progress);
        this.m_cProgressBar = (ProgressBar) findViewById(R.id.progressBarPanorama);
        setTitle(R.string.CreatePanorama);
        this.m_cHandler.removeCallbacks(this.m_cPercentUpdate);
        this.m_cHandler.postDelayed(this.m_cPercentUpdate, 1000L);
    }

    @Override // android.app.Dialog
    public void onBackPressed() {
    }

    public void CloseDialog() {
        if (isShowing()) {
            dismiss();
        }
    }
}