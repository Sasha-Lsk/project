package com.android.camera;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

/* loaded from: classes.dex */
public class EditCameraScriptDlg extends Dialog implements View.OnClickListener {
    private Context m_cContext;
    private EditText m_cEditCameraScript;
    private OnScriptChangedListener m_cListener;
    private String m_strScript;

    /* loaded from: classes.dex */
    public interface OnScriptChangedListener {
        void scriptChanged(String str);

        void scriptDefault(EditCameraScriptDlg editCameraScriptDlg);
    }

    public EditCameraScriptDlg(Context context, String strScript, OnScriptChangedListener cListener) {
        super(context);
        this.m_strScript = "";
        this.m_cListener = null;
        this.m_cContext = context;
        this.m_strScript = strScript;
        this.m_cListener = cListener;
    }

    @Override // android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editcamerascript);
        this.m_cEditCameraScript = (EditText) findViewById(R.id.editTextScript);
        findViewById(R.id.buttonDefault).setOnClickListener(this);
        findViewById(R.id.buttonApply).setOnClickListener(this);
        findViewById(R.id.buttonCancel).setOnClickListener(this);
        FillScript(this.m_strScript);
        setTitle(this.m_cContext.getResources().getString(R.string.SelectedFolder));
    }

    public void FillScript(String strScript) {
        String[] strArField = strScript.split(";");
        StringBuilder cBuilder = new StringBuilder();
        for (String str : strArField) {
            String strRow = str.trim();
            if (strRow.length() > 0) {
                cBuilder.append(strRow);
                cBuilder.append("\r\n");
            }
        }
        this.m_cEditCameraScript.setText(cBuilder.toString());
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.buttonCancel /* 2131230779 */:
                dismiss();
                return;
            case R.id.editTextScript /* 2131230780 */:
            default:
                return;
            case R.id.buttonDefault /* 2131230781 */:
                if (this.m_cListener != null) {
                    this.m_cListener.scriptDefault(this);
                    return;
                }
                return;
            case R.id.buttonApply /* 2131230782 */:
                if (this.m_cListener != null) {
                    this.m_cListener.scriptChanged(this.m_cEditCameraScript.getText().toString());
                }
                dismiss();
                return;
        }
    }
}