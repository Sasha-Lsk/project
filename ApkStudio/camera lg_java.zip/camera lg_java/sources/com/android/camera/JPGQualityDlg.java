package com.android.camera;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;

/* loaded from: classes.dex */
public class JPGQualityDlg extends Dialog implements SeekBar.OnSeekBarChangeListener, View.OnClickListener {
    private OnQualityChangedListener m_cListener;
    private SeekBar m_cSeekBar;
    private int m_nQuality;

    /* loaded from: classes.dex */
    public interface OnQualityChangedListener {
        void qualityChanged(int i);
    }

    public JPGQualityDlg(Context context, OnQualityChangedListener cListener, int nQuality) {
        super(context);
        this.m_cListener = null;
        this.m_nQuality = 100;
        this.m_cListener = cListener;
        this.m_nQuality = nQuality;
    }

    @Override // android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.JPEGQuality);
        setContentView(R.layout.jpg_quality);
        this.m_cSeekBar = (SeekBar) findViewById(R.id.SeekBarRed);
        this.m_cSeekBar.setProgress(this.m_nQuality);
        this.m_cSeekBar.setOnSeekBarChangeListener(this);
        findViewById(R.id.ButtonApply).setOnClickListener(this);
        findViewById(R.id.ButtonCancel).setOnClickListener(this);
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public void onProgressChanged(SeekBar arg0, int arg1, boolean arg2) {
        if (arg2) {
            this.m_nQuality = this.m_cSeekBar.getProgress();
        }
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public void onStartTrackingTouch(SeekBar arg0) {
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public void onStopTrackingTouch(SeekBar arg0) {
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View arg0) {
        switch (arg0.getId()) {
            case R.id.ButtonApply /* 2131230775 */:
                this.m_cListener.qualityChanged(this.m_nQuality);
                dismiss();
                return;
            case R.id.ButtonCancel /* 2131230776 */:
                dismiss();
                return;
            default:
                return;
        }
    }
}