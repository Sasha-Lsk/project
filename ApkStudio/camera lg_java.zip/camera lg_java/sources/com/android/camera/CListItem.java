package com.android.camera;

import android.text.format.Time;
import java.io.File;

/* loaded from: classes.dex */
public class CListItem {
    private String m_strFullFileName;
    private String m_strShortFileName;
    private String m_strTitle;

    public CListItem(String strFilePath) {
        int nIndex;
        try {
            Time cTime = new Time();
            this.m_strFullFileName = strFilePath;
            int nPos = strFilePath.lastIndexOf(47);
            if (nPos != -1) {
                this.m_strShortFileName = strFilePath.substring(nPos + 1);
            }
            String strShortName = this.m_strShortFileName;
            int nPos2 = strShortName.indexOf(46);
            String[] strFields = (nPos2 != -1 ? strShortName.substring(0, nPos2) : strShortName).split("_");
            try {
                if (strFields[0].length() != 0) {
                    nIndex = 0;
                } else {
                    int nIndex2 = 0 + 1;
                    nIndex = nIndex2;
                }
                int nIndex3 = nIndex + 1;
                int nYear = Integer.valueOf(strFields[nIndex]).intValue();
                int nIndex4 = strFields[nIndex3].length() == 0 ? nIndex3 + 1 : nIndex3;
                int nIndex5 = nIndex4 + 1;
                int nMonth = Integer.valueOf(strFields[nIndex4]).intValue();
                int nIndex6 = strFields[nIndex5].length() == 0 ? nIndex5 + 1 : nIndex5;
                int nIndex7 = nIndex6 + 1;
                int nDay = Integer.valueOf(strFields[nIndex6]).intValue();
                int nIndex8 = strFields[nIndex7].length() == 0 ? nIndex7 + 1 : nIndex7;
                int nIndex9 = nIndex8 + 1;
                int nHour = Integer.valueOf(strFields[nIndex8]).intValue();
                int nIndex10 = strFields[nIndex9].length() == 0 ? nIndex9 + 1 : nIndex9;
                int nIndex11 = nIndex10 + 1;
                int nMinute = Integer.valueOf(strFields[nIndex10]).intValue();
                int nIndex12 = strFields[nIndex11].length() == 0 ? nIndex11 + 1 : nIndex11;
                int nIndex13 = nIndex12 + 1;
                int nSecond = Integer.valueOf(strFields[nIndex12]).intValue();
                cTime.set(nSecond, nMinute, nHour, nDay, nMonth - 1, nYear);
            } catch (Exception e) {
                File cFile = new File(strFilePath);
                cTime.set(cFile.lastModified());
            }
            this.m_strTitle = String.format("%d/%02d/%02d %02d:%02d:%02d", Integer.valueOf(cTime.year), Integer.valueOf(cTime.month + 1), Integer.valueOf(cTime.monthDay), Integer.valueOf(cTime.hour), Integer.valueOf(cTime.minute), Integer.valueOf(cTime.second));
        } catch (Exception e2) {
        }
    }

    public String getFullFileName() {
        return this.m_strFullFileName;
    }

    public String getShortFileName() {
        return this.m_strShortFileName;
    }

    public String getTitle() {
        return this.m_strTitle;
    }

    public String toString() {
        return getTitle();
    }
}