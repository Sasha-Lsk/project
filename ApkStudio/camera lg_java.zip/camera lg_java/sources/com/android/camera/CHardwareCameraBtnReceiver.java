package com.android.camera;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/* loaded from: classes.dex */
public class CHardwareCameraBtnReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equalsIgnoreCase("android.intent.action.CAMERA_BUTTON")) {
            SharedPreferences cPrefs = context.getSharedPreferences("Common", 0);
            if (cPrefs.getBoolean("Run on camera button pressed", true)) {
                Intent cNewIntent = new Intent();
                cNewIntent.setClass(context, MainWindow.class);
                cNewIntent.setFlags(268435456);
                context.startActivity(cNewIntent);
                abortBroadcast();
            }
        }
    }
}