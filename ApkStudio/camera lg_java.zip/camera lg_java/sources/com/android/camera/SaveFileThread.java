package com.android.camera;

import android.content.ContentResolver;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;
import java.io.File;
import java.io.IOException;
import java.util.Vector;

/* loaded from: classes.dex */
public class SaveFileThread extends Thread {
    private CameraView m_cCameraView;
    private SaveFileListener m_cListenter;
    private boolean m_bExit = false;
    private Vector<JPEGData> m_cArJPEG = new Vector<>();
    private Vector<String> m_strArDelete = new Vector<>();
    private String m_strLastFileName = "";
    private Object m_oSemaphore = new Object();

    /* loaded from: classes.dex */
    public interface SaveFileListener {
        void onFileSaved(String str, boolean z);
    }

    public synchronized void DeleteLastFile() {
        DeleteFile(this.m_strLastFileName);
    }

    public synchronized void DeleteFile(String strFileName) {
        File cFile = new File(strFileName);
        if (cFile.exists()) {
            try {
                delete(this.m_cCameraView.m_cMainWnd.getContentResolver(), strFileName);
            } catch (Exception e) {
            }
        } else if (this.m_strArDelete.indexOf(strFileName) == -1) {
            this.m_strArDelete.add(strFileName);
        }
    }

    public SaveFileThread(CameraView cCameraView, SaveFileListener cListenter) {
        this.m_cCameraView = null;
        this.m_cListenter = null;
        this.m_cCameraView = cCameraView;
        this.m_cListenter = cListenter;
    }

    public synchronized int getCount() {
        return this.m_cArJPEG.size();
    }

    public void Exit() {
        this.m_bExit = true;
        synchronized (this.m_oSemaphore) {
            this.m_oSemaphore.notify();
        }
    }

    public void AddJPEGData(JPEGData cData) {
        this.m_strLastFileName = cData.m_strFileName;
        this.m_cArJPEG.add(cData);
        synchronized (this.m_oSemaphore) {
            this.m_oSemaphore.notify();
        }
    }

    public static void delete(ContentResolver cResolver, String strFileName) throws IOException {
        String strShortFileName;
        int nPos;
        int nPos2 = strFileName.lastIndexOf(47);
        if (nPos2 != -1 && (nPos = (strShortFileName = strFileName.substring(nPos2 + 1)).lastIndexOf(46)) != -1) {
            String strExt = strShortFileName.substring(nPos + 1);
            if (strExt.equalsIgnoreCase("jpg")) {
                Uri videoTable = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                String[] selectionArgs = {strFileName};
                cResolver.delete(videoTable, "_data=?", selectionArgs);
                return;
            }
            Uri videoTable2 = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
            String[] selectionArgs2 = {strFileName};
            cResolver.delete(videoTable2, "_data=?", selectionArgs2);
        }
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        while (!this.m_bExit) {
            while (this.m_cArJPEG.size() > 0) {
                try {
                    JPEGData cData = this.m_cArJPEG.get(0);
                    cData.m_cCameraView = this.m_cCameraView;
                    int nIndex = this.m_strArDelete.indexOf(cData.m_strFileName);
                    if (nIndex >= 0) {
                        this.m_strArDelete.remove(nIndex);
                        this.m_cArJPEG.remove(0);
                        this.m_cListenter.onFileSaved(cData.m_strFileName, false);
                    } else {
                        cData.SaveJPEG();
                        this.m_cArJPEG.remove(0);
                        if (this.m_cListenter != null) {
                            Log.e("SaveFileThread", String.format("onFileSaved, files to save %d", Integer.valueOf(this.m_cArJPEG.size())));
                            this.m_cListenter.onFileSaved(cData.m_strFileName, true);
                        }
                    }
                } catch (Exception ex) {
                    Log.e("SaveFileThread", "Error in onFileSaved " + ex.getMessage());
                }
            }
            int n = 0;
            while (n < this.m_strArDelete.size()) {
                File cFile = new File(this.m_strArDelete.get(n));
                if (cFile.exists()) {
                    try {
                        delete(this.m_cCameraView.m_cMainWnd.getContentResolver(), this.m_strArDelete.get(n));
                    } catch (Exception e) {
                    }
                    this.m_strArDelete.remove(n);
                    n--;
                }
                n++;
            }
            synchronized (this.m_oSemaphore) {
                this.m_oSemaphore.wait();
            }
        }
    }
}