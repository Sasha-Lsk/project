package com.android.camera;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import rubberbigpepper.CommonCtrl.DebugLog;
import rubberbigpepper.CommonCtrl.InvokeHelper;

/* loaded from: classes.dex */
public class SendLogDlg extends Dialog implements View.OnClickListener {
    private Context m_cContext;
    private EditText m_cEditText;

    public SendLogDlg(Context context) {
        super(context);
        this.m_cContext = null;
        this.m_cEditText = null;
        this.m_cContext = context;
    }

    @Override // android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.Describe);
        setContentView(R.layout.sendlog);
        this.m_cEditText = (EditText) findViewById(R.id.editTextProblem);
        findViewById(R.id.buttonSend).setOnClickListener(this);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View arg0) {
        if (arg0.getId() == R.id.buttonSend) {
            SendEmailToDeveloper();
            dismiss();
        }
    }

    private void SendEmailToDeveloper() {
        try {
            Intent sendIntent = new Intent("android.intent.action.SEND");
            sendIntent.putExtra("android.intent.extra.EMAIL", new String[]{"RubberBigPepper@gmail.com"});
            sendIntent.putExtra("android.intent.extra.SUBJECT", "lgCamera.log");
            StringBuilder cBuilder = new StringBuilder();
            cBuilder.append(this.m_cEditText.getText().toString());
            cBuilder.append("\r\n");
            PackageInfo cPackInfo = this.m_cContext.getPackageManager().getPackageInfo(this.m_cContext.getPackageName(), 64);
            cBuilder.append(this.m_cContext.getResources().getString(R.string.Version));
            cBuilder.append(cPackInfo.versionName);
            cBuilder.append("\r\n");
            cBuilder.append(this.m_cContext.getResources().getString(R.string.VersionCode));
            cBuilder.append(cPackInfo.versionCode);
            cBuilder.append("\r\n");
            cBuilder.append("Android: ");
            cBuilder.append(String.valueOf(InvokeHelper.GetStaticFieldValue(Build.VERSION.class, "SDK_INT")));
            cBuilder.append("\r\n");
            cBuilder.append("Manufacturer: ");
            cBuilder.append(String.valueOf(InvokeHelper.GetStaticFieldValue(Build.class, "MANUFACTURER")));
            cBuilder.append("\r\n");
            cBuilder.append("Model: ");
            cBuilder.append(String.valueOf(InvokeHelper.GetStaticFieldValue(Build.class, "MODEL")));
            sendIntent.putExtra("android.intent.extra.TEXT", cBuilder.toString());
            sendIntent.putExtra("android.intent.extra.STREAM", Uri.parse("file://" + DebugLog.m_strFileName));
            sendIntent.setType("text/plain");
            this.m_cContext.startActivity(Intent.createChooser(sendIntent, "lgCamera.log"));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}