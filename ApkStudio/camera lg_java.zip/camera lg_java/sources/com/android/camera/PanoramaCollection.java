package com.android.camera;

import android.graphics.YuvImage;
import android.os.AsyncTask;
import android.util.Log;
import rubberbigpepper.CommonCtrl.Panorama;

/* loaded from: classes.dex */
public class PanoramaCollection {
    private static final int FRAME_COUNT_INDEX = 9;
    private static final int HR_TO_LR_DOWNSAMPLE_FACTOR = 4;
    private static final int MOSAIC_RET_CODE_INDEX = 10;
    private static final int NUM_FRAMES_IN_BUFFER = 2;
    private static final int WINDOW_SIZE = 3;
    private static final int X_COORD_INDEX = 2;
    private static final int Y_COORD_INDEX = 5;
    private float mPanningRateX;
    private float mPanningRateY;
    private int mPreviewHeight;
    private int mPreviewWidth;
    private float mTranslationLastX;
    private float mTranslationLastY;
    private Panorama m_cMosaic = new Panorama();
    private float m_fAllAngle = 0.0f;
    private float m_fMaxAngleSpeed = 25.0f;
    private int m_nMode = 0;
    private float m_fEndAllAngle = 320.0f;
    private int MAX_NUMBER_OF_FRAMES = 200;
    private final long[] mFrameTimestamp = new long[2];
    private int mFillIn = 0;
    private int mTotalFrameCount = 0;
    private long mLastProcessedFrameTimestamp = 0;
    private int mLastProcessFrameIdx = -1;
    private int mCurrProcessFrameIdx = -1;
    private float[] mDeltaX = new float[3];
    private float[] mDeltaY = new float[3];
    private float[] mDeltaTime = new float[3];
    private int mOldestIdx = 0;
    private float mTotalTranslationX = 0.0f;
    private float mTotalTranslationY = 0.0f;
    private float mTotalDeltaTime = 0.0f;
    private float mHorizontalViewAngle = 60.0f;
    private float mVerticalViewAngle = 50.0f;
    private int m_nOrientation = 0;
    private PanoramaListener m_cListener = null;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public interface PanoramaListener {
        void OnPanoModeChanged(int i, int i2);

        void OnPanoramaCanceled();

        void OnPanoramaError(int i);

        void OnPanoramaReady(YuvImage yuvImage);

        void OnTooFast();
    }

    public void SetPanoramaListener(PanoramaListener cListener) {
        this.m_cListener = cListener;
    }

    public int GetMode() {
        return this.m_nMode;
    }

    public float getProgressAngle() {
        float fProgress = (this.m_fEndAllAngle * this.mTotalFrameCount) / this.MAX_NUMBER_OF_FRAMES;
        return Math.min(this.m_fEndAllAngle, Math.max(this.m_fAllAngle, fProgress));
    }

    public void Clear() {
        this.m_cMosaic.freeMosaicMemory();
        this.m_cMosaic.reset();
        this.m_nMode = 0;
    }

    public void InitPanorama(int nWidth, int nHeight, int nOrientation, boolean bFullSweep) {
        Log.e("lgCamera", "Panorama init, mode=" + this.m_nMode + ", width=" + nWidth + ", height=" + nHeight);
        if (this.m_nMode == 0) {
            if (bFullSweep) {
                this.MAX_NUMBER_OF_FRAMES = 200;
            } else {
                this.MAX_NUMBER_OF_FRAMES = 130;
            }
            this.m_nOrientation = nOrientation;
            this.mPreviewWidth = nWidth;
            this.mPreviewHeight = nHeight;
            this.m_nMode = 1;
            this.m_cMosaic.allocateMosaicMemory(nWidth, nHeight);
            Log.e("lgCamera", "memory allocated");
            this.m_cMosaic.reset();
            this.m_cMosaic.setStripType(1);
            this.mFillIn = 0;
            this.mTotalFrameCount = 0;
            this.mLastProcessedFrameTimestamp = 0L;
            this.mLastProcessFrameIdx = -1;
            this.mCurrProcessFrameIdx = -1;
            this.mOldestIdx = 0;
            this.mTotalTranslationX = 0.0f;
            this.mTotalTranslationY = 0.0f;
            this.mTotalDeltaTime = 0.0f;
            if (this.m_cListener != null) {
                this.m_cListener.OnPanoModeChanged(this.m_nMode, 0);
            }
        }
    }

    public void CancelPanorama() {
        if (this.m_nMode != 2) {
            int nOldMode = this.m_nMode;
            if (this.m_nMode == 1) {
                Clear();
            }
            if (this.m_cListener != null) {
                this.m_cListener.OnPanoModeChanged(this.m_nMode, nOldMode);
                return;
            }
            return;
        }
        this.m_cMosaic.reportProgress(true, true);
    }

    public int ReportProgress() {
        if (this.m_nMode == 2) {
            return this.m_cMosaic.reportProgress(true, false);
        }
        return 0;
    }

    private float GetDiffBetweenAngles(float fAngle1, float fAngle2) {
        while (fAngle1 < 0.0f) {
            fAngle1 += 360.0f;
        }
        while (fAngle1 >= 360.0f) {
            fAngle1 -= 360.0f;
        }
        while (fAngle2 < 0.0f) {
            fAngle2 += 360.0f;
        }
        while (fAngle2 >= 360.0f) {
            fAngle2 -= 360.0f;
        }
        float fDiff1 = fAngle1 - fAngle2;
        if (fDiff1 < 0.0f) {
            fDiff1 += 360.0f;
        }
        if (fDiff1 >= 360.0f) {
            fDiff1 -= 360.0f;
        }
        float fDiff2 = fAngle2 - fAngle1;
        if (fDiff2 < 0.0f) {
            fDiff2 += 360.0f;
        }
        if (fDiff2 >= 360.0f) {
            fDiff2 -= 360.0f;
        }
        return fDiff1 < fDiff2 ? fDiff1 : fDiff2;
    }

    public void CreatePanoImmedialety() {
        Log.e("lgCamera", "Creating panorama");
        new PanoramaMakeTask(this, null).execute(new Void[0]);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public class PanoramaMakeTask extends AsyncTask<Void, Void, Integer> {
        private int m_nRes;

        private PanoramaMakeTask() {
            this.m_nRes = 0;
        }

        /* synthetic */ PanoramaMakeTask(PanoramaCollection panoramaCollection, PanoramaMakeTask panoramaMakeTask) {
            this();
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            int nOldMode = PanoramaCollection.this.m_nMode;
            PanoramaCollection.this.m_nMode = 2;
            if (PanoramaCollection.this.m_cListener != null) {
                PanoramaCollection.this.m_cListener.OnPanoModeChanged(PanoramaCollection.this.m_nMode, nOldMode);
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Integer doInBackground(Void... params) {
            this.m_nRes = PanoramaCollection.this.m_cMosaic.createMosaic(true);
            Log.e("lgCamera", "createMosaic=" + this.m_nRes);
            return Integer.valueOf(this.m_nRes);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Integer result) {
            YuvImage yuvimage;
            int nOldMode = PanoramaCollection.this.m_nMode;
            PanoramaCollection.this.m_nMode = 0;
            if (PanoramaCollection.this.m_cListener != null) {
                PanoramaCollection.this.m_cListener.OnPanoModeChanged(PanoramaCollection.this.m_nMode, nOldMode);
                if (this.m_nRes == 1) {
                    try {
                        byte[] imageData = PanoramaCollection.this.m_cMosaic.getFinalMosaicNV21();
                        if (imageData == null) {
                            PanoramaCollection.this.m_cListener.OnPanoramaError(-5);
                            Log.e("lgCamera", "getFinalMosaicNV21() returned null.");
                            PanoramaCollection.this.Clear();
                            return;
                        }
                        int len = imageData.length - 8;
                        Log.e("lgCamera", "imageData leng=" + len);
                        int width = (imageData[len + 0] << 24) + ((imageData[len + 1] & 255) << 16) + ((imageData[len + 2] & 255) << 8) + (imageData[len + 3] & 255);
                        int height = (imageData[len + 4] << 24) + ((imageData[len + 5] & 255) << 16) + ((imageData[len + 6] & 255) << 8) + (imageData[len + 7] & 255);
                        Log.e("lgCamera", "ImLength = " + len + ", W = " + width + ", H = " + height);
                        if (width > 0 && height > 0) {
                            if (PanoramaCollection.this.m_nOrientation % 2 == 0) {
                                PanoramaCollection.this.m_cMosaic.RotateYUV420Degree90(imageData, width, height);
                                yuvimage = new YuvImage(imageData, 17, height, width, null);
                            } else {
                                yuvimage = new YuvImage(imageData, 17, width, height, null);
                            }
                            PanoramaCollection.this.m_cListener.OnPanoramaReady(yuvimage);
                        } else {
                            Log.e("lgCamera", "width|height <= 0!!, len = " + len + ", W = " + width + ", H = " + height);
                            PanoramaCollection.this.m_cListener.OnPanoramaError(-5);
                            PanoramaCollection.this.Clear();
                            return;
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        PanoramaCollection.this.m_cListener.OnPanoramaError(-4);
                    }
                } else if (this.m_nRes == -2) {
                    PanoramaCollection.this.m_cListener.OnPanoramaCanceled();
                } else {
                    PanoramaCollection.this.m_cListener.OnPanoramaError(this.m_nRes);
                }
            }
            PanoramaCollection.this.Clear();
        }
    }

    public void onPreviewFrame(byte[] data, float fAngle) {
        if (this.m_nMode == 1) {
            long t1 = System.currentTimeMillis();
            this.mFrameTimestamp[this.mFillIn] = t1;
            this.mCurrProcessFrameIdx = this.mFillIn;
            this.mFillIn = (this.mFillIn + 1) % 2;
            if (this.mCurrProcessFrameIdx != this.mLastProcessFrameIdx) {
                this.mLastProcessFrameIdx = this.mCurrProcessFrameIdx;
                long timestamp = this.mFrameTimestamp[this.mCurrProcessFrameIdx];
                if (this.mTotalFrameCount < this.MAX_NUMBER_OF_FRAMES) {
                    calculateTranslationRate(data, timestamp);
                    float fProgressX = ((this.mHorizontalViewAngle * this.mTranslationLastX) * 4.0f) / this.mPreviewWidth;
                    float fProgressY = ((this.mVerticalViewAngle * this.mTranslationLastY) * 4.0f) / this.mPreviewHeight;
                    this.m_fAllAngle = Math.max(fProgressX, fProgressY);
                    if (this.m_fAllAngle >= this.m_fEndAllAngle) {
                        StopCapture();
                        return;
                    }
                    float panningRateXInDegree = this.mPanningRateX * this.mHorizontalViewAngle;
                    float panningRateYInDegree = this.mPanningRateY * this.mVerticalViewAngle;
                    if ((Math.abs(panningRateXInDegree) > this.m_fMaxAngleSpeed || Math.abs(panningRateYInDegree) > this.m_fMaxAngleSpeed) && this.m_cListener != null) {
                        this.m_cListener.OnTooFast();
                        return;
                    }
                    return;
                }
                StopCapture();
            }
        }
    }

    private void StopCapture() {
        Log.e("lgCamera", "Creating panorama");
        new PanoramaMakeTask(this, null).execute(new Void[0]);
    }

    public void calculateTranslationRate(byte[] byArFrame, long now) {
        float[] frameData = this.m_cMosaic.setSourceImage(byArFrame);
        int ret_code = (int) frameData[10];
        this.mTotalFrameCount = (int) frameData[9];
        Log.e("lgCamera", "Total frame captured: " + this.mTotalFrameCount + ", ret code=" + ret_code);
        float translationCurrX = frameData[2];
        float translationCurrY = frameData[5];
        if (((float) this.mLastProcessedFrameTimestamp) == 0.0f) {
            this.mTranslationLastX = translationCurrX;
            this.mTranslationLastY = translationCurrY;
            this.mLastProcessedFrameTimestamp = now;
            return;
        }
        int idx = this.mOldestIdx;
        this.mTotalTranslationX -= this.mDeltaX[idx];
        this.mTotalTranslationY -= this.mDeltaY[idx];
        this.mTotalDeltaTime -= this.mDeltaTime[idx];
        this.mDeltaX[idx] = Math.abs(translationCurrX - this.mTranslationLastX);
        this.mDeltaY[idx] = Math.abs(translationCurrY - this.mTranslationLastY);
        this.mDeltaTime[idx] = ((float) (now - this.mLastProcessedFrameTimestamp)) / 1000.0f;
        this.mTotalTranslationX += this.mDeltaX[idx];
        this.mTotalTranslationY += this.mDeltaY[idx];
        this.mTotalDeltaTime += this.mDeltaTime[idx];
        this.mPanningRateX = (this.mTotalTranslationX / (this.mPreviewWidth / 4)) / this.mTotalDeltaTime;
        this.mPanningRateY = (this.mTotalTranslationY / (this.mPreviewHeight / 4)) / this.mTotalDeltaTime;
        this.mTranslationLastX = translationCurrX;
        this.mTranslationLastY = translationCurrY;
        this.mLastProcessedFrameTimestamp = now;
        this.mOldestIdx = (this.mOldestIdx + 1) % 3;
    }
}