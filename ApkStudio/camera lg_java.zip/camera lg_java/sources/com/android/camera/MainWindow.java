package com.android.camera;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.UriPermission;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaMetadataRetriever;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Process;
import android.os.SystemClock;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.OrientationEventListener;
import android.view.SurfaceView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.android.camera.EditCameraScriptDlg;
import com.android.camera.JPGQualityDlg;
import com.android.camera.OverlaySettingsDlg;
import com.android.camera.SelectFolderDialog;
import com.android.vending.licensing.AESObfuscator;
import com.android.vending.licensing.LicenseChecker;
import com.android.vending.licensing.LicenseCheckerCallback;
import com.android.vending.licensing.ServerManagedPolicy;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import java.io.File;
import java.io.FilenameFilter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;
import rubberbigpepper.CommonCtrl.BitrateSampleRateHelper;
import rubberbigpepper.CommonCtrl.CGridView;
import rubberbigpepper.CommonCtrl.DebugLog;
import rubberbigpepper.CommonCtrl.InvokeHelper;
import rubberbigpepper.CommonCtrl.Panorama;
import rubberbigpepper.CommonCtrl.SecCameraWrapper;
import rubberbigpepper.CommonCtrl.ZoomView;

/* loaded from: classes.dex */
public class MainWindow extends Activity implements View.OnClickListener, View.OnLongClickListener, LocationListener, CompoundButton.OnCheckedChangeListener, ZoomView.OnZoomViewValueChanged, CGridView.OnZeroAccelValue, CGridView.GridViewListener {
    private static final int ACCESS_REQUEST_CODE = 4543;
    private static final String BASE64_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAm2X9mHv32Gqr/E7ZO1X3UuHWkniNC6lec17QOlEoyVcCty8MbfqXITfGEpj/IV9HY76NNpno5QlTDAeLByHv2WXAeZqCCoKUjFpyIRmA8jhkT799E2K8p2aZ02MDTMpMkkVratnEyS0zYKkvUZkLLmra94ABcLTZHqcJ03TvLqVeAQy/u9HvaVu2G772Lm0aHbfnEcfKnVfh+b32qEqPkCU9x1r+j3s+SRD1CSpF0d4/4Bexj24QS3ZZLV11XZ7zGrt6UtHTbzq/NftB3jswtB87dU7+Nqz5aW+1X/SGRsGJnu3UNf7DxKH5xLmfmmxMsfkdRY+yFx/PhOO/NZDYXwIDAQAB";
    private AdView adView;
    private LicenseChecker mChecker;
    private LicenseCheckerCallback mLicenseCheckerCallback;
    private LinearLayout m_btnAB;
    private ImageButton m_btnAELock;
    private ImageButton m_btnAFReset;
    private ImageButton m_btnAllSettings;
    private LinearLayout m_btnAudioBitRate;
    private LinearLayout m_btnAudioEncoder;
    private LinearLayout m_btnAudioSampleRate;
    private LinearLayout m_btnAudioSource;
    private LinearLayout m_btnAutoExposure;
    private LinearLayout m_btnAutoShutter;
    private LinearLayout m_btnBrightness;
    private LinearLayout m_btnCE;
    private View m_btnCameraScript;
    private ImageButton m_btnCameraSettings;
    private ImageButton m_btnCapture;
    private ImageButton m_btnCommonSettings;
    private LinearLayout m_btnContrast;
    private ImageView m_btnDelete;
    private LinearLayout m_btnExposure;
    private LinearLayout m_btnFileNaming;
    private ImageButton m_btnFlashMode;
    private LinearLayout m_btnFocus;
    private LinearLayout m_btnFocusButton;
    private LinearLayout m_btnFolderSave;
    private View m_btnGallery;
    private ImageButton m_btnGalleryInternal;
    private LinearLayout m_btnISO;
    private LinearLayout m_btnJPGQuality;
    private ImageView m_btnNormalScreen;
    private ImageButton m_btnPauseResume;
    private LinearLayout m_btnPhotoInVideoRes;
    private LinearLayout m_btnPhotoInVideoResFront;
    private LinearLayout m_btnPhotoMode;
    private LinearLayout m_btnPhotoRes;
    private LinearLayout m_btnPhotoResFront;
    private ImageButton m_btnPhotoSettings;
    private ImageButton m_btnPlay;
    private LinearLayout m_btnPreviewTime;
    private ImageButton m_btnRecord;
    private LinearLayout m_btnRegInfo;
    private LinearLayout m_btnSM;
    private LinearLayout m_btnSaturation;
    private LinearLayout m_btnSharpness;
    private LinearLayout m_btnShutterButton;
    private LinearLayout m_btnSlowMotion;
    private ImageButton m_btnSwitchCamera;
    private TextView m_btnThanks;
    private LinearLayout m_btnVideoBitRate;
    private LinearLayout m_btnVideoEncoder;
    private LinearLayout m_btnVideoFPS;
    private LinearLayout m_btnVideoFormat;
    private LinearLayout m_btnVideoRes;
    private LinearLayout m_btnVideoResFront;
    private ImageButton m_btnVideoSettings;
    private LinearLayout m_btnWB;
    private ImageButton m_btnWBLock;
    private ProgressBar m_cBusyIndicator;
    private SurfaceView m_cCameraPreview;
    private CameraView m_cCameraView;
    private CheckBox m_cCheckBoxAGCOff;
    private CheckBox m_cCheckBoxAntiShake;
    private CheckBox m_cCheckBoxAutoRotate;
    private CheckBox m_cCheckBoxAutoStartNew;
    private CheckBox m_cCheckBoxDateTime;
    private CheckBox m_cCheckBoxDelayedSave;
    private CheckBox m_cCheckBoxEXIF;
    private CheckBox m_cCheckBoxFlashOnFocus;
    private CheckBox m_cCheckBoxForcedAF;
    private CheckBox m_cCheckBoxFullAngle;
    private CheckBox m_cCheckBoxLongClickShutter;
    private CheckBox m_cCheckBoxMTKDevice;
    private CheckBox m_cCheckBoxMaxBrightness;
    private CheckBox m_cCheckBoxRestartCamera;
    private CheckBox m_cCheckBoxRunOnCameraButton;
    private CheckBox m_cCheckBoxSaveDebugLog;
    private CheckBox m_cCheckBoxSensorFocus;
    private CheckBox m_cCheckBoxShowGrid;
    private CheckBox m_cCheckBoxShowStatus;
    private CheckBox m_cCheckBoxStereoSound;
    private CheckBox m_cCheckBoxTurnOffSounds;
    private CheckBox m_cCheckBoxUseSEC;
    private CheckBox m_cCheckBoxVibrate;
    private CheckBox m_cCheckBoxVideoStab;
    private ImageView m_cIVPreview;
    private ImageView m_cImageViewAntiShake;
    private View m_cLinearFullAngle;
    private ListView m_cListViewParams;
    private View m_cListViewParamsWnd;
    private TextView m_cTextViewAudioBitRate;
    private TextView m_cTextViewAudioEncoder;
    private TextView m_cTextViewDelayCount;
    private TextView m_cTextViewFPS;
    private TextView m_cTextViewFormat;
    private TextView m_cTextViewListParamsTitle;
    private TextView m_cTextViewMaxDelayCount;
    protected TextView m_cTextViewPanoMess;
    private TextView m_cTextViewRecord;
    private TextView m_cTextViewResHeight;
    private TextView m_cTextViewResWidth;
    private TextView m_cTextViewVideoBitRate;
    private TextView m_cTextViewVideoEncoder;
    private View m_cViewCameraContainer;
    private View m_cViewFrameCameraSettings;
    private View m_cViewIncludeCameraSettings;
    private View m_cViewMainButtonsInternal;
    private View m_cViewMainPreviewContainer;
    private View m_cViewPreviewButtons;
    private View m_cViewStatus;
    private ZoomView m_cZoomProgress;
    private int m_nTimeRecord;
    private View m_viewCameraSettingTab;
    private View m_viewCommonSettingTab;
    private View m_viewPhotoSettingTab;
    private LinearLayout m_viewUseSEC;
    private View m_viewVideoSettingTab;
    private static final byte[] SALT = {23, 43, 90, 92, 122, -12, -65, 59, 67, 61, -70, -126, 14, 88, 57, 18, -83, 118, -73, 54};
    public static String CAMERA_IMAGE_BUCKET_NAME = String.valueOf(Environment.getExternalStorageDirectory().toString()) + "/DCIM/Camera";
    public static CameraView g_cCameraView = null;
    private Timer m_cTimerRec = new Timer();
    public Handler m_cHandler = new Handler();
    private boolean m_bAutoShutter = false;
    private int m_nSecondsToShut = 0;
    private SoundPool m_cSoundPool = new SoundPool(10, 3, 0);
    private int m_nSoundID = -1;
    private float m_fVolume = 0.0f;
    private float m_fRate = 1.0f;
    private LocationManager m_cLocManager = null;
    public int m_nLastOrientation = 0;
    private MyOrientationEventListener m_cOrientListener = null;
    private boolean m_bFlagRecordImage = false;
    private float m_fBrightness = 1.0f;
    private boolean m_bAntiShake = false;
    private boolean m_bUseAntiShake = false;
    private boolean m_bPreviewMode = false;
    protected Point m_ptPreviewSize = new Point(0, 0);
    private Vibrator m_cVibrator = null;
    private long m_lLastBackPressTime = 0;
    public boolean m_bIndexInGallery = true;
    private String m_strLastFile = "";
    public Bitmap m_cBmpSmalPostView = null;
    private int m_nAutoTimerSeconds = 15;
    protected boolean m_bImageCaptureIntent = false;
    protected Uri m_cUriSaveImage = null;
    protected Uri m_cUriSaveVideo = null;
    protected boolean m_bVideoCaptureIntent = false;
    private Runnable m_cHideFocusRect = new Runnable() { // from class: com.android.camera.MainWindow.1
        @Override // java.lang.Runnable
        public void run() {
            MainWindow.this.m_cCameraView.m_cGridView.setShowFocus(0);
        }
    };
    private Runnable m_cShowNormalScreen = new Runnable() { // from class: com.android.camera.MainWindow.2
        @Override // java.lang.Runnable
        public void run() {
            MainWindow.this.ShowNormalScreen();
        }
    };
    private Runnable m_cUpdateScreen = new Runnable() { // from class: com.android.camera.MainWindow.3
        @Override // java.lang.Runnable
        public void run() {
            MainWindow.this.AdjustAspectRatio();
        }
    };
    private Runnable m_cUpdateAutoShutTimeUI = new Runnable() { // from class: com.android.camera.MainWindow.4
        @Override // java.lang.Runnable
        public void run() {
            MainWindow.this.m_cSoundPool.stop(MainWindow.this.m_nSoundID);
            MainWindow.this.m_cHandler.removeCallbacks(MainWindow.this.m_cUpdateAutoShutTimeUI);
            MainWindow mainWindow = MainWindow.this;
            mainWindow.m_nSecondsToShut--;
            if (MainWindow.this.m_nSecondsToShut <= 0) {
                MainWindow.this.m_cCameraView.CapturePhoto(false);
                return;
            }
            int nSoundCount = (int) (7.0d * Math.pow(MainWindow.this.m_nSecondsToShut, -0.7185999751091003d));
            MainWindow.this.m_cSoundPool.play(MainWindow.this.m_nSoundID, MainWindow.this.m_fVolume, MainWindow.this.m_fVolume, 1, nSoundCount - 1, MainWindow.this.m_fRate);
            MainWindow.this.m_fVolume += 0.06666667f;
            MainWindow.this.m_fRate += 0.06666667f;
            MainWindow.this.m_cHandler.postDelayed(MainWindow.this.m_cUpdateAutoShutTimeUI, 1000L);
        }
    };
    private Runnable m_cUpdateRecTimeUI = new Runnable() { // from class: com.android.camera.MainWindow.5
        @Override // java.lang.Runnable
        public void run() {
            int nMinute = MainWindow.this.m_nTimeRecord / 60;
            int nSeconds = MainWindow.this.m_nTimeRecord - (nMinute * 60);
            MainWindow.this.m_cTextViewRecord.setText(String.format("%d:%02d", Integer.valueOf(nMinute), Integer.valueOf(nSeconds)));
            if (!MainWindow.this.m_bFlagRecordImage || !MainWindow.this.m_cCameraView.IsStarted()) {
                MainWindow.this.m_btnPauseResume.setImageResource(R.drawable.pause_normal);
            } else if (MainWindow.this.m_cCameraView.IsPaused()) {
                MainWindow.this.m_btnPauseResume.setImageResource(R.drawable.pause_pressed);
            } else {
                MainWindow.this.m_btnPauseResume.setImageResource(R.drawable.pause_normal);
            }
            MainWindow.this.m_bFlagRecordImage = MainWindow.this.m_bFlagRecordImage ? false : true;
        }
    };
    private Runnable m_cUpdateBusy = new Runnable() { // from class: com.android.camera.MainWindow.6
        @Override // java.lang.Runnable
        public void run() {
            MainWindow.this.m_cHandler.removeCallbacks(MainWindow.this.m_cUpdateBusy);
            if (MainWindow.this.m_cCameraView.isBusy()) {
                MainWindow.this.m_cHandler.postDelayed(MainWindow.this.m_cUpdateBusy, 500L);
            }
            MainWindow.this.m_cBusyIndicator.setVisibility(4);
        }
    };

    private void HideCtrlPanel() {
        this.m_cViewFrameCameraSettings.startAnimation(AnimationUtils.loadAnimation(this, R.anim.settings_out));
        this.m_cListViewParamsWnd.setVisibility(8);
        this.m_cViewIncludeCameraSettings.setVisibility(0);
        WritePrefs();
        this.m_cViewFrameCameraSettings.setVisibility(8);
        UpdateButtons();
    }

    private boolean IsCtrlPanelShowing() {
        return this.m_cViewFrameCameraSettings.getVisibility() == 0;
    }

    private void ShowCtrlPanel() {
        this.m_cViewFrameCameraSettings.startAnimation(AnimationUtils.loadAnimation(this, R.anim.settings_in));
        this.m_cViewFrameCameraSettings.setVisibility(0);
        if (this.m_bImageCaptureIntent) {
            this.m_btnVideoSettings.setVisibility(8);
        } else {
            this.m_btnVideoSettings.setVisibility(0);
        }
        if (this.m_bVideoCaptureIntent) {
            this.m_btnPhotoSettings.setVisibility(8);
        } else {
            this.m_btnPhotoSettings.setVisibility(0);
        }
        UpdateButtons();
        this.m_btnCameraSettings.performClick();
    }

    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window wind = getWindow();
        wind.addFlags(524288);
        wind.addFlags(2097152);
        wind.addFlags(4194304);
        Intent cIntent = getIntent();
        String strAction = cIntent.getAction();
        Bundle myExtras = cIntent.getExtras();
        if ("android.media.action.IMAGE_CAPTURE".equals(strAction)) {
            this.m_bImageCaptureIntent = true;
            if (myExtras != null) {
                this.m_cUriSaveImage = (Uri) myExtras.getParcelable("output");
            }
        }
        if ("android.media.action.VIDEO_CAPTURE".equals(strAction)) {
            this.m_bVideoCaptureIntent = true;
            if (myExtras != null) {
                this.m_cUriSaveVideo = (Uri) myExtras.getParcelable("output");
            }
        }
        setContentView(R.layout.main);
        try {
            this.m_fBrightness = Settings.System.getInt(getContentResolver(), "screen_brightness") / 255.0f;
        } catch (Settings.SettingNotFoundException e) {
            e.printStackTrace();
        }
        this.m_cLocManager = (LocationManager) getSystemService("location");
        this.m_btnGallery = findViewById(R.id.ImageButtonGallery);
        this.m_btnGalleryInternal = (ImageButton) findViewById(R.id.ImageButtonGalleryInternal);
        this.m_btnPauseResume = (ImageButton) findViewById(R.id.ImageButtonPauseResume);
        this.m_btnCapture = (ImageButton) findViewById(R.id.ImageButtonCapture);
        this.m_btnRecord = (ImageButton) findViewById(R.id.ImageButtonRecord);
        this.m_btnDelete = (ImageView) findViewById(R.id.ImageViewDelete);
        this.m_btnNormalScreen = (ImageView) findViewById(R.id.ImageViewSave);
        this.m_btnCameraSettings = (ImageButton) findViewById(R.id.imageButtonCameraSettings);
        this.m_btnPhotoSettings = (ImageButton) findViewById(R.id.imageButtonPhotoSettings);
        this.m_btnVideoSettings = (ImageButton) findViewById(R.id.imageButtonVideoSettings);
        this.m_btnCommonSettings = (ImageButton) findViewById(R.id.imageButtonCommonSettings);
        this.m_btnAllSettings = (ImageButton) findViewById(R.id.imageButtonAllSettings);
        this.m_viewCameraSettingTab = findViewById(R.id.tabCameraSettings);
        this.m_viewPhotoSettingTab = findViewById(R.id.tabPhotoSettings);
        this.m_viewVideoSettingTab = findViewById(R.id.tabVideoSettings);
        this.m_viewCommonSettingTab = findViewById(R.id.tabCommonSettings);
        this.m_btnSwitchCamera = (ImageButton) findViewById(R.id.ImageButtonSwitchCamera);
        this.m_btnFlashMode = (ImageButton) findViewById(R.id.ImageButtonFlashMode);
        this.m_btnPlay = (ImageButton) findViewById(R.id.imageButtonPreviewPlay);
        this.m_btnAELock = (ImageButton) findViewById(R.id.ImageButtonAELock);
        this.m_btnWBLock = (ImageButton) findViewById(R.id.ImageButtonWBLock);
        this.m_btnAFReset = (ImageButton) findViewById(R.id.ImageButtonAFReset);
        this.m_cViewMainPreviewContainer = findViewById(R.id.relativeViewPreview);
        this.m_btnWB = (LinearLayout) findViewById(R.id.linearWhiteBalance);
        this.m_btnCE = (LinearLayout) findViewById(R.id.linearColorEffect);
        this.m_btnSM = (LinearLayout) findViewById(R.id.linearSceneMode);
        this.m_btnExposure = (LinearLayout) findViewById(R.id.linearExposureCompensation);
        this.m_btnAB = (LinearLayout) findViewById(R.id.linearAntiBanding);
        this.m_btnFocus = (LinearLayout) findViewById(R.id.linearFocusMode);
        this.m_btnISO = (LinearLayout) findViewById(R.id.linearISO);
        this.m_btnAutoExposure = (LinearLayout) findViewById(R.id.linearExposureMode);
        this.m_btnContrast = (LinearLayout) findViewById(R.id.linearContrast);
        this.m_btnBrightness = (LinearLayout) findViewById(R.id.linearBrightness);
        this.m_btnSaturation = (LinearLayout) findViewById(R.id.linearSaturation);
        this.m_btnSharpness = (LinearLayout) findViewById(R.id.linearSharpness);
        this.m_btnPhotoRes = (LinearLayout) findViewById(R.id.linearPhotoRes);
        this.m_btnPhotoResFront = (LinearLayout) findViewById(R.id.linearPhotoResFront);
        this.m_btnPhotoMode = (LinearLayout) findViewById(R.id.linearPhotoMode);
        this.m_btnVideoRes = (LinearLayout) findViewById(R.id.linearVideoRes);
        this.m_btnPhotoInVideoRes = (LinearLayout) findViewById(R.id.linearPhotoResInVideo);
        this.m_btnVideoResFront = (LinearLayout) findViewById(R.id.linearVideoResFront);
        this.m_btnPhotoInVideoResFront = (LinearLayout) findViewById(R.id.linearPhotoResInVideoFront);
        this.m_btnVideoEncoder = (LinearLayout) findViewById(R.id.linearVideoEncoder);
        this.m_btnVideoFormat = (LinearLayout) findViewById(R.id.linearVideoFormat);
        this.m_btnVideoBitRate = (LinearLayout) findViewById(R.id.linearVideoBitRate);
        this.m_btnVideoFPS = (LinearLayout) findViewById(R.id.linearVideoFPS);
        this.m_btnSlowMotion = (LinearLayout) findViewById(R.id.linearSlowMotion);
        this.m_btnAudioSource = (LinearLayout) findViewById(R.id.linearAudioSource);
        this.m_btnAudioEncoder = (LinearLayout) findViewById(R.id.linearAudioEncoder);
        this.m_btnAudioSampleRate = (LinearLayout) findViewById(R.id.linearAudioSamplingRate);
        this.m_btnAudioBitRate = (LinearLayout) findViewById(R.id.linearAudioBitRate);
        this.m_btnRegInfo = (LinearLayout) findViewById(R.id.linearRegInfo);
        this.m_btnJPGQuality = (LinearLayout) findViewById(R.id.linearJPGQuality);
        this.m_btnAutoShutter = (LinearLayout) findViewById(R.id.linearAutoShutterDelay);
        this.m_viewUseSEC = (LinearLayout) findViewById(R.id.linearLayoutUseSEC);
        this.m_btnThanks = (TextView) findViewById(R.id.TextViewSpecialThanks);
        this.m_cIVPreview = (ImageView) findViewById(R.id.ImageViewPreview);
        this.m_cLinearFullAngle = findViewById(R.id.linearLayoutFullAngle);
        this.m_cCheckBoxFullAngle = (CheckBox) findViewById(R.id.CheckBoxFullAngle);
        this.m_cCheckBoxRestartCamera = (CheckBox) findViewById(R.id.CheckBoxRestartCamera);
        this.m_cCheckBoxEXIF = (CheckBox) findViewById(R.id.CheckBoxSaveGPSInEXIF);
        this.m_cCheckBoxDateTime = (CheckBox) findViewById(R.id.CheckBoxOverlayDateTime);
        this.m_cCheckBoxStereoSound = (CheckBox) findViewById(R.id.CheckBoxStereoSound);
        this.m_cCheckBoxAutoRotate = (CheckBox) findViewById(R.id.CheckBoxAutoRotate);
        this.m_cCheckBoxAntiShake = (CheckBox) findViewById(R.id.CheckBoxAntishake);
        this.m_cCheckBoxDelayedSave = (CheckBox) findViewById(R.id.CheckBoxDelayedSave);
        this.m_cCheckBoxVideoStab = (CheckBox) findViewById(R.id.CheckBoxVideoStabilization);
        this.m_cCheckBoxShowStatus = (CheckBox) findViewById(R.id.CheckBoxShowStatus);
        this.m_cCheckBoxMTKDevice = (CheckBox) findViewById(R.id.CheckBoxMTKDevice);
        this.m_cCheckBoxShowGrid = (CheckBox) findViewById(R.id.CheckBoxShowGrid);
        this.m_cCheckBoxAutoStartNew = (CheckBox) findViewById(R.id.CheckBoxAutoStartNew);
        this.m_cCheckBoxFlashOnFocus = (CheckBox) findViewById(R.id.CheckBoxFlashOnFocus);
        this.m_cCheckBoxVibrate = (CheckBox) findViewById(R.id.CheckBoxVibrate);
        this.m_cCheckBoxRunOnCameraButton = (CheckBox) findViewById(R.id.CheckBoxRunOnCameraButton);
        this.m_cCheckBoxTurnOffSounds = (CheckBox) findViewById(R.id.CheckBoxTurnOffSounds);
        this.m_cCheckBoxMaxBrightness = (CheckBox) findViewById(R.id.CheckBoxMaxBrightness);
        this.m_cCheckBoxSensorFocus = (CheckBox) findViewById(R.id.CheckBoxSensorFocus);
        this.m_cCheckBoxForcedAF = (CheckBox) findViewById(R.id.CheckBoxForcedAF);
        this.m_cCheckBoxLongClickShutter = (CheckBox) findViewById(R.id.CheckBoxLongClickShutter);
        this.m_cCheckBoxSaveDebugLog = (CheckBox) findViewById(R.id.CheckBoxSaveDebugLog);
        this.m_cCheckBoxUseSEC = (CheckBox) findViewById(R.id.CheckBoxUseSEC);
        this.m_cCheckBoxAGCOff = (CheckBox) findViewById(R.id.CheckBoxAGCOff);
        this.m_btnCameraScript = findViewById(R.id.textViewCameraScript);
        this.m_btnPreviewTime = (LinearLayout) findViewById(R.id.linearPreviewTime);
        this.m_btnFocusButton = (LinearLayout) findViewById(R.id.linearFocusButton);
        this.m_btnShutterButton = (LinearLayout) findViewById(R.id.linearShutterButton);
        this.m_btnFileNaming = (LinearLayout) findViewById(R.id.linearFileNaming);
        this.m_btnFolderSave = (LinearLayout) findViewById(R.id.linearFolderSave);
        this.m_cListViewParams = (ListView) findViewById(R.id.ListViewParams);
        this.m_cListViewParamsWnd = findViewById(R.id.includeListParams);
        this.m_cTextViewListParamsTitle = (TextView) findViewById(R.id.TextViewParamsTitle);
        this.m_cZoomProgress = (ZoomView) findViewById(R.id.ProgressBarZoom);
        this.m_cBusyIndicator = (ProgressBar) findViewById(R.id.ProgressBarWait);
        this.m_cBusyIndicator.setVisibility(4);
        this.m_cTextViewResWidth = (TextView) findViewById(R.id.TextViewVSWidth);
        this.m_cTextViewResHeight = (TextView) findViewById(R.id.TextViewVSHeight);
        this.m_cTextViewVideoEncoder = (TextView) findViewById(R.id.TextViewEncoder);
        this.m_cTextViewVideoBitRate = (TextView) findViewById(R.id.TextViewBitRate);
        this.m_cTextViewAudioEncoder = (TextView) findViewById(R.id.TextViewAudioEncoder);
        this.m_cTextViewAudioBitRate = (TextView) findViewById(R.id.TextViewAudioBitRate);
        this.m_cTextViewFormat = (TextView) findViewById(R.id.TextViewFormat);
        this.m_cTextViewFPS = (TextView) findViewById(R.id.TextViewFPS);
        this.m_cTextViewDelayCount = (TextView) findViewById(R.id.TextViewDelayCount);
        this.m_cTextViewMaxDelayCount = (TextView) findViewById(R.id.TextViewDelayMax);
        this.m_cImageViewAntiShake = (ImageView) findViewById(R.id.ImageViewAntiShake);
        this.m_cZoomProgress.setOnZoomViewValueChanged(this);
        this.m_cTextViewRecord = (TextView) findViewById(R.id.TextViewTimer);
        this.m_cViewIncludeCameraSettings = findViewById(R.id.includeCameraSettings);
        this.m_cViewFrameCameraSettings = findViewById(R.id.frameCameraSettings);
        this.m_cViewCameraContainer = findViewById(R.id.relativeCameraContainer);
        this.m_cViewPreviewButtons = findViewById(R.id.LinearLayoutPreviewButtons);
        this.m_cViewStatus = findViewById(R.id.includeStatus);
        this.m_cViewMainButtonsInternal = findViewById(R.id.LinearLayoutMainButtonsInternal);
        this.m_cTextViewPanoMess = (TextView) findViewById(R.id.textViewPanoMess);
        this.m_cCheckBoxFullAngle.setOnCheckedChangeListener(this);
        this.m_cLinearFullAngle.setOnClickListener(this);
        this.m_cCheckBoxRestartCamera.setOnCheckedChangeListener(this);
        findViewById(R.id.linearRestartCamera).setOnClickListener(this);
        this.m_cCheckBoxShowStatus.setOnCheckedChangeListener(this);
        findViewById(R.id.linearLayoutShowStatus).setOnClickListener(this);
        this.m_cCheckBoxMTKDevice.setOnCheckedChangeListener(this);
        findViewById(R.id.linearLayoutMTKDevice).setOnClickListener(this);
        this.m_cCheckBoxShowGrid.setOnCheckedChangeListener(this);
        findViewById(R.id.linearLayoutShowGrid).setOnClickListener(this);
        this.m_cCheckBoxAutoStartNew.setOnCheckedChangeListener(this);
        findViewById(R.id.linearLayoutAutoStartNew).setOnClickListener(this);
        this.m_cCheckBoxFlashOnFocus.setOnCheckedChangeListener(this);
        findViewById(R.id.linearLayoutFlashOnFocus).setOnClickListener(this);
        this.m_cCheckBoxVibrate.setOnCheckedChangeListener(this);
        findViewById(R.id.linearLayoutVibrate).setOnClickListener(this);
        this.m_cCheckBoxRunOnCameraButton.setOnCheckedChangeListener(this);
        findViewById(R.id.linearLayoutRunOnCameraButton).setOnClickListener(this);
        this.m_cCheckBoxTurnOffSounds.setOnCheckedChangeListener(this);
        findViewById(R.id.linearLayoutTurnOffSounds).setOnClickListener(this);
        this.m_cCheckBoxMaxBrightness.setOnCheckedChangeListener(this);
        findViewById(R.id.linearLayoutMaxBrightness).setOnClickListener(this);
        this.m_cCheckBoxSensorFocus.setOnCheckedChangeListener(this);
        findViewById(R.id.linearLayoutSensorFocus).setOnClickListener(this);
        this.m_cCheckBoxForcedAF.setOnCheckedChangeListener(this);
        findViewById(R.id.linearLayoutForcedAF).setOnClickListener(this);
        this.m_cCheckBoxLongClickShutter.setOnCheckedChangeListener(this);
        findViewById(R.id.linearLayoutLongClickShutter).setOnClickListener(this);
        this.m_cCheckBoxSaveDebugLog.setOnCheckedChangeListener(this);
        findViewById(R.id.linearLayoutSaveDebugLog).setOnClickListener(this);
        this.m_cCheckBoxUseSEC.setOnCheckedChangeListener(this);
        this.m_viewUseSEC.setOnClickListener(this);
        this.m_cCheckBoxAGCOff.setOnCheckedChangeListener(this);
        findViewById(R.id.linearLayoutAGCOff).setOnClickListener(this);
        this.m_btnCameraScript.setOnClickListener(this);
        this.m_btnPreviewTime.setOnClickListener(this);
        this.m_btnFocusButton.setOnClickListener(this);
        this.m_btnShutterButton.setOnClickListener(this);
        this.m_btnFileNaming.setOnClickListener(this);
        this.m_btnFolderSave.setOnClickListener(this);
        this.m_cCheckBoxEXIF.setOnCheckedChangeListener(this);
        findViewById(R.id.RelativeLayoutSaveGPSInEXIF).setOnClickListener(this);
        this.m_cCheckBoxDateTime.setOnCheckedChangeListener(this);
        findViewById(R.id.RelativeLayoutOverlayDateTime).setOnClickListener(this);
        this.m_cCheckBoxStereoSound.setOnCheckedChangeListener(this);
        findViewById(R.id.RelativeLayoutStereoSound).setOnClickListener(this);
        this.m_cCheckBoxAutoRotate.setOnCheckedChangeListener(this);
        findViewById(R.id.RelativeLayoutAutoRotate).setOnClickListener(this);
        this.m_cCheckBoxAntiShake.setOnCheckedChangeListener(this);
        findViewById(R.id.RelativeLayoutAntishake).setOnClickListener(this);
        this.m_cCheckBoxDelayedSave.setOnCheckedChangeListener(this);
        findViewById(R.id.LinearLayoutDelayedSave).setOnClickListener(this);
        this.m_cCheckBoxVideoStab.setOnCheckedChangeListener(this);
        findViewById(R.id.RelativeLayoutVideoStab).setOnClickListener(this);
        this.m_btnCameraSettings.setOnClickListener(this);
        this.m_btnPhotoSettings.setOnClickListener(this);
        this.m_btnVideoSettings.setOnClickListener(this);
        this.m_btnCommonSettings.setOnClickListener(this);
        this.m_btnAllSettings.setOnClickListener(this);
        this.m_btnAutoShutter.setOnClickListener(this);
        this.m_btnPhotoRes.setOnClickListener(this);
        this.m_btnPhotoResFront.setOnClickListener(this);
        this.m_btnPhotoMode.setOnClickListener(this);
        this.m_btnVideoRes.setOnClickListener(this);
        this.m_btnPhotoInVideoRes.setOnClickListener(this);
        this.m_btnVideoResFront.setOnClickListener(this);
        this.m_btnPhotoInVideoResFront.setOnClickListener(this);
        this.m_btnVideoEncoder.setOnClickListener(this);
        this.m_btnVideoFormat.setOnClickListener(this);
        this.m_btnVideoBitRate.setOnClickListener(this);
        this.m_btnVideoFPS.setOnClickListener(this);
        this.m_btnSlowMotion.setOnClickListener(this);
        this.m_btnAudioSource.setOnClickListener(this);
        this.m_btnAudioEncoder.setOnClickListener(this);
        this.m_btnAudioSampleRate.setOnClickListener(this);
        this.m_btnAudioBitRate.setOnClickListener(this);
        this.m_btnRegInfo.setOnClickListener(this);
        this.m_btnPauseResume.setOnClickListener(this);
        this.m_btnSwitchCamera.setOnClickListener(this);
        this.m_btnFlashMode.setOnClickListener(this);
        this.m_btnCapture.setOnClickListener(this);
        this.m_btnCapture.setOnLongClickListener(this);
        this.m_btnRecord.setOnClickListener(this);
        this.m_btnAELock.setOnClickListener(this);
        this.m_btnWBLock.setOnClickListener(this);
        this.m_btnAFReset.setOnClickListener(this);
        this.m_btnThanks.setOnClickListener(this);
        this.m_btnAutoExposure.setOnClickListener(this);
        this.m_btnISO.setOnClickListener(this);
        this.m_btnWB.setOnClickListener(this);
        this.m_btnCE.setOnClickListener(this);
        this.m_btnSM.setOnClickListener(this);
        this.m_btnExposure.setOnClickListener(this);
        this.m_btnAB.setOnClickListener(this);
        this.m_btnFocus.setOnClickListener(this);
        this.m_btnGallery.setOnClickListener(this);
        findViewById(R.id.ImageButtonGalleryBorder).setOnClickListener(this);
        findViewById(R.id.ImageButtonGalleryBorder).setOnLongClickListener(this);
        this.m_btnContrast.setOnClickListener(this);
        this.m_btnBrightness.setOnClickListener(this);
        this.m_btnSaturation.setOnClickListener(this);
        this.m_btnSharpness.setOnClickListener(this);
        this.m_btnJPGQuality.setOnClickListener(this);
        this.m_btnDelete.setOnClickListener(this);
        this.m_btnNormalScreen.setOnClickListener(this);
        this.m_btnPlay.setOnClickListener(this);
        this.m_cCameraPreview = (SurfaceView) findViewById(R.id.CameraView);
        SharedPreferences cPrefs = getSharedPreferences("Common", 0);
        this.m_cCameraView = new CameraView(this, this.m_cCameraPreview.getHolder(), cPrefs.getBoolean("Use SEC API", true));
        g_cCameraView = this.m_cCameraView;
        this.m_cCameraView.m_cGridView = (CGridView) findViewById(R.id.GridView);
        this.m_cCameraView.m_cGridView.SetListener(this);
        ReadPrefs(cPrefs);
        this.m_cCameraView.ReadScript();
        UpdateControls();
        UpdateButtons();
        SharedPreferences.Editor cEditPrefs = getSharedPreferences("Common", 0).edit();
        cEditPrefs.putBoolean("Run on camera button pressed", true);
        cEditPrefs.commit();
        if (!CheckRPN()) {
            if (getPackageName().indexOf("Pro") >= 0) {
                try {
                    Toast.makeText(this, (int) R.string.ToastLicenseChecking, 1).show();
                    String strIMEI = getDeviceID();
                    this.mChecker = new LicenseChecker(this, new ServerManagedPolicy(this, new AESObfuscator(SALT, getPackageName(), strIMEI)), BASE64_PUBLIC_KEY);
                    this.mLicenseCheckerCallback = new MarketLicenseCheckerCallback(this, null);
                    this.mChecker.checkAccess(this.mLicenseCheckerCallback);
                } catch (Exception e2) {
                    DonationDlg(false);
                }
            } else {
                try {
                    this.adView = new AdView(this);
                    this.adView.setAdUnitId("ca-app-pub-3988028866185067/4854683941");
                    this.adView.setAdSize(AdSize.BANNER);
                    LinearLayout layout = (LinearLayout) findViewById(R.id.linearLayoutAdMob);
                    LinearLayout.LayoutParams cParams = new LinearLayout.LayoutParams(-2, -2);
                    cParams.gravity = 1;
                    layout.addView(this.adView, cParams);
                    this.adView.loadAd(new AdRequest.Builder().build());
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } else {
            this.m_cCameraView.m_bFreeVersion = false;
        }
        this.m_nSoundID = this.m_cSoundPool.load(this, R.raw.beep, 1);
        this.m_cOrientListener = new MyOrientationEventListener(this);
        this.m_cOrientListener.enable();
        HideCtrlPanel();
        this.m_cCameraView.m_cGridView.setListener(this);
        this.m_cVibrator = (Vibrator) getSystemService("vibrator");
    }

    public String getDeviceID() {
        TelephonyManager cManager = (TelephonyManager) getSystemService("phone");
        String strIMEI = cManager.getDeviceId();
        if (strIMEI == null || strIMEI.length() == 0) {
            Object oValue = InvokeHelper.GetStaticFieldValue(Build.class, "SERIAL");
            if (oValue != null) {
                String strIMEI2 = oValue.toString();
                Log.e("Serial", strIMEI2);
                return strIMEI2;
            }
            Object oValue2 = InvokeHelper.GetStaticFieldValue(Build.class, "ID");
            if (oValue2 != null) {
                String strIMEI3 = oValue2.toString();
                Log.e("ID", strIMEI3);
                return strIMEI3;
            }
            return "Unknown";
        }
        return strIMEI;
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        SetWindowBrightness(this.m_fBrightness);
        this.m_cHandler.removeCallbacks(this.m_cUpdateScreen);
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        if (this.m_cCameraView.m_bUseMaxBrightness) {
            SetWindowBrightness(1.0f);
        } else {
            SetWindowBrightness(this.m_fBrightness);
        }
        this.m_cLocManager.removeUpdates(this);
        if (this.m_cCameraView.getUseGPSEXIF()) {
            this.m_cLocManager.requestLocationUpdates("gps", 0L, 0.0f, this);
            this.m_cLocManager.requestLocationUpdates("network", 0L, 0.0f, this);
        }
        AdjustAspectRatio();
        UpdateGalleryIcon();
        this.m_cHandler.removeCallbacks(this.m_cUpdateScreen);
        this.m_cHandler.postDelayed(this.m_cUpdateScreen, 2000L);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View arg0) {
        String strVersionCode;
        StopAutoShutter();
        if (!this.m_cCameraView.isBusy()) {
            switch (arg0.getId()) {
                case R.id.linearWhiteBalance /* 2131230753 */:
                    SelectWhiteBalanceDlg();
                    break;
                case R.id.linearColorEffect /* 2131230754 */:
                    SelectColorEffectDlg();
                    break;
                case R.id.linearSceneMode /* 2131230755 */:
                    SelectSceneModeDlg();
                    break;
                case R.id.linearISO /* 2131230756 */:
                    SelectISODlg();
                    break;
                case R.id.linearExposureMode /* 2131230757 */:
                    SelectAutoExposureDlg();
                    break;
                case R.id.linearExposureCompensation /* 2131230758 */:
                    SelectExposureDlg();
                    break;
                case R.id.linearAntiBanding /* 2131230759 */:
                    SelectAntiBandingDlg();
                    break;
                case R.id.linearFocusMode /* 2131230760 */:
                    SelectFocusModeDlg();
                    break;
                case R.id.linearBrightness /* 2131230761 */:
                    SelectBrightnessDlg();
                    break;
                case R.id.linearContrast /* 2131230762 */:
                    SelectContrastDlg();
                    break;
                case R.id.linearSaturation /* 2131230763 */:
                    SelectSaturationDlg();
                    break;
                case R.id.linearSharpness /* 2131230764 */:
                    SelectSharpnessDlg();
                    break;
                case R.id.imageButtonPreviewPlay /* 2131230801 */:
                    try {
                        Intent cIntent = new Intent();
                        cIntent.setAction("android.intent.action.VIEW");
                        cIntent.setDataAndType(Uri.parse(this.m_strLastFile), "video/*");
                        startActivity(cIntent);
                        break;
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        break;
                    }
                case R.id.imageButtonAllSettings /* 2131230805 */:
                    ToggleSettingWnd();
                    break;
                case R.id.ImageButtonSwitchCamera /* 2131230806 */:
                    this.m_cCameraView.SwitchCamera();
                    Toast.makeText(this, (int) R.string.ToastCameraSwitch, 0).show();
                    AdjustAspectRatio();
                    UpdateControls();
                    UpdateButtons();
                    break;
                case R.id.ImageButtonAELock /* 2131230808 */:
                    this.m_cCameraView.setAELock(!this.m_cCameraView.getAELock());
                    if (this.m_cCameraView.getAELock()) {
                        Toast.makeText(this, (int) R.string.ToastAELock, 0).show();
                        break;
                    } else {
                        Toast.makeText(this, (int) R.string.ToastAEUnLock, 0).show();
                        break;
                    }
                case R.id.ImageButtonAFReset /* 2131230809 */:
                    this.m_cCameraView.ResetManualFocus();
                    break;
                case R.id.ImageButtonWBLock /* 2131230810 */:
                    this.m_cCameraView.setWBLock(!this.m_cCameraView.getWBLock());
                    if (this.m_cCameraView.getWBLock()) {
                        Toast.makeText(this, (int) R.string.ToastWBLock, 0).show();
                        break;
                    } else {
                        Toast.makeText(this, (int) R.string.ToastWBUnLock, 0).show();
                        break;
                    }
                case R.id.ImageButtonGallery /* 2131230815 */:
                case R.id.ImageButtonGalleryBorder /* 2131230817 */:
                    this.m_cCameraView.StopRecord();
                    StartGallery();
                    break;
                case R.id.ImageButtonFlashMode /* 2131230819 */:
                    this.m_cCameraView.SwitchFlashMode();
                    break;
                case R.id.ImageButtonRecord /* 2131230820 */:
                    if (this.m_cCameraView.m_bVibrate) {
                        this.m_cVibrator.vibrate(100L);
                    }
                    if (this.m_cCameraView.IsStarted()) {
                        this.m_cCameraView.StopRecord();
                        break;
                    } else if (!this.m_bAutoShutter) {
                        this.m_cCameraView.RecordVideo();
                        break;
                    }
                    break;
                case R.id.ImageButtonCapture /* 2131230821 */:
                    if (this.m_cCameraView.m_bVibrate) {
                        this.m_cVibrator.vibrate(100L);
                    }
                    if (this.m_cCameraView.IsStarted()) {
                        this.m_cCameraView.TakePictureICS(false);
                        break;
                    } else if (!this.m_bAutoShutter) {
                        if (this.m_bAntiShake) {
                            this.m_bUseAntiShake = true;
                            this.m_cImageViewAntiShake.setVisibility(0);
                            this.m_cHandler.postDelayed(new Runnable() { // from class: com.android.camera.MainWindow.7
                                @Override // java.lang.Runnable
                                public void run() {
                                    MainWindow.this.m_cImageViewAntiShake.setVisibility(8);
                                    if (MainWindow.this.m_bUseAntiShake) {
                                        MainWindow.this.m_bUseAntiShake = false;
                                        MainWindow.this.m_cSoundPool.play(MainWindow.this.m_nSoundID, 1.0f, 1.0f, 0, 0, 1.0f);
                                        Toast.makeText(MainWindow.this, (int) R.string.PhotoCanceled, 1).show();
                                    }
                                }
                            }, 5000L);
                            return;
                        } else if (this.m_cCameraView.getPhotoMode() == 2 && Panorama.m_bEnable) {
                            switch (this.m_cCameraView.GetPanoMode()) {
                                case 1:
                                    this.m_cCameraView.StopPanoramaTaking();
                                    break;
                                case 2:
                                    break;
                                default:
                                    this.m_cCameraView.StartPanoramaTakingPictures();
                                    break;
                            }
                        } else {
                            this.m_cCameraView.CapturePhoto(false);
                            break;
                        }
                    }
                    break;
                case R.id.ImageButtonPauseResume /* 2131230822 */:
                    if (this.m_cCameraView.IsPaused()) {
                        this.m_cCameraView.Resume();
                        break;
                    } else {
                        this.m_cCameraView.Pause();
                        break;
                    }
                case R.id.ImageViewSave /* 2131230825 */:
                    ShowNormalScreen();
                    break;
                case R.id.ImageViewDelete /* 2131230826 */:
                    this.m_bIndexInGallery = false;
                    this.m_cBmpSmalPostView = null;
                    ShowNormalScreen();
                    this.m_cCameraView.m_cSaveThread.DeleteLastFile();
                    return;
                case R.id.linearPhotoRes /* 2131230850 */:
                    SelectPhotoResDlg(false);
                    break;
                case R.id.linearPhotoResFront /* 2131230851 */:
                    SelectPhotoResDlg(true);
                    break;
                case R.id.linearPhotoMode /* 2131230852 */:
                    SelectPhotoModeDlg();
                    break;
                case R.id.linearLayoutFullAngle /* 2131230853 */:
                    this.m_cCheckBoxFullAngle.setChecked(!this.m_cCheckBoxFullAngle.isChecked());
                    break;
                case R.id.RelativeLayoutAntishake /* 2131230856 */:
                    this.m_cCheckBoxAntiShake.setChecked(!this.m_cCheckBoxAntiShake.isChecked());
                    break;
                case R.id.RelativeLayoutSaveGPSInEXIF /* 2131230859 */:
                    this.m_cCheckBoxEXIF.setChecked(!this.m_cCheckBoxEXIF.isChecked());
                    break;
                case R.id.RelativeLayoutOverlayDateTime /* 2131230862 */:
                    if (!this.m_cCheckBoxDateTime.isChecked()) {
                        OverlaySettingsDlg cDlg = new OverlaySettingsDlg(this, this.m_cCameraView, new OverlaySettingsDlg.OverlaySettingsListener() { // from class: com.android.camera.MainWindow.9
                            @Override // com.android.camera.OverlaySettingsDlg.OverlaySettingsListener
                            public void onOK() {
                                MainWindow.this.m_cCheckBoxDateTime.setChecked(true);
                            }

                            @Override // com.android.camera.OverlaySettingsDlg.OverlaySettingsListener
                            public void onCancel() {
                            }
                        });
                        cDlg.show();
                        break;
                    } else {
                        this.m_cCheckBoxDateTime.setChecked(false);
                        break;
                    }
                case R.id.linearJPGQuality /* 2131230865 */:
                    SelectJPGQualityDlg();
                    break;
                case R.id.LinearLayoutDelayedSave /* 2131230866 */:
                    this.m_cCheckBoxDelayedSave.setChecked(!this.m_cCheckBoxDelayedSave.isChecked());
                    break;
                case R.id.linearAutoShutterDelay /* 2131230869 */:
                    SelectAutoShutterDelayDlg();
                    break;
                case R.id.linearFolderSave /* 2131230880 */:
                    SelectFolderDlg(Build.VERSION.SDK_INT >= 21);
                    break;
                case R.id.linearFileNaming /* 2131230881 */:
                    SelectFileNameFormatDlg();
                    break;
                case R.id.linearLayoutUseSEC /* 2131230882 */:
                    this.m_cCheckBoxUseSEC.setChecked(!this.m_cCheckBoxUseSEC.isChecked());
                    break;
                case R.id.linearLayoutShowGrid /* 2131230885 */:
                    this.m_cCheckBoxShowGrid.setChecked(!this.m_cCheckBoxShowGrid.isChecked());
                    break;
                case R.id.linearLayoutShowStatus /* 2131230888 */:
                    this.m_cCheckBoxShowStatus.setChecked(!this.m_cCheckBoxShowStatus.isChecked());
                    break;
                case R.id.RelativeLayoutAutoRotate /* 2131230890 */:
                    this.m_cCheckBoxAutoRotate.setChecked(!this.m_cCheckBoxAutoRotate.isChecked());
                    break;
                case R.id.textViewCameraScript /* 2131230893 */:
                    ShowCameraScriptDlg();
                    break;
                case R.id.linearPreviewTime /* 2131230894 */:
                    SelectPreviewTimeDlg();
                    break;
                case R.id.linearLayoutAutoStartNew /* 2131230895 */:
                    this.m_cCheckBoxAutoStartNew.setChecked(!this.m_cCheckBoxAutoStartNew.isChecked());
                    break;
                case R.id.linearLayoutFlashOnFocus /* 2131230897 */:
                    this.m_cCheckBoxFlashOnFocus.setChecked(!this.m_cCheckBoxFlashOnFocus.isChecked());
                    break;
                case R.id.linearLayoutMTKDevice /* 2131230899 */:
                    this.m_cCheckBoxMTKDevice.setChecked(!this.m_cCheckBoxMTKDevice.isChecked());
                    break;
                case R.id.linearFocusButton /* 2131230901 */:
                    SelectFocusKeyCodeDlg();
                    break;
                case R.id.linearShutterButton /* 2131230902 */:
                    SelectShutterKeyCodeDlg();
                    break;
                case R.id.linearLayoutVibrate /* 2131230903 */:
                    this.m_cCheckBoxVibrate.setChecked(!this.m_cCheckBoxVibrate.isChecked());
                    break;
                case R.id.linearLayoutRunOnCameraButton /* 2131230905 */:
                    this.m_cCheckBoxRunOnCameraButton.setChecked(!this.m_cCheckBoxRunOnCameraButton.isChecked());
                    break;
                case R.id.linearLayoutTurnOffSounds /* 2131230907 */:
                    this.m_cCheckBoxTurnOffSounds.setChecked(!this.m_cCheckBoxTurnOffSounds.isChecked());
                    break;
                case R.id.linearLayoutMaxBrightness /* 2131230909 */:
                    this.m_cCheckBoxMaxBrightness.setChecked(!this.m_cCheckBoxMaxBrightness.isChecked());
                    break;
                case R.id.linearLayoutSensorFocus /* 2131230911 */:
                    this.m_cCheckBoxSensorFocus.setChecked(!this.m_cCheckBoxSensorFocus.isChecked());
                    break;
                case R.id.linearLayoutForcedAF /* 2131230913 */:
                    this.m_cCheckBoxForcedAF.setChecked(!this.m_cCheckBoxForcedAF.isChecked());
                    break;
                case R.id.linearLayoutLongClickShutter /* 2131230915 */:
                    this.m_cCheckBoxLongClickShutter.setChecked(!this.m_cCheckBoxLongClickShutter.isChecked());
                    break;
                case R.id.linearLayoutSaveDebugLog /* 2131230917 */:
                    this.m_cCheckBoxSaveDebugLog.setChecked(!this.m_cCheckBoxSaveDebugLog.isChecked());
                    break;
                case R.id.buttonSendLog /* 2131230919 */:
                    SendLogDlg cDlg2 = new SendLogDlg(this);
                    cDlg2.show();
                    break;
                case R.id.linearRegInfo /* 2131230920 */:
                    if (this.m_cCameraView.m_bFreeVersion) {
                        DonationDlg(true);
                        break;
                    } else {
                        try {
                            Resources cRes = getResources();
                            AlertDialog.Builder cBuilder = new AlertDialog.Builder(this);
                            cBuilder.setTitle(R.string.app_name);
                            String strVersion = " n/a";
                            try {
                                PackageInfo cPackInfo = getPackageManager().getPackageInfo(getPackageName(), 64);
                                strVersion = " " + cPackInfo.versionName;
                                strVersionCode = " " + String.valueOf(cPackInfo.versionCode);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            String strMessage = String.valueOf(cRes.getString(R.string.Version)) + strVersion + "\r\n";
                            String strMessage2 = String.valueOf(strMessage) + cRes.getString(R.string.VersionCode) + strVersionCode + "\r\n";
                            SharedPreferences cPrefs = getSharedPreferences("Registration", 0);
                            String strIMEI = getDeviceID();
                            String strKey = cPrefs.getString("Registration key", "");
                            cBuilder.setMessage(String.valueOf(String.valueOf(String.valueOf(strMessage2) + cRes.getString(R.string.RegInfoDlgTitle) + ":\r\n") + cRes.getString(R.string.RegDlgIMEI) + ": " + strIMEI + "\r\n") + cRes.getString(R.string.RegDlgKey) + ": " + strKey);
                            cBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() { // from class: com.android.camera.MainWindow.8
                                @Override // android.content.DialogInterface.OnClickListener
                                public void onClick(DialogInterface arg02, int arg1) {
                                }
                            });
                            cBuilder.create().show();
                            break;
                        } catch (Exception e2) {
                            break;
                        }
                    }
                case R.id.TextViewSpecialThanks /* 2131230921 */:
                    AlertDialog.Builder cBuilder2 = new AlertDialog.Builder(this);
                    cBuilder2.setTitle(R.string.LabelSpecialThanks);
                    cBuilder2.setMessage(R.string.LabelSpecialText);
                    cBuilder2.setPositiveButton("OK", new DialogInterface.OnClickListener() { // from class: com.android.camera.MainWindow.10
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                    cBuilder2.create().show();
                    break;
                case R.id.imageButtonCameraSettings /* 2131230940 */:
                    this.m_btnCameraSettings.setSelected(true);
                    this.m_btnPhotoSettings.setSelected(false);
                    this.m_btnVideoSettings.setSelected(false);
                    this.m_btnCommonSettings.setSelected(false);
                    this.m_viewCameraSettingTab.setVisibility(0);
                    this.m_viewPhotoSettingTab.setVisibility(8);
                    this.m_viewVideoSettingTab.setVisibility(8);
                    this.m_viewCommonSettingTab.setVisibility(8);
                    break;
                case R.id.imageButtonPhotoSettings /* 2131230941 */:
                    this.m_btnCameraSettings.setSelected(false);
                    this.m_btnPhotoSettings.setSelected(true);
                    this.m_btnVideoSettings.setSelected(false);
                    this.m_btnCommonSettings.setSelected(false);
                    this.m_viewCameraSettingTab.setVisibility(8);
                    this.m_viewPhotoSettingTab.setVisibility(0);
                    this.m_viewVideoSettingTab.setVisibility(8);
                    this.m_viewCommonSettingTab.setVisibility(8);
                    break;
                case R.id.imageButtonVideoSettings /* 2131230942 */:
                    this.m_btnCameraSettings.setSelected(false);
                    this.m_btnPhotoSettings.setSelected(false);
                    this.m_btnVideoSettings.setSelected(true);
                    this.m_btnCommonSettings.setSelected(false);
                    this.m_viewCameraSettingTab.setVisibility(8);
                    this.m_viewPhotoSettingTab.setVisibility(8);
                    this.m_viewVideoSettingTab.setVisibility(0);
                    this.m_viewCommonSettingTab.setVisibility(8);
                    break;
                case R.id.imageButtonCommonSettings /* 2131230943 */:
                    this.m_btnCameraSettings.setSelected(false);
                    this.m_btnPhotoSettings.setSelected(false);
                    this.m_btnVideoSettings.setSelected(false);
                    this.m_btnCommonSettings.setSelected(true);
                    this.m_viewCameraSettingTab.setVisibility(8);
                    this.m_viewPhotoSettingTab.setVisibility(8);
                    this.m_viewVideoSettingTab.setVisibility(8);
                    this.m_viewCommonSettingTab.setVisibility(0);
                    break;
                case R.id.linearRestartCamera /* 2131230948 */:
                    this.m_cCheckBoxRestartCamera.setChecked(!this.m_cCheckBoxRestartCamera.isChecked());
                    break;
                case R.id.linearVideoRes /* 2131230951 */:
                    SelectVideoResDlg(false);
                    break;
                case R.id.linearPhotoResInVideo /* 2131230952 */:
                    SelectPhotoInVideoResDlg(false);
                    break;
                case R.id.linearVideoResFront /* 2131230953 */:
                    SelectVideoResDlg(true);
                    break;
                case R.id.linearPhotoResInVideoFront /* 2131230954 */:
                    SelectPhotoInVideoResDlg(true);
                    break;
                case R.id.linearVideoEncoder /* 2131230955 */:
                    SelectVideoEncoderDlg();
                    break;
                case R.id.linearVideoFormat /* 2131230956 */:
                    SelectVideoFormatDlg();
                    break;
                case R.id.linearVideoBitRate /* 2131230957 */:
                    SelectVideoBitRateDlg();
                    break;
                case R.id.linearVideoFPS /* 2131230958 */:
                    SelectVideoFPSDlg();
                    break;
                case R.id.linearSlowMotion /* 2131230959 */:
                    SelectSlowMotionDlg();
                    break;
                case R.id.RelativeLayoutVideoStab /* 2131230960 */:
                    this.m_cCheckBoxVideoStab.setChecked(!this.m_cCheckBoxVideoStab.isChecked());
                    break;
                case R.id.linearAudioSource /* 2131230963 */:
                    SelectAudioSourceDlg();
                    break;
                case R.id.linearAudioEncoder /* 2131230964 */:
                    SelectAudioEncoderDlg();
                    break;
                case R.id.linearAudioSamplingRate /* 2131230965 */:
                    SelectAudioSamplingRateDlg();
                    break;
                case R.id.linearAudioBitRate /* 2131230966 */:
                    SelectAudioBitRateDlg();
                    break;
                case R.id.linearLayoutAGCOff /* 2131230967 */:
                    this.m_cCheckBoxAGCOff.setChecked(!this.m_cCheckBoxAGCOff.isChecked());
                    break;
                case R.id.RelativeLayoutStereoSound /* 2131230970 */:
                    this.m_cCheckBoxStereoSound.setChecked(!this.m_cCheckBoxStereoSound.isChecked());
                    break;
            }
        }
        UpdateButtons();
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        if (this.adView != null) {
            this.adView.destroy();
        }
        super.onDestroy();
        if (isFinishing()) {
            WritePrefs();
            this.m_cOrientListener.disable();
            this.m_cLocManager.removeUpdates(this);
            this.m_cSoundPool.release();
            this.m_cSoundPool = null;
            try {
                if (this.mChecker != null) {
                    this.mChecker.onDestroy();
                }
            } catch (Exception e) {
            }
            this.m_cCameraView.ReleaseCameraViewAndExit();
            g_cCameraView = null;
            SetAppIcon(!this.m_cCameraView.m_bFreeVersion);
            Process.killProcess(Process.myPid());
        }
    }

    private void WritePrefs() {
        SharedPreferences.Editor cPrefs = getSharedPreferences("Common", 0).edit();
        cPrefs.clear();
        cPrefs.putInt("Resolution width", this.m_cCameraView.getResolution().x);
        cPrefs.putInt("Resolution height", this.m_cCameraView.getResolution().y);
        cPrefs.putInt("Resolution width front", this.m_cCameraView.getResolutionFront().x);
        cPrefs.putInt("Resolution height front", this.m_cCameraView.getResolutionFront().y);
        cPrefs.putInt("Encoder", this.m_cCameraView.getEncoder());
        cPrefs.putInt("Bitrate", this.m_cCameraView.getBitRate());
        cPrefs.putInt("Bitrate front", this.m_cCameraView.getBitRateFront());
        cPrefs.putString("White balance", this.m_cCameraView.getWB());
        cPrefs.putInt("Photo width", this.m_cCameraView.getPhotoSize().x);
        cPrefs.putInt("Photo height", this.m_cCameraView.getPhotoSize().y);
        cPrefs.putInt("Photo in video width", this.m_cCameraView.getPhotoInVideoSize().x);
        cPrefs.putInt("Photo in video height", this.m_cCameraView.getPhotoInVideoSize().y);
        cPrefs.putInt("Photo width front", this.m_cCameraView.getPhotoSizeFront().x);
        cPrefs.putInt("Photo height front", this.m_cCameraView.getPhotoSizeFront().y);
        cPrefs.putInt("Photo in video width front", this.m_cCameraView.getPhotoInVideoSizeFront().x);
        cPrefs.putInt("Photo in video height front", this.m_cCameraView.getPhotoInVideoSizeFront().y);
        cPrefs.putString("Flash mode", this.m_cCameraView.getFlashMode());
        cPrefs.putString("Scene mode", this.m_cCameraView.getSceneMode());
        cPrefs.putString("Color effect", this.m_cCameraView.getEffect());
        cPrefs.putString("Anti banding", this.m_cCameraView.getAntiBanding());
        cPrefs.putString("Focus mode", this.m_cCameraView.getFocusMode());
        cPrefs.putString("ISO", this.m_cCameraView.getISO());
        cPrefs.putString("Auto exposure", this.m_cCameraView.getAutoExposure());
        cPrefs.putInt("Audio bitrate", this.m_cCameraView.getAudioBitRate());
        cPrefs.putInt("Audio samplingrate", this.m_cCameraView.getSamplingRate());
        cPrefs.putInt("Audio encoder", this.m_cCameraView.getAudioEncoder());
        cPrefs.putInt("Frame rates", this.m_cCameraView.getFrameRates());
        cPrefs.putInt("Format", this.m_cCameraView.getFormat());
        cPrefs.putBoolean("Shutter on screen touch", this.m_cCameraView.getShutterOnScreenTouch());
        cPrefs.putBoolean("Turn off sounds", this.m_cCameraView.getTurnOffSounds());
        cPrefs.putBoolean("Run on camera button pressed", this.m_cCameraView.getRunOnCameraPress());
        cPrefs.putBoolean("Save GPS in EXIF", this.m_cCameraView.getUseGPSEXIF());
        cPrefs.putInt("Audio source", this.m_cCameraView.getAudioSource());
        cPrefs.putString("Contrast", this.m_cCameraView.getContrast());
        cPrefs.putString("Brightness", this.m_cCameraView.getBrightness());
        cPrefs.putString("Saturation", this.m_cCameraView.getSaturation());
        cPrefs.putString("Sharpness", this.m_cCameraView.getSharpness());
        cPrefs.putBoolean("Allow sensor focus", this.m_cCameraView.getAllowSensorFocus());
        cPrefs.putBoolean("Save debug log", DebugLog.m_bDebug);
        cPrefs.putInt("Picture format", this.m_cCameraView.getPictureFormat());
        cPrefs.putBoolean("Overlay date and time", this.m_cCameraView.getOverlayDateTime());
        cPrefs.putBoolean("Format filename", this.m_cCameraView.getSaveInIMAGEVIDEO());
        cPrefs.putInt("Audio channels", this.m_cCameraView.getAudioChannels());
        cPrefs.putBoolean("Forced AF", this.m_cCameraView.getForcedAF());
        cPrefs.putInt("Shutter keycode", this.m_cCameraView.m_nShutterKeyCode);
        cPrefs.putInt("Focus keycode", this.m_cCameraView.m_nFocusKeyCode);
        cPrefs.putBoolean("Use max brightness", this.m_cCameraView.m_bUseMaxBrightness);
        cPrefs.putInt("Last image index", this.m_cCameraView.getImageIndex());
        cPrefs.putInt("Last video index", this.m_cCameraView.getVideoIndex());
        cPrefs.putBoolean("Long click shutter", this.m_cCameraView.m_bLongClickShutter);
        cPrefs.putInt("JPEG quality", this.m_cCameraView.getJPGQuality());
        cPrefs.putInt("Exposure compensation", this.m_cCameraView.getExposure());
        cPrefs.putBoolean("Auto rotate", this.m_cCameraView.getAutoRotate());
        cPrefs.putString("Folder", CameraView.getFolder());
        cPrefs.putBoolean("Show grid", this.m_cCameraView.m_cGridView.getShowGrid());
        cPrefs.putBoolean("Antishake mode", this.m_bAntiShake);
        cPrefs.putInt("Max delayed saving files", this.m_cCameraView.getMaxDelayedFiles());
        cPrefs.putInt("Preview", this.m_cCameraView.m_nPreviewTime);
        cPrefs.putString("Overlay font", this.m_cCameraView.m_strOverlayFont);
        cPrefs.putInt("Overlay font color", this.m_cCameraView.m_nOverlayColor);
        cPrefs.putBoolean("Overlay 12-hour format", this.m_cCameraView.m_bOverlay12HourFormat);
        cPrefs.putBoolean("Overlay add GPS", this.m_cCameraView.m_bOverlayGPS);
        cPrefs.putString("Overlay additional text", this.m_cCameraView.m_strOverlayAddText);
        cPrefs.putInt("Overlay font size", this.m_cCameraView.m_nOverlayFontSize);
        cPrefs.putInt("Overlay gravity", this.m_cCameraView.m_nOverlayGravity);
        cPrefs.putInt("Overlay datetime format", this.m_cCameraView.m_nOverlayDateTimeFormat);
        cPrefs.putBoolean("Video stabilization", this.m_cCameraView.getVideoStab());
        cPrefs.putBoolean("Vibrate", this.m_cCameraView.m_bVibrate);
        cPrefs.putBoolean("Flash on focus", this.m_cCameraView.m_bFlashOnFocus);
        cPrefs.putString("Camera script", this.m_cCameraView.m_strScript);
        cPrefs.putBoolean("MTK 65xx device", this.m_cCameraView.m_bMTKDevice);
        cPrefs.putBoolean("AE lock", this.m_cCameraView.getAELock());
        cPrefs.putBoolean("WB lock", this.m_cCameraView.getWBLock());
        cPrefs.putBoolean("Show status", this.m_cCameraView.m_bShowStatus);
        cPrefs.putInt("Exposure compensation front", this.m_cCameraView.getExposureFront());
        cPrefs.putString("White balance front", this.m_cCameraView.getWBFront());
        cPrefs.putString("Contrast front", this.m_cCameraView.getContrastFront());
        cPrefs.putString("Brightness front", this.m_cCameraView.getBrightnessFront());
        cPrefs.putString("Saturation front", this.m_cCameraView.getSaturationFront());
        cPrefs.putString("Sharpness front", this.m_cCameraView.getSharpnessFront());
        cPrefs.putString("Flash mode front", this.m_cCameraView.getFlashModeFront());
        cPrefs.putString("Scene mode front", this.m_cCameraView.getSceneModeFront());
        cPrefs.putString("Color effect front", this.m_cCameraView.getEffectFront());
        cPrefs.putString("Anti banding front", this.m_cCameraView.getAntiBandingFront());
        cPrefs.putString("Focus mode front", this.m_cCameraView.getFocusModeFront());
        cPrefs.putString("ISO front", this.m_cCameraView.getISOFront());
        cPrefs.putString("Auto exposure front", this.m_cCameraView.getAutoExposureFront());
        cPrefs.putInt("Autoshutter timer", this.m_nAutoTimerSeconds);
        cPrefs.putFloat("Slow motion", this.m_cCameraView.m_fSlowMotionModule);
        cPrefs.putBoolean("Restart camera on video", this.m_cCameraView.m_bRestartCamera);
        cPrefs.putBoolean("Pano full angle", this.m_cCameraView.m_bFullSweep);
        cPrefs.putBoolean("Use SEC API", this.m_cCameraView.IsUseSEC());
        if (CameraView.m_treeUri != null) {
            cPrefs.putString("Tree URI", CameraView.m_treeUri.toString());
        }
        cPrefs.putBoolean("AGC off", this.m_cCameraView.IsAGCOff());
        cPrefs.commit();
    }

    private void ReadPrefs(SharedPreferences cPrefs) {
        Point ptRes = new Point(cPrefs.getInt("Resolution width", this.m_cCameraView.getResolution().x), cPrefs.getInt("Resolution height", this.m_cCameraView.getResolution().y));
        this.m_cCameraView.setResolution(ptRes);
        Point ptRes2 = new Point(cPrefs.getInt("Resolution width front", this.m_cCameraView.getResolutionFront().x), cPrefs.getInt("Resolution height front", this.m_cCameraView.getResolutionFront().y));
        this.m_cCameraView.setResolutionFront(ptRes2);
        this.m_cCameraView.setEncoder(cPrefs.getInt("Encoder", this.m_cCameraView.getEncoder()));
        this.m_cCameraView.setBitRate(BitrateSampleRateHelper.getNearestVideoBitrate(cPrefs.getInt("Bitrate", this.m_cCameraView.getBitRate())));
        this.m_cCameraView.setBitRateFront(BitrateSampleRateHelper.getNearestVideoBitrate(cPrefs.getInt("Bitrate front", this.m_cCameraView.getBitRateFront())));
        this.m_cCameraView.setWB(cPrefs.getString("White balance", "auto"));
        this.m_cCameraView.setFlashMode(cPrefs.getString("Flash mode", "off"));
        this.m_cCameraView.setSceneMode(cPrefs.getString("Scene mode", "auto"));
        this.m_cCameraView.setEffect(cPrefs.getString("Color effect", "none"));
        this.m_cCameraView.setPhotoSize(cPrefs.getInt("Photo width", this.m_cCameraView.getPhotoSize().x), cPrefs.getInt("Photo height", this.m_cCameraView.getPhotoSize().y));
        this.m_cCameraView.setPhotoInVideoSize(cPrefs.getInt("Photo in video width", this.m_cCameraView.getPhotoInVideoSize().x), cPrefs.getInt("Photo in video height", this.m_cCameraView.getPhotoInVideoSize().y));
        this.m_cCameraView.setPhotoSizeFront(cPrefs.getInt("Photo width front", this.m_cCameraView.getPhotoSizeFront().x), cPrefs.getInt("Photo height front", this.m_cCameraView.getPhotoSizeFront().y));
        this.m_cCameraView.setPhotoInVideoSizeFront(cPrefs.getInt("Photo in video width front", this.m_cCameraView.getPhotoInVideoSizeFront().x), cPrefs.getInt("Photo in video height front", this.m_cCameraView.getPhotoInVideoSizeFront().y));
        this.m_cCameraView.setAntiBanding(cPrefs.getString("Anti banding", this.m_cCameraView.getAntiBanding()));
        this.m_cCameraView.setFocusMode(cPrefs.getString("Focus mode", this.m_cCameraView.getFocusMode()));
        this.m_cCameraView.setISO(cPrefs.getString("ISO", "auto"));
        this.m_cCameraView.setAutoExposure(cPrefs.getString("Auto exposure", this.m_cCameraView.getAutoExposure()));
        this.m_cCameraView.setAudioBitRate(BitrateSampleRateHelper.getNearestAudioBitrate(cPrefs.getInt("Audio bitrate", this.m_cCameraView.getAudioBitRate())));
        this.m_cCameraView.setSamplingRate(BitrateSampleRateHelper.getNearestAudioSamplerate(cPrefs.getInt("Audio samplingrate", this.m_cCameraView.getSamplingRate())));
        this.m_cCameraView.setFrameRates(cPrefs.getInt("Frame rates", this.m_cCameraView.getFrameRates()));
        this.m_cCameraView.setAudioEncoder(cPrefs.getInt("Audio encoder", this.m_cCameraView.getAudioEncoder()));
        this.m_cCameraView.setFormat(cPrefs.getInt("Format", this.m_cCameraView.getFormat()));
        this.m_cCameraView.setShutterOnScreenTouch(cPrefs.getBoolean("Shutter on screen touch", this.m_cCameraView.getShutterOnScreenTouch()));
        this.m_cCameraView.setTurnOffSounds(cPrefs.getBoolean("Turn off sounds", this.m_cCameraView.getTurnOffSounds()));
        this.m_cCameraView.setRunOnCameraPress(cPrefs.getBoolean("Run on camera button pressed", this.m_cCameraView.getRunOnCameraPress()));
        this.m_cCameraView.setUseGPSEXIF(cPrefs.getBoolean("Save GPS in EXIF", this.m_cCameraView.getUseGPSEXIF()));
        this.m_cCameraView.setAudioSource(cPrefs.getInt("Audio source", this.m_cCameraView.getAudioSource()));
        this.m_cCameraView.setContrast(cPrefs.getString("Contrast", this.m_cCameraView.getContrast()));
        this.m_cCameraView.setBrightness(cPrefs.getString("Brightness", this.m_cCameraView.getBrightness()));
        this.m_cCameraView.setSaturation(cPrefs.getString("Saturation", this.m_cCameraView.getSaturation()));
        this.m_cCameraView.setSharpness(cPrefs.getString("Sharpness", this.m_cCameraView.getSharpness()));
        this.m_cCameraView.setAllowSensorFocus(cPrefs.getBoolean("Allow sensor focus", this.m_cCameraView.getAllowSensorFocus()));
        DebugLog.m_bDebug = cPrefs.getBoolean("Save debug log", DebugLog.m_bDebug);
        this.m_cCameraView.setPictureFormat(cPrefs.getInt("Picture format", this.m_cCameraView.getPictureFormat()));
        this.m_cCameraView.setOverlayDateTime(cPrefs.getBoolean("Overlay date and time", this.m_cCameraView.getOverlayDateTime()));
        this.m_cCameraView.setSaveInIMAGEVIDEO(cPrefs.getBoolean("Format filename", this.m_cCameraView.getSaveInIMAGEVIDEO()));
        this.m_cCameraView.setAudioChannels(cPrefs.getInt("Audio channels", this.m_cCameraView.getAudioChannels()));
        this.m_cCameraView.setForcedAF(cPrefs.getBoolean("Forced AF", this.m_cCameraView.getForcedAF()));
        this.m_cCameraView.m_nShutterKeyCode = cPrefs.getInt("Shutter keycode", this.m_cCameraView.m_nShutterKeyCode);
        this.m_cCameraView.m_nFocusKeyCode = cPrefs.getInt("Focus keycode", this.m_cCameraView.m_nFocusKeyCode);
        this.m_cCameraView.m_bUseMaxBrightness = cPrefs.getBoolean("Use max brightness", this.m_cCameraView.m_bUseMaxBrightness);
        this.m_cCameraView.setImageIndex(cPrefs.getInt("Last image index", this.m_cCameraView.getImageIndex()));
        this.m_cCameraView.setVideoIndex(cPrefs.getInt("Last video index", this.m_cCameraView.getVideoIndex()));
        this.m_cCameraView.m_bLongClickShutter = cPrefs.getBoolean("Long click shutter", this.m_cCameraView.m_bLongClickShutter);
        this.m_cCameraView.setJPGQuality(cPrefs.getInt("JPEG quality", this.m_cCameraView.getJPGQuality()));
        this.m_cCameraView.setExposure(cPrefs.getInt("Exposure compensation", this.m_cCameraView.getExposure()));
        this.m_cCameraView.setAutoRotate(cPrefs.getBoolean("Auto rotate", true));
        this.m_cCameraView.m_cGridView.setShowGrid(cPrefs.getBoolean("Show grid", this.m_cCameraView.m_cGridView.getShowGrid()));
        this.m_bAntiShake = cPrefs.getBoolean("Antishake mode", this.m_bAntiShake);
        this.m_cCameraView.setMaxDelayedFiles(cPrefs.getInt("Max delayed saving files", this.m_cCameraView.getMaxDelayedFiles()));
        this.m_cCameraView.m_nPreviewTime = cPrefs.getInt("Preview", this.m_cCameraView.m_nPreviewTime);
        this.m_cCameraView.m_strOverlayFont = cPrefs.getString("Overlay font", this.m_cCameraView.m_strOverlayFont);
        this.m_cCameraView.m_nOverlayColor = cPrefs.getInt("Overlay font color", this.m_cCameraView.m_nOverlayColor);
        this.m_cCameraView.m_bOverlay12HourFormat = cPrefs.getBoolean("Overlay 12-hour format", this.m_cCameraView.m_bOverlay12HourFormat);
        this.m_cCameraView.m_bOverlayGPS = cPrefs.getBoolean("Overlay add GPS", this.m_cCameraView.m_bOverlayGPS);
        this.m_cCameraView.m_strOverlayAddText = cPrefs.getString("Overlay additional text", this.m_cCameraView.m_strOverlayAddText);
        this.m_cCameraView.m_nOverlayFontSize = cPrefs.getInt("Overlay font size", this.m_cCameraView.m_nOverlayFontSize);
        this.m_cCameraView.m_nOverlayGravity = cPrefs.getInt("Overlay gravity", this.m_cCameraView.m_nOverlayGravity);
        this.m_cCameraView.m_nOverlayDateTimeFormat = cPrefs.getInt("Overlay datetime format", this.m_cCameraView.m_nOverlayDateTimeFormat);
        this.m_cCameraView.setVideoStab(cPrefs.getBoolean("Video stabilization", this.m_cCameraView.getVideoStab()));
        this.m_cCameraView.m_bVibrate = cPrefs.getBoolean("Vibrate", this.m_cCameraView.m_bVibrate);
        this.m_cCameraView.m_bFlashOnFocus = cPrefs.getBoolean("Flash on focus", this.m_cCameraView.m_bFlashOnFocus);
        CameraView.setFolder(getApplicationContext(), cPrefs.getString("Folder", CameraView.getFolder()));
        try {
            DebugLog.WriteDebug("Manufacturer=" + InvokeHelper.GetStaticFieldValue(Build.class, "MANUFACTURER").toString());
            DebugLog.WriteDebug("Model=" + InvokeHelper.GetStaticFieldValue(Build.class, "MODEL").toString());
        } catch (Exception e) {
        }
        this.m_cCameraView.m_strScript = cPrefs.getString("Camera script", this.m_cCameraView.m_strScript);
        this.m_cCameraView.m_bMTKDevice = cPrefs.getBoolean("MTK 65xx device", this.m_cCameraView.m_bMTKDevice);
        this.m_cCameraView.setAELock(cPrefs.getBoolean("AE lock", this.m_cCameraView.getAELock()));
        this.m_cCameraView.setWBLock(cPrefs.getBoolean("WB lock", this.m_cCameraView.getWBLock()));
        this.m_cCameraView.m_bShowStatus = cPrefs.getBoolean("Show status", this.m_cCameraView.m_bShowStatus);
        this.m_cCameraView.setExposureFront(cPrefs.getInt("Exposure compensation front", this.m_cCameraView.getExposureFront()));
        this.m_cCameraView.setWBFront(cPrefs.getString("White balance front", this.m_cCameraView.getWBFront()));
        this.m_cCameraView.setContrastFront(cPrefs.getString("Contrast front", this.m_cCameraView.getContrastFront()));
        this.m_cCameraView.setBrightnessFront(cPrefs.getString("Brightness front", this.m_cCameraView.getBrightnessFront()));
        this.m_cCameraView.setSaturationFront(cPrefs.getString("Saturation front", this.m_cCameraView.getSaturationFront()));
        this.m_cCameraView.setSharpnessFront(cPrefs.getString("Sharpness front", this.m_cCameraView.getSharpnessFront()));
        this.m_cCameraView.setFlashModeFront(cPrefs.getString("Flash mode front", this.m_cCameraView.getFlashModeFront()));
        this.m_cCameraView.setSceneModeFront(cPrefs.getString("Scene mode front", this.m_cCameraView.getSceneModeFront()));
        this.m_cCameraView.setEffectFront(cPrefs.getString("Color effect front", this.m_cCameraView.getEffectFront()));
        this.m_cCameraView.setAntiBandingFront(cPrefs.getString("Anti banding front", this.m_cCameraView.getAntiBandingFront()));
        this.m_cCameraView.setFocusModeFront(cPrefs.getString("Focus mode front", this.m_cCameraView.getFocusModeFront()));
        this.m_cCameraView.setISOFront(cPrefs.getString("ISO front", this.m_cCameraView.getISOFront()));
        this.m_cCameraView.setAutoExposureFront(cPrefs.getString("Auto exposure front", this.m_cCameraView.getAutoExposureFront()));
        this.m_nAutoTimerSeconds = cPrefs.getInt("Autoshutter timer", this.m_nAutoTimerSeconds);
        this.m_cCameraView.m_fSlowMotionModule = cPrefs.getFloat("Slow motion", this.m_cCameraView.m_fSlowMotionModule);
        this.m_cCameraView.m_bRestartCamera = cPrefs.getBoolean("Restart camera on video", this.m_cCameraView.m_bRestartCamera);
        this.m_cCameraView.m_bFullSweep = cPrefs.getBoolean("Pano full angle", this.m_cCameraView.m_bFullSweep);
        try {
            CameraView.m_treeUri = Uri.parse(cPrefs.getString("Tree URI", null));
        } catch (Exception e2) {
        }
        this.m_cCameraView.SetAGCOff(cPrefs.getBoolean("AGC off", this.m_cCameraView.IsAGCOff()));
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public void onCameraViewAction(int nAction) {
        switch (nAction) {
            case 1:
                if (this.m_cTimerRec != null) {
                    this.m_cTimerRec.cancel();
                }
                this.m_cTimerRec = new Timer();
                this.m_nTimeRecord = 0;
                this.m_cTimerRec.scheduleAtFixedRate(new TimerTask() { // from class: com.android.camera.MainWindow.11
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        if (!MainWindow.this.m_cCameraView.IsPaused()) {
                            MainWindow.this.m_nTimeRecord++;
                        }
                        MainWindow.this.runOnUiThread(MainWindow.this.m_cUpdateRecTimeUI);
                    }
                }, 0L, 1000L);
                Toast.makeText(this, (int) R.string.ToastRecordStarted, 0).show();
                if (this.m_cCameraView.m_nSDK < 14) {
                    this.m_cZoomProgress.setVisibility(8);
                }
                this.m_btnPauseResume.setImageResource(R.drawable.pause_normal);
                this.m_btnRecord.setImageResource(R.drawable.stop);
                UpdateButtons();
                AdjustAspectRatio();
                return;
            case 2:
                if (this.m_cTimerRec != null) {
                    this.m_cTimerRec.cancel();
                }
                this.m_cTimerRec = null;
                ((View) this.m_btnPauseResume.getParent()).setVisibility(4);
                Toast.makeText(this, (int) R.string.ToastRecordStopped, 0).show();
                this.m_cCameraView.StartPreview(false);
                this.m_cZoomProgress.setProgress(0);
                this.m_strLastFile = this.m_cCameraView.m_strFileName;
                if (!isFinishing()) {
                    ShowPreviewScreen(this.m_cCameraView.m_nPreviewTime > 0);
                }
                this.m_btnRecord.setImageResource(R.drawable.camcorder);
                UpdateButtons();
                AdjustAspectRatio();
                return;
            case 3:
                Toast.makeText(this, (int) R.string.ToastRecordFailed, 0).show();
                UpdateButtons();
                return;
            case 4:
                Toast.makeText(this, (int) R.string.ToastPreviewFailed, 1).show();
                UpdateButtons();
                return;
            case 7:
                Toast.makeText(this, (int) R.string.ToastInsufficientSize, 0).show();
                break;
            case 8:
                runOnUiThread(new Runnable() { // from class: com.android.camera.MainWindow.12
                    @Override // java.lang.Runnable
                    public void run() {
                        MainWindow.this.m_cBusyIndicator.setVisibility(4);
                    }
                });
                this.m_cHandler.postDelayed(this.m_cUpdateBusy, 500L);
                UpdateButtons();
                return;
            case 9:
                runOnUiThread(new Runnable() { // from class: com.android.camera.MainWindow.13
                    @Override // java.lang.Runnable
                    public void run() {
                        MainWindow.this.m_cBusyIndicator.setVisibility(0);
                    }
                });
                UpdateButtons();
                return;
            case 10:
                this.m_cHandler.removeCallbacks(this.m_cHideFocusRect);
                this.m_cCameraView.m_cGridView.setShowFocus(3);
                this.m_cHandler.postDelayed(this.m_cHideFocusRect, 500L);
                return;
            case 11:
                this.m_btnPauseResume.setImageResource(R.drawable.pause_pressed);
                Toast.makeText(this, (int) R.string.ToastRecordPaused, 0).show();
                UpdateButtons();
                return;
            case 12:
                this.m_btnPauseResume.setImageResource(R.drawable.pause_normal);
                Toast.makeText(this, (int) R.string.ToastRecordResumed, 0).show();
                UpdateButtons();
                return;
            case 13:
                if (this.m_cCameraView.m_nPreviewTime == 0 && !this.m_cCameraView.IsStarted()) {
                    this.m_cCameraView.StartPreview(false);
                    return;
                }
                return;
            case 14:
                this.m_cHandler.removeCallbacks(this.m_cHideFocusRect);
                this.m_cCameraView.m_cGridView.setShowFocus(2);
                this.m_cHandler.postDelayed(this.m_cHideFocusRect, 500L);
                return;
            case 15:
                if (this.m_btnCapture.isPressed()) {
                    Log.e("CameraView", "Making new photo");
                    this.m_cCameraView.CapturePhoto(true);
                    return;
                }
                Log.e("CameraView", "Stop making photos");
                return;
            case CameraView.ICSBURSTPHOTO_CAPTURED /* 16 */:
                if (this.m_btnCapture.isPressed()) {
                    Log.e("CameraView", "Making new photo");
                    this.m_cCameraView.TakePictureICS(true);
                    return;
                }
                Log.e("CameraView", "Stop making photos");
                return;
            case CameraView.MANUALFOCUS_SET /* 17 */:
                this.m_btnAFReset.setVisibility(0);
                return;
            case CameraView.FOCUS_RESET /* 18 */:
                this.m_btnAFReset.setVisibility(4);
                return;
        }
        UpdateControls();
        UpdateButtons();
    }

    public void UpdateControls() {
        String strText;
        UpdateSettingsTab();
        this.m_cZoomProgress.setMax(this.m_cCameraView.getMaxZoom());
        boolean bFrontCamera = this.m_cCameraView.IsFrontCamera();
        List<String> strArAB = this.m_cCameraView.getSupportedAntiBanding();
        if (strArAB == null || strArAB.size() == 0) {
            this.m_btnAB.setVisibility(8);
        } else {
            this.m_btnAB.setVisibility(0);
            ((TextView) this.m_btnAB.findViewById(16908309)).setText(bFrontCamera ? this.m_cCameraView.getAntiBandingFront() : this.m_cCameraView.getAntiBanding());
        }
        List<String> strArAutoExposure = this.m_cCameraView.getSupportedAutoExposures();
        if (strArAutoExposure == null || strArAutoExposure.size() == 0) {
            this.m_btnAutoExposure.setVisibility(8);
        } else {
            this.m_btnAutoExposure.setVisibility(0);
            ((TextView) this.m_btnAutoExposure.findViewById(16908309)).setText(bFrontCamera ? this.m_cCameraView.getAutoExposureFront() : this.m_cCameraView.getAutoExposure());
        }
        List<String> strArBrightness = this.m_cCameraView.getSupportedBrightnessValues();
        if (strArBrightness == null || strArBrightness.size() == 0) {
            this.m_btnBrightness.setVisibility(8);
        } else {
            this.m_btnBrightness.setVisibility(0);
            ((TextView) this.m_btnBrightness.findViewById(16908309)).setText(bFrontCamera ? this.m_cCameraView.getBrightnessFront() : this.m_cCameraView.getBrightness());
        }
        List<String> strArContrast = this.m_cCameraView.getSupportedContrastValues();
        if (strArContrast == null || strArContrast.size() == 0) {
            this.m_btnContrast.setVisibility(8);
        } else {
            this.m_btnContrast.setVisibility(0);
            ((TextView) this.m_btnContrast.findViewById(16908309)).setText(bFrontCamera ? this.m_cCameraView.getContrastFront() : this.m_cCameraView.getContrast());
        }
        List<String> strArSaturation = this.m_cCameraView.getSupportedSaturationValues();
        if (strArSaturation == null || strArSaturation.size() == 0) {
            this.m_btnSaturation.setVisibility(8);
        } else {
            this.m_btnSaturation.setVisibility(0);
            ((TextView) this.m_btnSaturation.findViewById(16908309)).setText(bFrontCamera ? this.m_cCameraView.getSaturationFront() : this.m_cCameraView.getSaturation());
        }
        List<String> strArSharpness = this.m_cCameraView.getSupportedSharpnessValues();
        if (strArSharpness == null || strArSharpness.size() == 0) {
            this.m_btnSharpness.setVisibility(8);
        } else {
            this.m_btnSharpness.setVisibility(0);
            ((TextView) this.m_btnSharpness.findViewById(16908309)).setText(bFrontCamera ? this.m_cCameraView.getSharpnessFront() : this.m_cCameraView.getSharpness());
        }
        List<String> strArExposures = this.m_cCameraView.getSupportedExposure();
        if (strArExposures == null || strArExposures.size() == 0) {
            this.m_btnExposure.setVisibility(8);
        } else {
            this.m_btnExposure.setVisibility(0);
            ((TextView) this.m_btnExposure.findViewById(16908309)).setText(String.valueOf(bFrontCamera ? this.m_cCameraView.getExposureFront() : this.m_cCameraView.getExposure()));
        }
        List<String> strArISO = this.m_cCameraView.getSupportedISOValues();
        if (strArISO == null || strArISO.size() == 0) {
            this.m_btnISO.setVisibility(8);
        } else {
            this.m_btnISO.setVisibility(0);
            ((TextView) this.m_btnISO.findViewById(16908309)).setText(bFrontCamera ? this.m_cCameraView.getISOFront() : this.m_cCameraView.getISO());
        }
        List<String> strArFocusModes = this.m_cCameraView.getSupportedFocusMode();
        if (strArFocusModes == null || strArFocusModes.size() == 0) {
            this.m_btnFocus.setVisibility(8);
        } else {
            this.m_btnFocus.setVisibility(0);
            ((TextView) this.m_btnFocus.findViewById(16908309)).setText(bFrontCamera ? this.m_cCameraView.getFocusModeFront() : this.m_cCameraView.getFocusMode());
        }
        List<String> strArSM = this.m_cCameraView.getSupportedScenes();
        if (strArSM == null || strArSM.size() == 0) {
            this.m_btnSM.setVisibility(8);
        } else {
            this.m_btnSM.setVisibility(0);
            ((TextView) this.m_btnSM.findViewById(16908309)).setText(bFrontCamera ? this.m_cCameraView.getSceneModeFront() : this.m_cCameraView.getSceneMode());
        }
        List<String> strArCE = this.m_cCameraView.getSupportedCE();
        if (strArCE == null || strArCE.size() == 0) {
            this.m_btnCE.setVisibility(8);
        } else {
            this.m_btnCE.setVisibility(0);
            ((TextView) this.m_btnCE.findViewById(16908309)).setText(bFrontCamera ? this.m_cCameraView.getEffectFront() : this.m_cCameraView.getEffect());
        }
        List<String> strArWB = this.m_cCameraView.getSupportedWB();
        if (strArWB == null || strArWB.size() == 0) {
            this.m_btnWB.setVisibility(8);
        } else {
            this.m_btnWB.setVisibility(0);
            ((TextView) this.m_btnWB.findViewById(16908309)).setText(bFrontCamera ? this.m_cCameraView.getWBFront() : this.m_cCameraView.getWB());
        }
        List<String> strArFM = this.m_cCameraView.getSupportedFM();
        if (strArFM == null || strArFM.size() == 0) {
            this.m_btnFlashMode.setImageResource(R.drawable.flash_off_normal);
            this.m_btnFlashMode.setVisibility(4);
        } else {
            this.m_btnFlashMode.setVisibility(0);
            String strFM = bFrontCamera ? this.m_cCameraView.getFlashModeFront() : this.m_cCameraView.getFlashMode();
            if (strFM != null) {
                if (strFM.equalsIgnoreCase("auto")) {
                    this.m_btnFlashMode.setImageResource(R.drawable.flash_auto);
                }
                if (strFM.equalsIgnoreCase("on")) {
                    this.m_btnFlashMode.setImageResource(R.drawable.flash_on);
                }
                if (strFM.equalsIgnoreCase("off")) {
                    this.m_btnFlashMode.setImageResource(R.drawable.flash_off);
                }
                if (strFM.equalsIgnoreCase("torch") || strFM.equalsIgnoreCase("tourch")) {
                    this.m_btnFlashMode.setImageResource(R.drawable.flash_torch);
                }
            } else {
                this.m_btnFlashMode.setImageResource(R.drawable.flash_off_normal);
                this.m_btnFlashMode.setVisibility(4);
            }
        }
        Resources cRes = getResources();
        if (bFrontCamera) {
            this.m_btnPhotoRes.setVisibility(8);
            this.m_btnVideoRes.setVisibility(8);
            this.m_btnPhotoInVideoRes.setVisibility(8);
            this.m_btnPhotoResFront.setVisibility(0);
            this.m_btnVideoResFront.setVisibility(0);
            if (this.m_cCameraView.CanCaptureWhileRecording() && !this.m_bVideoCaptureIntent) {
                this.m_btnPhotoInVideoResFront.setVisibility(0);
            } else {
                this.m_btnPhotoInVideoResFront.setVisibility(8);
            }
        } else {
            this.m_btnPhotoRes.setVisibility(0);
            this.m_btnVideoRes.setVisibility(0);
            if (this.m_cCameraView.CanCaptureWhileRecording() && !this.m_bVideoCaptureIntent) {
                this.m_btnPhotoInVideoRes.setVisibility(0);
            } else {
                this.m_btnPhotoInVideoRes.setVisibility(8);
            }
            this.m_btnPhotoResFront.setVisibility(8);
            this.m_btnVideoResFront.setVisibility(8);
            this.m_btnPhotoInVideoResFront.setVisibility(8);
        }
        ((TextView) this.m_btnPhotoRes.findViewById(16908309)).setText(String.format("%d x %d", Integer.valueOf(this.m_cCameraView.getPhotoSize().x), Integer.valueOf(this.m_cCameraView.getPhotoSize().y)));
        ((TextView) this.m_btnPhotoResFront.findViewById(16908309)).setText(String.format("%d x %d", Integer.valueOf(this.m_cCameraView.getPhotoSizeFront().x), Integer.valueOf(this.m_cCameraView.getPhotoSizeFront().y)));
        ((TextView) this.m_btnPhotoMode.findViewById(16908309)).setText(cRes.getStringArray(R.array.PhotoModes)[this.m_cCameraView.getPhotoMode()]);
        ((TextView) this.m_btnVideoRes.findViewById(16908309)).setText(String.format("%d x %d", Integer.valueOf(this.m_cCameraView.getResolution().x), Integer.valueOf(this.m_cCameraView.getResolution().y)));
        ((TextView) this.m_btnPhotoInVideoRes.findViewById(16908309)).setText(String.format("%d x %d", Integer.valueOf(this.m_cCameraView.getPhotoInVideoSize().x), Integer.valueOf(this.m_cCameraView.getPhotoInVideoSize().y)));
        ((TextView) this.m_btnVideoResFront.findViewById(16908309)).setText(String.format("%d x %d", Integer.valueOf(this.m_cCameraView.getResolutionFront().x), Integer.valueOf(this.m_cCameraView.getResolutionFront().y)));
        ((TextView) this.m_btnPhotoInVideoResFront.findViewById(16908309)).setText(String.format("%d x %d", Integer.valueOf(this.m_cCameraView.getPhotoInVideoSizeFront().x), Integer.valueOf(this.m_cCameraView.getPhotoInVideoSizeFront().y)));
        ((TextView) this.m_btnVideoEncoder.findViewById(16908309)).setText(cRes.getStringArray(R.array.VideoEncoder)[this.m_cCameraView.getEncoder()]);
        ((TextView) this.m_btnVideoFormat.findViewById(16908309)).setText(cRes.getStringArray(R.array.VideoFormat)[this.m_cCameraView.getFormat() - 1]);
        ((TextView) this.m_btnJPGQuality.findViewById(16908309)).setText(String.valueOf(this.m_cCameraView.getJPGQuality()));
        int nBitRate = this.m_cCameraView.getBitRate();
        if (bFrontCamera) {
            nBitRate = this.m_cCameraView.getBitRateFront();
        }
        if (nBitRate >= 1000000) {
            ((TextView) this.m_btnVideoBitRate.findViewById(16908309)).setText(String.format("%d Mbit", Integer.valueOf(nBitRate / 1000000)));
        } else {
            ((TextView) this.m_btnVideoBitRate.findViewById(16908309)).setText(String.format("%d Kbit", Integer.valueOf(nBitRate / 1000)));
        }
        if (this.m_cCameraView.getFrameRates() == 0) {
            ((TextView) this.m_btnVideoFPS.findViewById(16908309)).setText(R.string.Auto);
        } else {
            ((TextView) this.m_btnVideoFPS.findViewById(16908309)).setText(String.format("%d", Integer.valueOf(this.m_cCameraView.getFrameRates())));
        }
        if (this.m_cCameraView.getAudioSource() < 8) {
            ((TextView) this.m_btnAudioSource.findViewById(16908309)).setText(cRes.getStringArray(R.array.AudioSource)[this.m_cCameraView.getAudioSource()]);
        }
        if (this.m_cCameraView.getAudioEncoder() < 4) {
            ((TextView) this.m_btnAudioEncoder.findViewById(16908309)).setText(cRes.getStringArray(R.array.AudioEncoder)[this.m_cCameraView.getAudioEncoder()]);
        }
        if (this.m_cCameraView.getAudioEncoder() == 3) {
            this.m_btnAudioSampleRate.setVisibility(0);
            this.m_btnAudioBitRate.setVisibility(0);
        } else {
            this.m_btnAudioSampleRate.setVisibility(8);
            this.m_btnAudioBitRate.setVisibility(8);
        }
        ((TextView) this.m_btnAudioSampleRate.findViewById(16908309)).setText(String.format("%d", Integer.valueOf(this.m_cCameraView.getSamplingRate())));
        ((TextView) this.m_btnAudioBitRate.findViewById(16908309)).setText(String.format("%d", Integer.valueOf(this.m_cCameraView.getAudioBitRate())));
        try {
            PackageInfo cPackInfo = getPackageManager().getPackageInfo(getPackageName(), 64);
            if (!this.m_cCameraView.getMainWindow().CheckRPN()) {
                strText = String.valueOf("") + cRes.getString(R.string.LabelFree) + " " + cPackInfo.versionName;
            } else {
                strText = String.valueOf("") + cRes.getString(R.string.LabelRegistered) + " " + cPackInfo.versionName;
            }
            ((TextView) this.m_btnRegInfo.findViewById(16908309)).setText(strText);
        } catch (Exception e) {
        }
        this.m_cCheckBoxMTKDevice.setChecked(this.m_cCameraView.m_bMTKDevice);
        this.m_cCheckBoxEXIF.setChecked(this.m_cCameraView.getUseGPSEXIF());
        this.m_cCheckBoxDateTime.setChecked(this.m_cCameraView.getOverlayDateTime());
        this.m_cCheckBoxAutoRotate.setChecked(this.m_cCameraView.getAutoRotate());
        this.m_cCheckBoxAntiShake.setChecked(this.m_bAntiShake);
        this.m_cCheckBoxDelayedSave.setChecked(this.m_cCameraView.getMaxDelayedFiles() > 1);
        this.m_cCheckBoxVideoStab.setChecked(this.m_cCameraView.getVideoStab());
        this.m_cCheckBoxAGCOff.setChecked(this.m_cCameraView.IsAGCOff());
        this.m_cCheckBoxShowStatus.setChecked(this.m_cCameraView.m_bShowStatus);
        this.m_cCheckBoxRestartCamera.setChecked(this.m_cCameraView.m_bRestartCamera);
        if (this.m_cCameraView.getAudioChannels() == 2) {
            this.m_cCheckBoxStereoSound.setChecked(true);
        } else {
            this.m_cCheckBoxStereoSound.setChecked(false);
        }
        if (!this.m_cCameraView.IsStarted()) {
            this.m_cTextViewRecord.setText("");
            this.m_cCameraView.m_cGridView.setShowCross(this.m_bAntiShake);
        } else {
            this.m_cCameraView.m_cGridView.setShowCross(false);
        }
        switch (this.m_cCameraView.getEncoder()) {
            case 1:
                this.m_cTextViewVideoEncoder.setText("H.263");
                break;
            case 2:
                this.m_cTextViewVideoEncoder.setText("H.264");
                break;
            case 3:
                this.m_cTextViewVideoEncoder.setText("MPEG4");
                break;
            default:
                this.m_cTextViewVideoEncoder.setText("Default");
                break;
        }
        int nBitRate2 = this.m_cCameraView.getBitRate();
        if (nBitRate2 < 1000000) {
            this.m_cTextViewVideoBitRate.setText(String.format("%dKbit", Integer.valueOf(nBitRate2 / 1000)));
        } else {
            this.m_cTextViewVideoBitRate.setText(String.format("%dMbit", Integer.valueOf(nBitRate2 / 1000000)));
        }
        switch (this.m_cCameraView.getAudioEncoder()) {
            case 1:
                this.m_cTextViewAudioEncoder.setText("AMR_NB");
                break;
            case 2:
                this.m_cTextViewAudioEncoder.setText("AMR_WB");
                break;
            case 3:
                this.m_cTextViewAudioEncoder.setText("AAC");
                break;
            default:
                this.m_cTextViewAudioEncoder.setText("Default");
                break;
        }
        int nAudioBitRate = this.m_cCameraView.getAudioBitRate();
        if (nAudioBitRate > 0) {
            this.m_cTextViewAudioBitRate.setText(String.format("%d", Integer.valueOf(nAudioBitRate)));
        } else {
            this.m_cTextViewAudioBitRate.setText("Default");
        }
        if (this.m_cCameraView.getFormat() == 1) {
            this.m_cTextViewFormat.setText("3GPP");
        } else {
            this.m_cTextViewFormat.setText("MP4");
        }
        int nFPS = this.m_cCameraView.getFrameRates();
        if (nFPS == 0) {
            this.m_cTextViewFPS.setText("Auto");
        } else {
            this.m_cTextViewFPS.setText(String.format("%dFPS", Integer.valueOf(this.m_cCameraView.getFrameRates())));
        }
        switch (this.m_cCameraView.getPhotoMode()) {
            case 0:
                this.m_btnCapture.setImageResource(R.drawable.camera);
                this.m_cLinearFullAngle.setVisibility(8);
                break;
            case 1:
                this.m_btnCapture.setImageResource(R.drawable.serial);
                this.m_cLinearFullAngle.setVisibility(8);
                break;
            case 2:
                this.m_cLinearFullAngle.setVisibility(0);
                this.m_cCheckBoxFullAngle.setOnCheckedChangeListener(null);
                this.m_cCheckBoxFullAngle.setChecked(this.m_cCameraView.m_bFullSweep);
                this.m_cCheckBoxFullAngle.setOnCheckedChangeListener(this);
                if (this.m_cCameraView.GetPanoMode() == 1) {
                    this.m_btnCapture.setImageResource(R.drawable.panorama_stop);
                    break;
                } else {
                    this.m_btnCapture.setImageResource(R.drawable.panorama_start);
                    break;
                }
        }
        ((TextView) this.m_btnAutoShutter.findViewById(16908309)).setText(String.format("%d", Integer.valueOf(this.m_nAutoTimerSeconds)));
        if (this.m_cCameraView.CanSlowMotion()) {
            this.m_btnSlowMotion.setVisibility(0);
            int nSelItem = 3;
            if (this.m_cCameraView.m_fSlowMotionModule <= 0.25f) {
                nSelItem = 0;
            } else if (this.m_cCameraView.m_fSlowMotionModule <= 0.33f) {
                nSelItem = 1;
            } else if (this.m_cCameraView.m_fSlowMotionModule <= 0.5f) {
                nSelItem = 2;
            } else if (this.m_cCameraView.m_fSlowMotionModule >= 4.0f) {
                nSelItem = 6;
            } else if (this.m_cCameraView.m_fSlowMotionModule >= 3.0f) {
                nSelItem = 5;
            } else if (this.m_cCameraView.m_fSlowMotionModule >= 2.0f) {
                nSelItem = 4;
            }
            ((TextView) this.m_btnSlowMotion.findViewById(16908309)).setText(cRes.getStringArray(R.array.SlowfastMotionMultiply)[nSelItem]);
        } else {
            this.m_btnSlowMotion.setVisibility(8);
        }
        AdjustAspectRatio();
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == 25 || keyCode == 24) {
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            if (this.m_cListViewParamsWnd.getVisibility() == 0) {
                this.m_cListViewParamsWnd.setVisibility(8);
                this.m_cViewIncludeCameraSettings.setVisibility(0);
                return true;
            } else if (IsCtrlPanelShowing()) {
                HideCtrlPanel();
                return true;
            } else if (this.m_bPreviewMode) {
                ShowNormalScreen();
                return true;
            } else if (this.m_cCameraView.IsStarted()) {
                this.m_cCameraView.StopRecord();
                return true;
            } else {
                long lTime = System.currentTimeMillis();
                if (lTime - this.m_lLastBackPressTime < 2000) {
                    finish();
                    return false;
                }
                Toast.makeText(this, (int) R.string.PressBack, 0).show();
                this.m_lLastBackPressTime = lTime;
                return true;
            }
        } else if (keyCode == 82) {
            ToggleSettingWnd();
            return true;
        } else if (keyCode == this.m_cCameraView.m_nFocusKeyCode && !IsCtrlPanelShowing()) {
            if (!this.m_cCameraView.isBusy() && event.getRepeatCount() == 0 && this.m_cCameraView.GetPanoMode() == 0) {
                if (this.m_cCameraView.m_nFocusKeyCode == this.m_cCameraView.m_nShutterKeyCode) {
                    if (this.m_cCameraView.IsStarted()) {
                        this.m_cCameraView.StopRecord();
                        return true;
                    }
                    boolean bLastForceAF = this.m_cCameraView.getForcedAF();
                    this.m_cCameraView.setForcedAF(true);
                    this.m_cCameraView.CapturePhoto(false);
                    this.m_cCameraView.setForcedAF(bLastForceAF);
                    return true;
                }
                this.m_cCameraView.MakeFocus(false);
                return true;
            }
            return true;
        } else if (keyCode == this.m_cCameraView.m_nShutterKeyCode && !IsCtrlPanelShowing() && this.m_cCameraView.GetPanoMode() == 0) {
            if (this.m_cCameraView.isBusy() || event.getRepeatCount() != 0) {
                return true;
            }
            if (this.m_cCameraView.IsStarted()) {
                this.m_cCameraView.StopRecord();
                return true;
            }
            this.m_cCameraView.CapturePhoto(false);
            return true;
        } else if (keyCode == 25 && !IsCtrlPanelShowing() && this.m_cCameraView.GetPanoMode() == 0) {
            try {
                this.m_cZoomProgress.setProgress(this.m_cZoomProgress.getProgress() - 1);
                this.m_cCameraView.setZoomValue(this.m_cZoomProgress.getProgress() + 1);
                return true;
            } catch (Exception ex) {
                ex.printStackTrace();
                return true;
            }
        } else if (keyCode == 24 && !IsCtrlPanelShowing() && this.m_cCameraView.GetPanoMode() == 0) {
            try {
                this.m_cZoomProgress.setProgress(this.m_cZoomProgress.getProgress() + 1);
                this.m_cCameraView.setZoomValue(this.m_cZoomProgress.getProgress() + 1);
                return true;
            } catch (Exception ex2) {
                ex2.printStackTrace();
                return true;
            }
        } else if (keyCode == 21 || keyCode == 22 || keyCode == 19 || keyCode == 20) {
            return true;
        } else {
            return super.onKeyDown(keyCode, event);
        }
    }

    private void ToggleSettingWnd() {
        if (!this.m_cCameraView.isBusy()) {
            if (IsCtrlPanelShowing()) {
                HideCtrlPanel();
            } else if (this.m_cListViewParamsWnd.getVisibility() != 0) {
                ShowCtrlPanel();
            }
        }
    }

    private void SelectWhiteBalanceDlg() {
        final boolean bFront = this.m_cCameraView.IsFrontCamera();
        String strWB = bFront ? this.m_cCameraView.getWBFront() : this.m_cCameraView.getWB();
        List<String> strArWB = this.m_cCameraView.getSupportedWB();
        if (strArWB != null && strArWB.size() != 0) {
            String[] strArray = new String[strArWB.size()];
            int nSelItem = -1;
            for (int n = 0; n < strArWB.size(); n++) {
                if (strWB.equalsIgnoreCase(strArWB.get(n))) {
                    nSelItem = n;
                }
                strArray[n] = strArWB.get(n);
            }
            this.m_cTextViewListParamsTitle.setText(R.string.WhiteBalance);
            this.m_cListViewParamsWnd.setVisibility(0);
            ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, strArray);
            this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
            this.m_cListViewParams.setChoiceMode(1);
            if (nSelItem >= 0) {
                this.m_cListViewParams.setItemChecked(nSelItem, true);
                this.m_cListViewParams.setSelection(nSelItem);
            }
            this.m_cViewIncludeCameraSettings.setVisibility(4);
            this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.14
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    List<String> strArWB2 = MainWindow.this.m_cCameraView.getSupportedWB();
                    if (bFront) {
                        MainWindow.this.m_cCameraView.setWBFront(strArWB2.get(arg2));
                    } else {
                        MainWindow.this.m_cCameraView.setWB(strArWB2.get(arg2));
                    }
                    MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                    MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                    MainWindow.this.UpdateControls();
                }
            });
        }
    }

    private void SelectColorEffectDlg() {
        final boolean bFront = this.m_cCameraView.IsFrontCamera();
        String strCE = bFront ? this.m_cCameraView.getEffectFront() : this.m_cCameraView.getEffect();
        List<String> strArCE = this.m_cCameraView.getSupportedCE();
        if (strArCE != null && strArCE.size() != 0) {
            String[] strArray = new String[strArCE.size()];
            int nSelItem = -1;
            for (int n = 0; n < strArCE.size(); n++) {
                if (strCE.equalsIgnoreCase(strArCE.get(n))) {
                    nSelItem = n;
                }
                strArray[n] = strArCE.get(n);
            }
            this.m_cTextViewListParamsTitle.setText(R.string.ColorEffect);
            this.m_cListViewParamsWnd.setVisibility(0);
            ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, strArray);
            this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
            this.m_cListViewParams.setChoiceMode(1);
            if (nSelItem >= 0) {
                this.m_cListViewParams.setItemChecked(nSelItem, true);
                this.m_cListViewParams.setSelection(nSelItem);
            }
            this.m_cViewIncludeCameraSettings.setVisibility(4);
            this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.15
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    List<String> strArCE2 = MainWindow.this.m_cCameraView.getSupportedCE();
                    if (bFront) {
                        MainWindow.this.m_cCameraView.setEffectFront(strArCE2.get(arg2));
                    } else {
                        MainWindow.this.m_cCameraView.setEffect(strArCE2.get(arg2));
                    }
                    MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                    MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                    MainWindow.this.UpdateControls();
                }
            });
        }
    }

    private void SelectSceneModeDlg() {
        final boolean bFront = this.m_cCameraView.IsFrontCamera();
        String strSM = bFront ? this.m_cCameraView.getSceneModeFront() : this.m_cCameraView.getSceneMode();
        List<String> strArSM = this.m_cCameraView.getSupportedScenes();
        if (strArSM != null && strArSM.size() != 0) {
            String[] strArray = new String[strArSM.size()];
            int nSelItem = -1;
            for (int n = 0; n < strArSM.size(); n++) {
                if (strSM.equalsIgnoreCase(strArSM.get(n))) {
                    nSelItem = n;
                }
                strArray[n] = strArSM.get(n);
            }
            this.m_cTextViewListParamsTitle.setText(R.string.SceneMode);
            this.m_cListViewParamsWnd.setVisibility(0);
            ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, strArray);
            this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
            this.m_cListViewParams.setChoiceMode(1);
            if (nSelItem >= 0) {
                this.m_cListViewParams.setItemChecked(nSelItem, true);
                this.m_cListViewParams.setSelection(nSelItem);
            }
            this.m_cViewIncludeCameraSettings.setVisibility(4);
            this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.16
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    try {
                        List<String> strArSM2 = MainWindow.this.m_cCameraView.getSupportedScenes();
                        if (bFront) {
                            MainWindow.this.m_cCameraView.setSceneModeFront(strArSM2.get(arg2));
                        } else {
                            MainWindow.this.m_cCameraView.setSceneMode(strArSM2.get(arg2));
                        }
                        MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                        MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                        MainWindow.this.UpdateControls();
                    } catch (Exception e) {
                    }
                }
            });
        }
    }

    private void SelectExposureDlg() {
        final boolean bFront = this.m_cCameraView.IsFrontCamera();
        String strExposure = String.valueOf(bFront ? this.m_cCameraView.getExposureFront() : this.m_cCameraView.getExposure());
        List<String> strArExposures = this.m_cCameraView.getSupportedExposure();
        if (strArExposures != null && strArExposures.size() != 0) {
            String[] strArray = new String[strArExposures.size()];
            int nSelItem = -1;
            for (int n = 0; n < strArExposures.size(); n++) {
                if (strExposure.equalsIgnoreCase(strArExposures.get(n))) {
                    nSelItem = n;
                }
                strArray[n] = strArExposures.get(n);
            }
            this.m_cTextViewListParamsTitle.setText(R.string.ExposureCompensation);
            this.m_cListViewParamsWnd.setVisibility(0);
            ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, strArray);
            this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
            this.m_cListViewParams.setChoiceMode(1);
            if (nSelItem >= 0) {
                this.m_cListViewParams.setItemChecked(nSelItem, true);
                this.m_cListViewParams.setSelection(nSelItem);
            }
            this.m_cViewIncludeCameraSettings.setVisibility(4);
            this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.17
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    List<String> strArExposures2 = MainWindow.this.m_cCameraView.getSupportedExposure();
                    if (bFront) {
                        MainWindow.this.m_cCameraView.setExposureFront(Integer.valueOf(strArExposures2.get(arg2)).intValue());
                    } else {
                        MainWindow.this.m_cCameraView.setExposure(Integer.valueOf(strArExposures2.get(arg2)).intValue());
                    }
                    MainWindow.this.m_cListViewParams.setItemChecked(arg2, true);
                    MainWindow.this.UpdateControls();
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void DonationDlg(boolean bShowAnyway) {
        if (!CheckRPN() || bShowAnyway) {
            Random cRandom = new Random(SystemClock.uptimeMillis());
            if (cRandom.nextInt(2) == 0 || bShowAnyway) {
                AlertDialog.Builder cBuilder = new AlertDialog.Builder(this);
                cBuilder.setTitle(R.string.DonationDlgTitle);
                cBuilder.setMessage(R.string.DonationDlgMessage);
                cBuilder.setPositiveButton(R.string.DonationDlgBtnBuy, new DialogInterface.OnClickListener() { // from class: com.android.camera.MainWindow.18
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i = new Intent("android.intent.action.VIEW");
                        Uri u = Uri.parse("market://details?id=pname:com.android.cameraPro");
                        i.setData(u);
                        try {
                            MainWindow.this.startActivity(i);
                        } catch (Exception e) {
                            DebugLog.WriteDebug("Market error: " + e.getMessage());
                        }
                    }
                });
                cBuilder.setNeutralButton(R.string.DonationDlgBtnOther, new DialogInterface.OnClickListener() { // from class: com.android.camera.MainWindow.19
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i = new Intent("android.intent.action.VIEW");
                        Uri u = Uri.parse("market://search?q=pub:RubberBigPepper");
                        i.setData(u);
                        try {
                            MainWindow.this.startActivity(i);
                        } catch (Exception e) {
                            DebugLog.WriteDebug("Market error: " + e.getMessage());
                        }
                    }
                });
                cBuilder.setNegativeButton(R.string.RegEnterKey, new DialogInterface.OnClickListener() { // from class: com.android.camera.MainWindow.20
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        RegistrationDialog cDlg = new RegistrationDialog(MainWindow.this);
                        cDlg.show();
                    }
                });
                cBuilder.create().show();
            }
        }
    }

    private void SelectAntiBandingDlg() {
        final boolean bFront = this.m_cCameraView.IsFrontCamera();
        String strAB = bFront ? this.m_cCameraView.getAntiBandingFront() : this.m_cCameraView.getAntiBanding();
        List<String> strArAB = this.m_cCameraView.getSupportedAntiBanding();
        if (strArAB != null && strArAB.size() != 0) {
            String[] strArray = new String[strArAB.size()];
            int nSelItem = -1;
            for (int n = 0; n < strArAB.size(); n++) {
                if (strAB.equalsIgnoreCase(strArAB.get(n))) {
                    nSelItem = n;
                }
                strArray[n] = strArAB.get(n);
            }
            this.m_cTextViewListParamsTitle.setText(R.string.AntiBanding);
            this.m_cListViewParamsWnd.setVisibility(0);
            ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, strArray);
            this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
            this.m_cListViewParams.setChoiceMode(1);
            if (nSelItem >= 0) {
                this.m_cListViewParams.setItemChecked(nSelItem, true);
                this.m_cListViewParams.setSelection(nSelItem);
            }
            this.m_cViewIncludeCameraSettings.setVisibility(4);
            this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.21
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    List<String> strArAB2 = MainWindow.this.m_cCameraView.getSupportedAntiBanding();
                    if (bFront) {
                        MainWindow.this.m_cCameraView.setAntiBandingFront(strArAB2.get(arg2));
                    } else {
                        MainWindow.this.m_cCameraView.setAntiBanding(strArAB2.get(arg2));
                    }
                    MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                    MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                    MainWindow.this.UpdateControls();
                }
            });
        }
    }

    private void SelectFocusModeDlg() {
        final boolean bFront = this.m_cCameraView.IsFrontCamera();
        String strFocusMode = bFront ? this.m_cCameraView.getFocusModeFront() : this.m_cCameraView.getFocusMode();
        List<String> strArFocusModes = this.m_cCameraView.getSupportedFocusMode();
        if (strArFocusModes != null && strArFocusModes.size() != 0) {
            String[] strArray = new String[strArFocusModes.size()];
            int nSelItem = -1;
            for (int n = 0; n < strArFocusModes.size(); n++) {
                if (strFocusMode.equalsIgnoreCase(strArFocusModes.get(n))) {
                    nSelItem = n;
                }
                strArray[n] = strArFocusModes.get(n);
            }
            this.m_cTextViewListParamsTitle.setText(R.string.FocusMode);
            this.m_cListViewParamsWnd.setVisibility(0);
            ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, strArray);
            this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
            this.m_cListViewParams.setChoiceMode(1);
            if (nSelItem >= 0) {
                this.m_cListViewParams.setItemChecked(nSelItem, true);
                this.m_cListViewParams.setSelection(nSelItem);
            }
            this.m_cViewIncludeCameraSettings.setVisibility(4);
            this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.22
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    List<String> strArFocusModes2 = MainWindow.this.m_cCameraView.getSupportedFocusMode();
                    if (bFront) {
                        MainWindow.this.m_cCameraView.setFocusModeFront(strArFocusModes2.get(arg2));
                    } else {
                        MainWindow.this.m_cCameraView.setFocusMode(strArFocusModes2.get(arg2));
                    }
                    MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                    MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                    MainWindow.this.UpdateControls();
                }
            });
        }
    }

    private void SelectISODlg() {
        final boolean bFront = this.m_cCameraView.IsFrontCamera();
        String strISO = bFront ? this.m_cCameraView.getISOFront() : this.m_cCameraView.getISO();
        List<String> strArISO = this.m_cCameraView.getSupportedISOValues();
        if (strArISO != null && strArISO.size() != 0) {
            String[] strArray = new String[strArISO.size()];
            int nSelItem = -1;
            for (int n = 0; n < strArISO.size(); n++) {
                if (strISO.equalsIgnoreCase(strArISO.get(n))) {
                    nSelItem = n;
                }
                strArray[n] = strArISO.get(n);
            }
            this.m_cTextViewListParamsTitle.setText(R.string.ISO);
            this.m_cListViewParamsWnd.setVisibility(0);
            ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, strArray);
            this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
            this.m_cListViewParams.setChoiceMode(1);
            if (nSelItem >= 0) {
                this.m_cListViewParams.setItemChecked(nSelItem, true);
                this.m_cListViewParams.setSelection(nSelItem);
            }
            this.m_cViewIncludeCameraSettings.setVisibility(4);
            this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.23
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    List<String> strArISO2 = MainWindow.this.m_cCameraView.getSupportedISOValues();
                    if (bFront) {
                        MainWindow.this.m_cCameraView.setISOFront(strArISO2.get(arg2));
                    } else {
                        MainWindow.this.m_cCameraView.setISO(strArISO2.get(arg2));
                    }
                    MainWindow.this.m_cListViewParams.setItemChecked(arg2, true);
                    MainWindow.this.UpdateControls();
                }
            });
        }
    }

    private void SelectAutoExposureDlg() {
        final boolean bFront = this.m_cCameraView.IsFrontCamera();
        String strAutoExposure = bFront ? this.m_cCameraView.getAutoExposureFront() : this.m_cCameraView.getAutoExposure();
        List<String> strArAutoExposure = this.m_cCameraView.getSupportedAutoExposures();
        if (strArAutoExposure != null && strArAutoExposure.size() != 0) {
            String[] strArray = new String[strArAutoExposure.size()];
            int nSelItem = -1;
            for (int n = 0; n < strArAutoExposure.size(); n++) {
                if (strAutoExposure.equalsIgnoreCase(strArAutoExposure.get(n))) {
                    nSelItem = n;
                }
                strArray[n] = strArAutoExposure.get(n);
            }
            this.m_cTextViewListParamsTitle.setText(R.string.ExposureMode);
            this.m_cListViewParamsWnd.setVisibility(0);
            ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, strArray);
            this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
            this.m_cListViewParams.setChoiceMode(1);
            if (nSelItem >= 0) {
                this.m_cListViewParams.setItemChecked(nSelItem, true);
                this.m_cListViewParams.setSelection(nSelItem);
            }
            this.m_cViewIncludeCameraSettings.setVisibility(4);
            this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.24
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    List<String> strArAutoExposure2 = MainWindow.this.m_cCameraView.getSupportedAutoExposures();
                    if (bFront) {
                        MainWindow.this.m_cCameraView.setAutoExposureFront(strArAutoExposure2.get(arg2));
                    } else {
                        MainWindow.this.m_cCameraView.setAutoExposure(strArAutoExposure2.get(arg2));
                    }
                    MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                    MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                    MainWindow.this.UpdateControls();
                }
            });
        }
    }

    private void SelectContrastDlg() {
        final boolean bFront = this.m_cCameraView.IsFrontCamera();
        String strContrast = bFront ? this.m_cCameraView.getContrastFront() : this.m_cCameraView.getContrast();
        List<String> strArContrast = this.m_cCameraView.getSupportedContrastValues();
        if (strArContrast != null && strArContrast.size() != 0) {
            String[] strArray = new String[strArContrast.size()];
            int nSelItem = -1;
            for (int n = 0; n < strArContrast.size(); n++) {
                if (strContrast.equalsIgnoreCase(strArContrast.get(n))) {
                    nSelItem = n;
                }
                strArray[n] = strArContrast.get(n);
            }
            this.m_cTextViewListParamsTitle.setText(R.string.Contrast);
            this.m_cListViewParamsWnd.setVisibility(0);
            ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, strArray);
            this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
            this.m_cListViewParams.setChoiceMode(1);
            if (nSelItem >= 0) {
                this.m_cListViewParams.setItemChecked(nSelItem, true);
                this.m_cListViewParams.setSelection(nSelItem);
            }
            this.m_cViewIncludeCameraSettings.setVisibility(4);
            this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.25
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    List<String> strArContrast2 = MainWindow.this.m_cCameraView.getSupportedContrastValues();
                    if (bFront) {
                        MainWindow.this.m_cCameraView.setContrastFront(strArContrast2.get(arg2));
                    } else {
                        MainWindow.this.m_cCameraView.setContrast(strArContrast2.get(arg2));
                    }
                    MainWindow.this.m_cListViewParams.setItemChecked(arg2, true);
                    MainWindow.this.UpdateControls();
                }
            });
        }
    }

    private void SelectBrightnessDlg() {
        final boolean bFront = this.m_cCameraView.IsFrontCamera();
        String strBrightness = bFront ? this.m_cCameraView.getBrightnessFront() : this.m_cCameraView.getBrightness();
        List<String> strArBrightness = this.m_cCameraView.getSupportedBrightnessValues();
        if (strArBrightness != null && strArBrightness.size() != 0) {
            String[] strArray = new String[strArBrightness.size()];
            int nSelItem = -1;
            for (int n = 0; n < strArBrightness.size(); n++) {
                if (strBrightness.equalsIgnoreCase(strArBrightness.get(n))) {
                    nSelItem = n;
                }
                strArray[n] = strArBrightness.get(n);
            }
            this.m_cTextViewListParamsTitle.setText(R.string.Brightness);
            this.m_cListViewParamsWnd.setVisibility(0);
            ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, strArray);
            this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
            this.m_cListViewParams.setChoiceMode(1);
            if (nSelItem >= 0) {
                this.m_cListViewParams.setItemChecked(nSelItem, true);
                this.m_cListViewParams.setSelection(nSelItem);
            }
            this.m_cViewIncludeCameraSettings.setVisibility(4);
            this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.26
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    List<String> strArBrightness2 = MainWindow.this.m_cCameraView.getSupportedBrightnessValues();
                    if (bFront) {
                        MainWindow.this.m_cCameraView.setBrightnessFront(strArBrightness2.get(arg2));
                    } else {
                        MainWindow.this.m_cCameraView.setBrightness(strArBrightness2.get(arg2));
                    }
                    MainWindow.this.m_cListViewParams.setItemChecked(arg2, true);
                    MainWindow.this.UpdateControls();
                }
            });
        }
    }

    private void SelectSaturationDlg() {
        final boolean bFront = this.m_cCameraView.IsFrontCamera();
        String strSaturation = bFront ? this.m_cCameraView.getSaturationFront() : this.m_cCameraView.getSaturation();
        List<String> strArSaturation = this.m_cCameraView.getSupportedSaturationValues();
        if (strArSaturation != null && strArSaturation.size() != 0) {
            String[] strArray = new String[strArSaturation.size()];
            int nSelItem = -1;
            for (int n = 0; n < strArSaturation.size(); n++) {
                if (strSaturation.equalsIgnoreCase(strArSaturation.get(n))) {
                    nSelItem = n;
                }
                strArray[n] = strArSaturation.get(n);
            }
            this.m_cTextViewListParamsTitle.setText(R.string.Saturation);
            this.m_cListViewParamsWnd.setVisibility(0);
            ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, strArray);
            this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
            this.m_cListViewParams.setChoiceMode(1);
            if (nSelItem >= 0) {
                this.m_cListViewParams.setItemChecked(nSelItem, true);
                this.m_cListViewParams.setSelection(nSelItem);
            }
            this.m_cViewIncludeCameraSettings.setVisibility(4);
            this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.27
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    List<String> strArSaturation2 = MainWindow.this.m_cCameraView.getSupportedSaturationValues();
                    if (bFront) {
                        MainWindow.this.m_cCameraView.setSaturationFront(strArSaturation2.get(arg2));
                    } else {
                        MainWindow.this.m_cCameraView.setSaturation(strArSaturation2.get(arg2));
                    }
                    MainWindow.this.m_cListViewParams.setItemChecked(arg2, true);
                    MainWindow.this.UpdateControls();
                }
            });
        }
    }

    private void SelectSharpnessDlg() {
        final boolean bFront = this.m_cCameraView.IsFrontCamera();
        String strSharpness = bFront ? this.m_cCameraView.getSharpnessFront() : this.m_cCameraView.getSharpness();
        List<String> strArSharpness = this.m_cCameraView.getSupportedSharpnessValues();
        if (strArSharpness != null && strArSharpness.size() != 0) {
            String[] strArray = new String[strArSharpness.size()];
            int nSelItem = -1;
            for (int n = 0; n < strArSharpness.size(); n++) {
                if (strSharpness.equalsIgnoreCase(strArSharpness.get(n))) {
                    nSelItem = n;
                }
                strArray[n] = strArSharpness.get(n);
            }
            this.m_cTextViewListParamsTitle.setText(R.string.Sharpness);
            this.m_cListViewParamsWnd.setVisibility(0);
            ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, strArray);
            this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
            this.m_cListViewParams.setChoiceMode(1);
            if (nSelItem >= 0) {
                this.m_cListViewParams.setItemChecked(nSelItem, true);
                this.m_cListViewParams.setSelection(nSelItem);
            }
            this.m_cViewIncludeCameraSettings.setVisibility(4);
            this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.28
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    List<String> strArSharpness2 = MainWindow.this.m_cCameraView.getSupportedSharpnessValues();
                    if (bFront) {
                        MainWindow.this.m_cCameraView.setSharpnessFront(strArSharpness2.get(arg2));
                    } else {
                        MainWindow.this.m_cCameraView.setSharpness(strArSharpness2.get(arg2));
                    }
                    MainWindow.this.m_cListViewParams.setItemChecked(arg2, true);
                    MainWindow.this.UpdateControls();
                }
            });
        }
    }

    @Override // android.view.View.OnLongClickListener
    public boolean onLongClick(View arg0) {
        switch (arg0.getId()) {
            case R.id.ImageButtonGallery /* 2131230815 */:
                try {
                    this.m_cCameraView.StopRecord();
                    Intent cOptIntent = new Intent();
                    cOptIntent.setClass(this, FileListActivity.class);
                    startActivity(cOptIntent);
                    return true;
                } catch (Exception e) {
                    return true;
                }
            case R.id.ImageButtonCapture /* 2131230821 */:
                if (!this.m_cCameraView.IsStarted()) {
                    switch (this.m_cCameraView.getPhotoMode()) {
                        case 0:
                            if (this.m_bAutoShutter) {
                                StopAutoShutter();
                                return true;
                            }
                            StartAutoShutter();
                            return true;
                        case 1:
                            this.m_cCameraView.CapturePhoto(true);
                            return true;
                        default:
                            return true;
                    }
                }
                this.m_cCameraView.TakePictureICS(true);
                return true;
            default:
                return false;
        }
    }

    private void StartAutoShutter() {
        this.m_bAutoShutter = true;
        this.m_fVolume = 1.0f / this.m_nAutoTimerSeconds;
        this.m_fRate = 1.0f;
        this.m_nSecondsToShut = this.m_nAutoTimerSeconds;
        this.m_cHandler.post(this.m_cUpdateAutoShutTimeUI);
    }

    private void StopAutoShutter() {
        if (this.m_bAutoShutter) {
            Toast.makeText(this, (int) R.string.ToastAutoShutterCanceled, 0).show();
        }
        this.m_bAutoShutter = false;
        this.m_cSoundPool.stop(this.m_nSoundID);
        this.m_cHandler.removeCallbacks(this.m_cUpdateAutoShutTimeUI);
    }

    /* loaded from: classes.dex */
    private class MarketLicenseCheckerCallback implements LicenseCheckerCallback {
        private MarketLicenseCheckerCallback() {
        }

        /* synthetic */ MarketLicenseCheckerCallback(MainWindow mainWindow, MarketLicenseCheckerCallback marketLicenseCheckerCallback) {
            this();
        }

        @Override // com.android.vending.licensing.LicenseCheckerCallback
        public void allow() {
            if (!MainWindow.this.isFinishing()) {
                Log.d("lgCamera", "Market license allow");
                Toast.makeText(MainWindow.this, (int) R.string.ToastLicenseAllow, 0).show();
                MainWindow.this.m_cCameraView.m_bFreeVersion = false;
                MainWindow.this.SetAppIcon(true);
                try {
                    SharedPreferences.Editor cPrefs = MainWindow.this.getSharedPreferences("Registration", 0).edit();
                    String strIMEI = MainWindow.this.getDeviceID();
                    String strKey = MainWindow.this.GenerateRPN(strIMEI);
                    cPrefs.putString("Registration info", strIMEI);
                    cPrefs.putString("Registration key", strKey);
                    cPrefs.commit();
                } catch (Exception e) {
                }
            }
        }

        @Override // com.android.vending.licensing.LicenseCheckerCallback
        public void dontAllow() {
            if (!MainWindow.this.isFinishing()) {
                Toast.makeText(MainWindow.this, (int) R.string.ToastLicenseNotAllow, 1).show();
                Log.d("lgCamera", "Market license don't allow");
                MainWindow.this.DonationDlg(false);
                MainWindow.this.SetAppIcon(false);
            }
        }

        @Override // com.android.vending.licensing.LicenseCheckerCallback
        public void applicationError(LicenseCheckerCallback.ApplicationErrorCode errorCode) {
            if (!MainWindow.this.isFinishing()) {
                Toast.makeText(MainWindow.this, (int) R.string.ToastLicenseError, 1).show();
                Log.d("lgCamera", "Market license error");
                MainWindow.this.DonationDlg(false);
            }
        }
    }

    @Override // android.location.LocationListener
    public void onLocationChanged(Location location) {
    }

    @Override // android.location.LocationListener
    public void onProviderDisabled(String provider) {
    }

    @Override // android.location.LocationListener
    public void onProviderEnabled(String provider) {
    }

    @Override // android.location.LocationListener
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    public Location getLastKnownLocation() {
        Location cLoc = this.m_cLocManager.getLastKnownLocation("gps");
        return cLoc != null ? cLoc : this.m_cLocManager.getLastKnownLocation("network");
    }

    /* loaded from: classes.dex */
    private class MyOrientationEventListener extends OrientationEventListener {
        private Handler m_cHandler;
        private Runnable m_cRotateRun;
        private float m_fAngle;
        private float m_fEndAngle;
        private float m_fStepAngle;

        public MyOrientationEventListener(Context context) {
            super(context);
            this.m_fEndAngle = 0.0f;
            this.m_fAngle = 0.0f;
            this.m_fStepAngle = 0.0f;
            this.m_cHandler = new Handler();
            this.m_cRotateRun = new Runnable() { // from class: com.android.camera.MainWindow.MyOrientationEventListener.1
                @Override // java.lang.Runnable
                public void run() {
                    MyOrientationEventListener.this.m_fAngle += MyOrientationEventListener.this.m_fStepAngle;
                    if ((MyOrientationEventListener.this.m_fAngle >= MyOrientationEventListener.this.m_fEndAngle && MyOrientationEventListener.this.m_fStepAngle > 0.0f) || (MyOrientationEventListener.this.m_fAngle <= MyOrientationEventListener.this.m_fEndAngle && MyOrientationEventListener.this.m_fStepAngle < 0.0f)) {
                        MyOrientationEventListener.this.m_fAngle = MyOrientationEventListener.this.m_fEndAngle;
                    }
                    if (MainWindow.this.m_cCameraView.m_nSDK >= 14) {
                        MainWindow.this.m_btnCapture.setRotation(MyOrientationEventListener.this.m_fAngle);
                        MainWindow.this.m_btnRecord.setRotation(MyOrientationEventListener.this.m_fAngle);
                        MainWindow.this.m_btnSwitchCamera.setRotation(MyOrientationEventListener.this.m_fAngle);
                        MainWindow.this.m_btnAllSettings.setRotation(MyOrientationEventListener.this.m_fAngle);
                        MainWindow.this.m_btnFlashMode.setRotation(MyOrientationEventListener.this.m_fAngle);
                        MainWindow.this.m_btnPauseResume.setRotation(MyOrientationEventListener.this.m_fAngle);
                        MainWindow.this.m_btnAELock.setRotation(MyOrientationEventListener.this.m_fAngle);
                        MainWindow.this.m_btnWBLock.setRotation(MyOrientationEventListener.this.m_fAngle);
                        MainWindow.this.m_btnAFReset.setRotation(MyOrientationEventListener.this.m_fAngle);
                    }
                    if (MyOrientationEventListener.this.m_fAngle != MyOrientationEventListener.this.m_fEndAngle) {
                        MyOrientationEventListener.this.m_cHandler.postDelayed(MyOrientationEventListener.this.m_cRotateRun, 50L);
                    } else {
                        MyOrientationEventListener.this.m_cHandler.removeCallbacks(MyOrientationEventListener.this.m_cRotateRun);
                    }
                }
            };
        }

        @Override // android.view.OrientationEventListener
        public void onOrientationChanged(int orientation) {
            int nRotation = (int) ((orientation / 90.0f) + 0.5f);
            if (MainWindow.this.m_nLastOrientation != nRotation) {
                Log.e("lgCamera", "Rotation " + nRotation);
                switch (nRotation) {
                    case 0:
                    case 4:
                        this.m_fEndAngle = 270.0f;
                        switch (MainWindow.this.m_nLastOrientation) {
                            case 1:
                                this.m_fAngle = 180.0f;
                                this.m_fStepAngle = 18.0f;
                                break;
                            case 2:
                                this.m_fAngle = 90.0f;
                                this.m_fStepAngle = 36.0f;
                                break;
                            case 3:
                                this.m_fAngle = 360.0f;
                                this.m_fStepAngle = -18.0f;
                                break;
                        }
                    case 1:
                        this.m_fEndAngle = 180.0f;
                        switch (MainWindow.this.m_nLastOrientation) {
                            case 0:
                            case 4:
                                this.m_fAngle = 270.0f;
                                this.m_fStepAngle = -18.0f;
                                break;
                            case 2:
                                this.m_fAngle = 90.0f;
                                this.m_fStepAngle = 18.0f;
                                break;
                            case 3:
                                this.m_fAngle = 0.0f;
                                this.m_fStepAngle = 36.0f;
                                break;
                        }
                    case 2:
                        this.m_fEndAngle = 90.0f;
                        switch (MainWindow.this.m_nLastOrientation) {
                            case 0:
                            case 4:
                                this.m_fAngle = 270.0f;
                                this.m_fStepAngle = -36.0f;
                                break;
                            case 1:
                                this.m_fAngle = 180.0f;
                                this.m_fStepAngle = -18.0f;
                                break;
                            case 3:
                                this.m_fAngle = 0.0f;
                                this.m_fStepAngle = 18.0f;
                                break;
                        }
                    case 3:
                    default:
                        this.m_fEndAngle = 0.0f;
                        switch (MainWindow.this.m_nLastOrientation) {
                            case 0:
                            case 4:
                                this.m_fAngle = -90.0f;
                                this.m_fStepAngle = 18.0f;
                                break;
                            case 1:
                                this.m_fAngle = 180.0f;
                                this.m_fStepAngle = -36.0f;
                                break;
                            case 2:
                                this.m_fAngle = 90.0f;
                                this.m_fStepAngle = -18.0f;
                                break;
                        }
                }
                this.m_cHandler.removeCallbacks(this.m_cRotateRun);
                this.m_cHandler.postDelayed(this.m_cRotateRun, 50L);
                MainWindow.this.m_nLastOrientation = nRotation;
            }
        }
    }

    public void AdjustAspectRatio() {
        this.m_cViewCameraContainer.setPadding(0, 0, 0, 0);
        int nViewWidth = this.m_cViewCameraContainer.getWidth();
        int nViewHeight = this.m_cViewCameraContainer.getHeight();
        boolean bFront = this.m_cCameraView.IsFrontCamera();
        Point ptRes = bFront ? this.m_cCameraView.getPhotoSizeFront() : this.m_cCameraView.getPhotoSize();
        if (this.m_cCameraView.IsStarted()) {
            ptRes = bFront ? this.m_cCameraView.getResolutionFront() : this.m_cCameraView.getResolution();
        }
        if (ptRes.x != 0 && ptRes.y != 0) {
            int nNewHeight = (ptRes.y * nViewWidth) / ptRes.x;
            Log.d("Aspect ratio", String.format("Width=%d, height=%d, newheight=%d", Integer.valueOf(nViewWidth), Integer.valueOf(nViewHeight), Integer.valueOf(nNewHeight)));
            if (nNewHeight > nViewHeight) {
                int nNewWidth = (ptRes.x * nViewHeight) / ptRes.y;
                this.m_ptPreviewSize.x = nNewWidth;
                this.m_ptPreviewSize.y = nViewHeight;
                int nMainBtnWidth = this.m_cViewMainButtonsInternal.getWidth();
                if (nMainBtnWidth == 0) {
                    WindowManager cWM = (WindowManager) getSystemService("window");
                    DisplayMetrics cMetrics = new DisplayMetrics();
                    cWM.getDefaultDisplay().getMetrics(cMetrics);
                    int nMainBtnWidth2 = (int) ((cMetrics.densityDpi * 33) / 160.0f);
                }
                int nMargin = (nViewWidth - nNewWidth) / 2;
                this.m_cViewCameraContainer.setPadding(nMargin, 0, nMargin, 0);
                return;
            }
            this.m_ptPreviewSize.x = nViewWidth;
            this.m_ptPreviewSize.y = nNewHeight;
            int nTopBottomPadding = (nViewHeight - nNewHeight) / 2;
            this.m_cViewCameraContainer.setPadding(0, nTopBottomPadding, 5, nTopBottomPadding);
        }
    }

    public boolean CheckRPN() {
        try {
            SharedPreferences cPrefs = getSharedPreferences("Registration", 0);
            String strIMEI = getDeviceID();
            String strKey = cPrefs.getString("Registration key", "");
            return CheckRPN(strIMEI, strKey);
        } catch (Exception e) {
            return false;
        }
    }

    static /* synthetic */ boolean access$28(MainWindow mainWindow, String str, String str2) {
        mainWindow.CheckRPN(str, str2);
        return true;
    }

    private boolean CheckRPN(String strName, String strKey) {
        try {
            if (strName.length() > 1 && strKey.length() == 5) {
                String strRes = GenerateRPN(strName);
                return strRes.equalsIgnoreCase(strKey);
            }
            return true;
        } catch (Exception e) {
            return true;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String GenerateRPN(String strIMEI) {
        if (strIMEI.length() > 10) {
            strIMEI = String.valueOf(strIMEI.substring(0, 5)) + strIMEI.substring(strIMEI.length() - 5);
        }
        int nResult = 0;
        byte[] byArName = strIMEI.getBytes();
        int nI = 0;
        for (int n = 0; n < strIMEI.length(); n++) {
            int nTemp = 0;
            if (n == 3) {
                nTemp = 1;
            }
            int nC = byArName[n];
            nResult = (nTemp * 600) + nResult + (nC * 500);
            nI++;
            if (nI >= 10) {
                nI = 0;
            }
        }
        while (nResult > 65535) {
            nResult %= 65536;
        }
        while (nResult < -65535) {
            nResult %= 65536;
        }
        if (nResult < 0) {
            nResult += 65536;
        }
        return String.format("%05d", Integer.valueOf(nResult));
    }

    /* loaded from: classes.dex */
    protected class RegistrationDialog extends Dialog implements View.OnClickListener {
        private Button m_btnApply;
        private Button m_btnCancel;
        private Button m_btnHelp;
        private EditText m_editTextIMEI;
        private EditText m_editTextKey;

        public RegistrationDialog(Context context) {
            super(context);
            setContentView(R.layout.regdialog);
            this.m_btnApply = (Button) findViewById(R.id.ButtonApply);
            this.m_btnCancel = (Button) findViewById(R.id.ButtonCancel);
            this.m_btnHelp = (Button) findViewById(R.id.ButtonHelp);
            this.m_editTextIMEI = (EditText) findViewById(R.id.EditTextIMEI);
            this.m_editTextKey = (EditText) findViewById(R.id.EditTextKey);
            setTitle(R.string.RegDlgTitle);
            SharedPreferences cPrefs = context.getSharedPreferences("Registration", 0);
            this.m_editTextIMEI.setText(cPrefs.getString("Registration info", MainWindow.this.getDeviceID()));
            this.m_editTextIMEI.setEnabled(false);
            this.m_editTextKey.setText(cPrefs.getString("Registration key", ""));
            this.m_btnApply.setOnClickListener(this);
            this.m_btnHelp.setOnClickListener(this);
            this.m_btnCancel.setOnClickListener(this);
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View arg0) {
            switch (arg0.getId()) {
                case R.id.ButtonApply /* 2131230775 */:
                    String strImei = this.m_editTextIMEI.getText().toString();
                    String strKey = this.m_editTextKey.getText().toString();
                    boolean bRes = MainWindow.access$28(MainWindow.this, strImei, strKey);
                    AlertDialog.Builder cBuilder = new AlertDialog.Builder(getContext());
                    cBuilder.setTitle(R.string.RegDlgTitle);
                    SharedPreferences.Editor cPrefs = MainWindow.this.getSharedPreferences("Registration", 0).edit();
                    cPrefs.putString("Registration info", strImei);
                    cPrefs.putString("Registration key", strKey);
                    cPrefs.commit();
                    if (bRes) {
                        MainWindow.this.SetAppIcon(true);
                        cBuilder.setMessage(R.string.RegDlgComplete);
                    } else {
                        MainWindow.this.SetAppIcon(false);
                        cBuilder.setMessage(R.string.RegDlgFailed);
                    }
                    MainWindow.this.m_cCameraView.m_bFreeVersion = bRes ? false : true;
                    MainWindow.this.UpdateControls();
                    if (MainWindow.this.adView != null) {
                        MainWindow.this.adView.destroy();
                        MainWindow.this.adView = null;
                    }
                    cBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() { // from class: com.android.camera.MainWindow.RegistrationDialog.1
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialog, int which) {
                            RegistrationDialog.this.dismiss();
                        }
                    });
                    cBuilder.setOnCancelListener(new DialogInterface.OnCancelListener() { // from class: com.android.camera.MainWindow.RegistrationDialog.2
                        @Override // android.content.DialogInterface.OnCancelListener
                        public void onCancel(DialogInterface arg02) {
                            RegistrationDialog.this.dismiss();
                        }
                    });
                    cBuilder.create().show();
                    return;
                case R.id.ButtonCancel /* 2131230776 */:
                    cancel();
                    return;
                case R.id.ButtonHelp /* 2131230874 */:
                    Resources cRes = MainWindow.this.getResources();
                    String strText = String.valueOf(cRes.getString(R.string.RegEmailRegCant)) + "\r\n" + cRes.getString(R.string.RegEmailRegInfo) + " " + this.m_editTextIMEI.getText().toString() + "\r\n" + cRes.getString(R.string.RegEmailRegKey) + " " + this.m_editTextKey.getText().toString() + "\r\n" + MainWindow.this.getPackageName();
                    Intent sendIntent = new Intent("android.intent.action.SEND");
                    sendIntent.putExtra("android.intent.extra.EMAIL", new String[]{"RubberBigPepper@gmail.com"});
                    sendIntent.putExtra("android.intent.extra.SUBJECT", cRes.getString(R.string.RegEmailRegProblem));
                    sendIntent.putExtra("android.intent.extra.TEXT", strText);
                    sendIntent.setType("text/plain");
                    MainWindow.this.startActivity(Intent.createChooser(sendIntent, cRes.getString(R.string.RegEmailIntent)));
                    return;
                default:
                    return;
            }
        }
    }

    public void UpdateFocusRect(int nXCenter, int nYCenter) {
        this.m_cHandler.removeCallbacks(this.m_cHideFocusRect);
        if (nXCenter < 0 || nYCenter < 0) {
            int nAllWidth = this.m_cCameraView.m_cGridView.getWidth();
            int nAllHeight = this.m_cCameraView.m_cGridView.getHeight();
            nXCenter = nAllWidth / 2;
            nYCenter = nAllHeight / 2;
        } else if (this.m_cCameraView.m_ptPreviewSize.x != 0 && this.m_cCameraView.m_ptPreviewSize.y != 0) {
            nXCenter = (this.m_ptPreviewSize.x * nXCenter) / this.m_cCameraView.m_ptPreviewSize.x;
            nYCenter = (this.m_ptPreviewSize.y * nYCenter) / this.m_cCameraView.m_ptPreviewSize.y;
            Log.e("lgCamera", String.format("Xcenter=%d, YCenter=%d", Integer.valueOf(nXCenter), Integer.valueOf(nYCenter)));
        }
        this.m_cCameraView.m_cGridView.setShowFocusPos(nXCenter, nYCenter);
        this.m_cCameraView.m_cGridView.setShowFocus(1);
        this.m_cHandler.postDelayed(this.m_cHideFocusRect, 1500L);
    }

    private void SelectPhotoResDlg(final boolean bFront) {
        List<Point> cArSizes = this.m_cCameraView.getSupportedPhotoSizes();
        if (cArSizes != null && cArSizes.size() != 0) {
            Point ptRes = this.m_cCameraView.getPhotoSize();
            if (bFront) {
                ptRes = this.m_cCameraView.getPhotoSizeFront();
            }
            int nIndex = -1;
            this.m_cTextViewListParamsTitle.setText(R.string.PhotoRes);
            this.m_cListViewParamsWnd.setVisibility(0);
            ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, R.layout.list_item);
            for (int n = 0; n < cArSizes.size(); n++) {
                Point szCur = cArSizes.get(n);
                if (szCur.x == ptRes.x && szCur.y == ptRes.y) {
                    nIndex = n;
                }
                cAdapter.add(String.format("%d x %d (%s %.1f MP)", Integer.valueOf(szCur.x), Integer.valueOf(szCur.y), getAspectString(szCur), Float.valueOf((szCur.x * szCur.y) / 1000000.0f)));
            }
            this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
            this.m_cListViewParams.setChoiceMode(1);
            if (nIndex >= 0) {
                this.m_cListViewParams.setItemChecked(nIndex, true);
                this.m_cListViewParams.setSelection(nIndex);
            }
            this.m_cViewIncludeCameraSettings.setVisibility(4);
            this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.29
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    List<Point> cArSizes2 = MainWindow.this.m_cCameraView.getSupportedPhotoSizes();
                    Point szRes = cArSizes2.get(arg2);
                    if (bFront) {
                        MainWindow.this.m_cCameraView.setPhotoSizeFront(szRes.x, szRes.y);
                    } else {
                        MainWindow.this.m_cCameraView.setPhotoSize(szRes.x, szRes.y);
                    }
                    MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                    MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                    MainWindow.this.UpdateControls();
                }
            });
        }
    }

    private void SelectPhotoInVideoResDlg(final boolean bFront) {
        List<Point> cArSizes = this.m_cCameraView.getSupportedPhotoSizes();
        if (cArSizes != null && cArSizes.size() != 0) {
            Point ptRes = this.m_cCameraView.getPhotoInVideoSize();
            if (bFront) {
                ptRes = this.m_cCameraView.getPhotoInVideoSizeFront();
            }
            int nIndex = -1;
            this.m_cTextViewListParamsTitle.setText(R.string.PhotoRes);
            this.m_cListViewParamsWnd.setVisibility(0);
            ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, R.layout.list_item);
            for (int n = 0; n < cArSizes.size(); n++) {
                Point szCur = cArSizes.get(n);
                if (szCur.x == ptRes.x && szCur.y == ptRes.y) {
                    nIndex = n;
                }
                cAdapter.add(String.format("%d x %d (%s %.1f MP)", Integer.valueOf(szCur.x), Integer.valueOf(szCur.y), getAspectString(szCur), Float.valueOf((szCur.x * szCur.y) / 1000000.0f)));
            }
            this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
            this.m_cListViewParams.setChoiceMode(1);
            if (nIndex >= 0) {
                this.m_cListViewParams.setItemChecked(nIndex, true);
                this.m_cListViewParams.setSelection(nIndex);
            }
            this.m_cViewIncludeCameraSettings.setVisibility(4);
            this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.30
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    List<Point> cArSizes2 = MainWindow.this.m_cCameraView.getSupportedPhotoSizes();
                    Point szRes = cArSizes2.get(arg2);
                    if (bFront) {
                        MainWindow.this.m_cCameraView.setPhotoInVideoSizeFront(szRes.x, szRes.y);
                    } else {
                        MainWindow.this.m_cCameraView.setPhotoInVideoSize(szRes.x, szRes.y);
                    }
                    MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                    MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                    MainWindow.this.UpdateControls();
                }
            });
        }
    }

    private void SelectPhotoModeDlg() {
        this.m_cTextViewListParamsTitle.setText(R.string.PhotoMode);
        this.m_cListViewParamsWnd.setVisibility(0);
        String[] strArModes = getResources().getStringArray(R.array.PhotoModes);
        List<String> strArModes2 = new Vector<>();
        strArModes2.add(strArModes[0]);
        if (!this.m_bImageCaptureIntent) {
            strArModes2.add(strArModes[1]);
        }
        if (Panorama.m_bEnable) {
            strArModes2.add(strArModes[2]);
        }
        ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, (String[]) strArModes2.toArray(new String[strArModes2.size()]));
        this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
        this.m_cListViewParams.setChoiceMode(1);
        this.m_cListViewParams.setItemChecked(this.m_cCameraView.getPhotoMode(), true);
        this.m_cViewIncludeCameraSettings.setVisibility(4);
        this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.31
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                if (arg2 == 1 && MainWindow.this.m_bImageCaptureIntent) {
                    arg2 = 2;
                }
                MainWindow.this.m_cCameraView.setPhotoMode(arg2);
                MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                MainWindow.this.UpdateControls();
                MainWindow.this.UpdateButtons();
            }
        });
    }

    private void SelectVideoResDlg(final boolean bFront) {
        List<Point> cArSizes = this.m_cCameraView.getSupportedVideoRes();
        if (cArSizes != null && cArSizes.size() != 0) {
            Vector<Point> ptArNative = new Vector<>();
            ptArNative.add(new Point(160, 120));
            ptArNative.add(new Point(176, 144));
            ptArNative.add(new Point(320, 240));
            ptArNative.add(new Point(352, 288));
            ptArNative.add(new Point(400, 300));
            ptArNative.add(new Point(480, 320));
            ptArNative.add(new Point(640, 480));
            ptArNative.add(new Point(704, 576));
            ptArNative.add(new Point(720, 480));
            ptArNative.add(new Point(800, 480));
            ptArNative.add(new Point(1280, 720));
            ptArNative.add(new Point(1920, 1080));
            ptArNative.add(new Point(1920, 1088));
            ptArNative.add(new Point(3840, 2160));
            for (int n = 0; n < cArSizes.size(); n++) {
                Point ptSize = cArSizes.get(n);
                int nIndex = -1;
                int m = 0;
                while (true) {
                    if (m < ptArNative.size()) {
                        if (ptArNative.get(m).x != ptSize.x || ptArNative.get(m).y != ptSize.y) {
                            m++;
                        } else {
                            nIndex = m;
                            break;
                        }
                    } else {
                        break;
                    }
                }
                ptSize.x = -ptSize.x;
                if (nIndex == -1) {
                    ptArNative.add(ptSize);
                } else {
                    ptArNative.set(nIndex, ptSize);
                }
            }
            final Point[] ptAll = new Point[ptArNative.size()];
            ptArNative.toArray(ptAll);
            Arrays.sort(ptAll, new VideoResComparer(this, null));
            this.m_cTextViewListParamsTitle.setText(R.string.VideoResolution);
            this.m_cListViewParamsWnd.setVisibility(0);
            ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, R.layout.list_item);
            cAdapter.setDropDownViewResource(17367049);
            int nIndex2 = -1;
            Point ptRes = this.m_cCameraView.getResolution();
            if (bFront) {
                ptRes = this.m_cCameraView.getResolutionFront();
            }
            for (int n2 = 0; n2 < ptAll.length; n2++) {
                Point ptSize2 = ptAll[n2];
                if (ptSize2.x < 0 || ptSize2.y < 0) {
                    ptSize2.x = Math.abs(ptSize2.x);
                    ptSize2.y = Math.abs(ptSize2.y);
                    cAdapter.add(String.format("%d x %d (%s %.1f MP)", Integer.valueOf(ptSize2.x), Integer.valueOf(ptSize2.y), getAspectString(ptSize2), Float.valueOf(ptSize2.x * ptSize2.y * 1.0E-6f)));
                } else {
                    cAdapter.add(String.format("%d x %d %s", Integer.valueOf(ptSize2.x), Integer.valueOf(ptSize2.y), getResources().getString(R.string.WarningNotSupported)));
                }
                if (ptSize2.x == ptRes.x && ptSize2.y == ptRes.y) {
                    nIndex2 = n2;
                }
            }
            this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
            this.m_cListViewParams.setChoiceMode(1);
            if (nIndex2 >= 0) {
                this.m_cListViewParams.setItemChecked(nIndex2, true);
                this.m_cListViewParams.setSelection(nIndex2);
            }
            this.m_cViewIncludeCameraSettings.setVisibility(4);
            this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.32
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    if (bFront) {
                        MainWindow.this.m_cCameraView.setResolutionFront(ptAll[arg2]);
                    } else {
                        MainWindow.this.m_cCameraView.setResolution(ptAll[arg2]);
                    }
                    MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                    MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                    MainWindow.this.UpdateControls();
                }
            });
        }
    }

    private void SelectVideoFormatDlg() {
        this.m_cTextViewListParamsTitle.setText(R.string.VideoFormat);
        this.m_cListViewParamsWnd.setVisibility(0);
        ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, getResources().getStringArray(R.array.VideoFormat));
        this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
        this.m_cListViewParams.setChoiceMode(1);
        this.m_cListViewParams.setItemChecked(this.m_cCameraView.getFormat() - 1, true);
        this.m_cViewIncludeCameraSettings.setVisibility(4);
        this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.33
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                MainWindow.this.m_cCameraView.setFormat(arg2 + 1);
                MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                MainWindow.this.UpdateControls();
            }
        });
    }

    private void SelectVideoEncoderDlg() {
        this.m_cTextViewListParamsTitle.setText(R.string.VideoEncoder);
        this.m_cListViewParamsWnd.setVisibility(0);
        ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, getResources().getStringArray(R.array.VideoEncoder));
        this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
        this.m_cListViewParams.setChoiceMode(1);
        this.m_cListViewParams.setItemChecked(this.m_cCameraView.getEncoder(), true);
        this.m_cViewIncludeCameraSettings.setVisibility(4);
        this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.34
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                MainWindow.this.m_cCameraView.setEncoder(arg2);
                MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                MainWindow.this.UpdateControls();
            }
        });
    }

    private void SelectVideoBitRateDlg() {
        this.m_cTextViewListParamsTitle.setText(R.string.VideoBitRate);
        this.m_cListViewParamsWnd.setVisibility(0);
        String[] strArBitRates = new String[BitrateSampleRateHelper.m_nArVideoBitrates.length];
        int nBitRate = this.m_cCameraView.getBitRate();
        final boolean bFront = this.m_cCameraView.IsFrontCamera();
        if (bFront) {
            nBitRate = this.m_cCameraView.getBitRateFront();
        }
        int nSelItem = 0;
        for (int n = 0; n < BitrateSampleRateHelper.m_nArVideoBitrates.length; n++) {
            if (BitrateSampleRateHelper.m_nArVideoBitrates[n] >= 1000000) {
                strArBitRates[n] = String.format("%d Mbit", Integer.valueOf(BitrateSampleRateHelper.m_nArVideoBitrates[n] / 1000000));
            } else {
                strArBitRates[n] = String.format("%d Kbit", Integer.valueOf(BitrateSampleRateHelper.m_nArVideoBitrates[n] / 1000));
            }
            if (nBitRate == BitrateSampleRateHelper.m_nArVideoBitrates[n]) {
                nSelItem = n;
            }
        }
        ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, strArBitRates);
        this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
        this.m_cListViewParams.setChoiceMode(1);
        if (nSelItem >= 0) {
            this.m_cListViewParams.setItemChecked(nSelItem, true);
            this.m_cListViewParams.setSelection(nSelItem);
        }
        this.m_cViewIncludeCameraSettings.setVisibility(4);
        this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.35
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                if (bFront) {
                    MainWindow.this.m_cCameraView.setBitRateFront(BitrateSampleRateHelper.m_nArVideoBitrates[arg2]);
                } else {
                    MainWindow.this.m_cCameraView.setBitRate(BitrateSampleRateHelper.m_nArVideoBitrates[arg2]);
                }
                MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                MainWindow.this.UpdateControls();
            }
        });
    }

    private void SelectVideoFPSDlg() {
        this.m_cTextViewListParamsTitle.setText(R.string.VideoFPS);
        this.m_cListViewParamsWnd.setVisibility(0);
        int nFrameRates = this.m_cCameraView.getFrameRates();
        final List<Integer> nArFPS = this.m_cCameraView.getSupportedFrameRates();
        if (nArFPS != null && nArFPS.size() != 0) {
            int nSelItem = -1;
            ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, R.layout.list_item);
            cAdapter.setDropDownViewResource(17367049);
            cAdapter.add(getResources().getString(R.string.Auto));
            for (int n = 0; n < nArFPS.size(); n++) {
                if (nFrameRates == nArFPS.get(n).intValue()) {
                    nSelItem = n + 1;
                }
                if (n >= nArFPS.size() - 3) {
                    cAdapter.add(String.valueOf(nArFPS.get(n).toString()) + getResources().getString(R.string.WarningNotSupported));
                } else {
                    cAdapter.add(nArFPS.get(n).toString());
                }
            }
            this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
            this.m_cListViewParams.setChoiceMode(1);
            if (nSelItem >= 0) {
                this.m_cListViewParams.setItemChecked(nSelItem, true);
                this.m_cListViewParams.setSelection(nSelItem);
            }
            this.m_cViewIncludeCameraSettings.setVisibility(4);
            this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.36
                @Override // android.widget.AdapterView.OnItemClickListener
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    if (arg2 == 0) {
                        MainWindow.this.m_cCameraView.setFrameRates(0);
                    } else {
                        MainWindow.this.m_cCameraView.setFrameRates(((Integer) nArFPS.get(arg2 - 1)).intValue());
                    }
                    MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                    MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                    MainWindow.this.UpdateControls();
                }
            });
        }
    }

    private void SelectAudioEncoderDlg() {
        this.m_cTextViewListParamsTitle.setText(R.string.AudioEncoder);
        this.m_cListViewParamsWnd.setVisibility(0);
        ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, getResources().getStringArray(R.array.AudioEncoder));
        this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
        this.m_cListViewParams.setChoiceMode(1);
        this.m_cListViewParams.setItemChecked(this.m_cCameraView.getAudioEncoder(), true);
        this.m_cViewIncludeCameraSettings.setVisibility(4);
        this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.37
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                MainWindow.this.m_cCameraView.setAudioEncoder(arg2);
                if (arg2 == 0 || arg2 == 1) {
                    MainWindow.this.m_cCameraView.setAudioBitRate(12800);
                    MainWindow.this.m_cCameraView.setSamplingRate(8000);
                }
                MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                MainWindow.this.UpdateControls();
            }
        });
    }

    private void SelectAudioSourceDlg() {
        this.m_cTextViewListParamsTitle.setText(R.string.LabelAudioSource);
        this.m_cListViewParamsWnd.setVisibility(0);
        ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, getResources().getStringArray(R.array.AudioSource));
        this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
        this.m_cListViewParams.setChoiceMode(1);
        int nSelItem = this.m_cCameraView.getAudioSource();
        if (nSelItem >= 0) {
            this.m_cListViewParams.setItemChecked(nSelItem, true);
        }
        this.m_cViewIncludeCameraSettings.setVisibility(4);
        this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.38
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                MainWindow.this.m_cCameraView.setAudioSource(arg2);
                MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                MainWindow.this.UpdateControls();
            }
        });
    }

    private void SelectAudioBitRateDlg() {
        this.m_cTextViewListParamsTitle.setText(R.string.AudioBitRate);
        this.m_cListViewParamsWnd.setVisibility(0);
        String[] strArBitRates = new String[BitrateSampleRateHelper.m_nArAudioBitrates.length];
        int nBitRate = this.m_cCameraView.getAudioBitRate();
        int nSelItem = -1;
        for (int n = 0; n < BitrateSampleRateHelper.m_nArAudioBitrates.length; n++) {
            strArBitRates[n] = String.format("%d", Integer.valueOf(BitrateSampleRateHelper.m_nArAudioBitrates[n]));
            if (nBitRate == BitrateSampleRateHelper.m_nArAudioBitrates[n]) {
                nSelItem = n;
            }
        }
        ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, strArBitRates);
        this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
        this.m_cListViewParams.setChoiceMode(1);
        if (nSelItem >= 0) {
            this.m_cListViewParams.setItemChecked(nSelItem, true);
            this.m_cListViewParams.setSelection(nSelItem);
        }
        this.m_cViewIncludeCameraSettings.setVisibility(4);
        this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.39
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                MainWindow.this.m_cCameraView.setAudioBitRate(BitrateSampleRateHelper.m_nArAudioBitrates[arg2]);
                MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                MainWindow.this.UpdateControls();
            }
        });
    }

    private void SelectAudioSamplingRateDlg() {
        this.m_cTextViewListParamsTitle.setText(R.string.AudioSampleRate);
        this.m_cListViewParamsWnd.setVisibility(0);
        String[] strArBitRates = new String[BitrateSampleRateHelper.m_nArAudioSampleRates.length];
        int nSelItem = -1;
        int nBitRate = this.m_cCameraView.getSamplingRate();
        for (int n = 0; n < BitrateSampleRateHelper.m_nArAudioSampleRates.length; n++) {
            strArBitRates[n] = String.format("%d", Integer.valueOf(BitrateSampleRateHelper.m_nArAudioSampleRates[n]));
            if (nBitRate == BitrateSampleRateHelper.m_nArAudioSampleRates[n]) {
                nSelItem = n;
            }
        }
        ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, strArBitRates);
        this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
        this.m_cListViewParams.setChoiceMode(1);
        if (nSelItem >= 0) {
            this.m_cListViewParams.setItemChecked(nSelItem, true);
            this.m_cListViewParams.setSelection(nSelItem);
        }
        this.m_cViewIncludeCameraSettings.setVisibility(4);
        this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.40
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                MainWindow.this.m_cCameraView.setSamplingRate(BitrateSampleRateHelper.m_nArAudioSampleRates[arg2]);
                MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                MainWindow.this.UpdateControls();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public class VideoResComparer implements Comparator<Point> {
        private VideoResComparer() {
        }

        /* synthetic */ VideoResComparer(MainWindow mainWindow, VideoResComparer videoResComparer) {
            this();
        }

        @Override // java.util.Comparator
        public int compare(Point object1, Point object2) {
            int nX1 = Math.abs(object1.x);
            int nX2 = Math.abs(object2.x);
            if (nX1 < nX2) {
                return -1;
            }
            if (nX1 > nX2) {
                return 1;
            }
            int nY1 = Math.abs(object1.y);
            int nY2 = Math.abs(object2.y);
            if (nY1 >= nY2) {
                return nY1 > nY2 ? 1 : 0;
            }
            return -1;
        }
    }

    @Override // android.widget.CompoundButton.OnCheckedChangeListener
    public void onCheckedChanged(CompoundButton view, boolean isChecked) {
        switch (view.getId()) {
            case R.id.CheckBoxFullAngle /* 2131230854 */:
                if (isChecked) {
                    AlertDialog.Builder cBuilder = new AlertDialog.Builder(this);
                    cBuilder.setTitle(R.string.PanoFullSweep);
                    cBuilder.setMessage(R.string.PanoFullSweepWarning);
                    cBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() { // from class: com.android.camera.MainWindow.41
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface arg0, int arg1) {
                            MainWindow.this.m_cCameraView.m_bFullSweep = true;
                            MainWindow.this.UpdateControls();
                        }
                    });
                    cBuilder.setNegativeButton(R.string.DlgCancel, new DialogInterface.OnClickListener() { // from class: com.android.camera.MainWindow.42
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface arg0, int arg1) {
                            MainWindow.this.m_cCheckBoxFullAngle.setChecked(false);
                            MainWindow.this.UpdateControls();
                        }
                    });
                    cBuilder.create().show();
                    break;
                } else {
                    this.m_cCameraView.m_bFullSweep = false;
                    break;
                }
            case R.id.CheckBoxAntishake /* 2131230857 */:
                this.m_bAntiShake = isChecked;
                break;
            case R.id.CheckBoxSaveGPSInEXIF /* 2131230860 */:
                this.m_cCameraView.setUseGPSEXIF(isChecked);
                this.m_cLocManager.removeUpdates(this);
                if (this.m_cCameraView.getUseGPSEXIF()) {
                    this.m_cLocManager.requestLocationUpdates("gps", 0L, 0.0f, this);
                    this.m_cLocManager.requestLocationUpdates("network", 0L, 0.0f, this);
                    break;
                }
                break;
            case R.id.CheckBoxOverlayDateTime /* 2131230863 */:
                this.m_cCameraView.setOverlayDateTime(isChecked);
                break;
            case R.id.CheckBoxDelayedSave /* 2131230867 */:
                if (isChecked) {
                    this.m_cCameraView.setMaxDelayedFiles(5);
                    break;
                } else {
                    this.m_cCameraView.setMaxDelayedFiles(1);
                    break;
                }
            case R.id.CheckBoxUseSEC /* 2131230883 */:
                this.m_cCheckBoxUseSEC.setOnCheckedChangeListener(null);
                this.m_cCameraView.SetUseSEC(isChecked);
                this.m_cCheckBoxUseSEC.setChecked(this.m_cCameraView.IsUseSEC());
                this.m_cCheckBoxUseSEC.setOnCheckedChangeListener(this);
                break;
            case R.id.CheckBoxShowGrid /* 2131230886 */:
                this.m_cCameraView.m_cGridView.setShowGrid(isChecked);
                break;
            case R.id.CheckBoxShowStatus /* 2131230889 */:
                this.m_cCameraView.m_bShowStatus = isChecked;
                break;
            case R.id.CheckBoxAutoRotate /* 2131230891 */:
                this.m_cCameraView.setAutoRotate(isChecked);
                break;
            case R.id.CheckBoxAutoStartNew /* 2131230896 */:
                this.m_cCameraView.m_bStartRecordNewAfterStop = isChecked;
                break;
            case R.id.CheckBoxFlashOnFocus /* 2131230898 */:
                this.m_cCameraView.m_bFlashOnFocus = isChecked;
                break;
            case R.id.CheckBoxMTKDevice /* 2131230900 */:
                this.m_cCameraView.m_bMTKDevice = isChecked;
                break;
            case R.id.CheckBoxVibrate /* 2131230904 */:
                this.m_cCameraView.m_bVibrate = isChecked;
                break;
            case R.id.CheckBoxRunOnCameraButton /* 2131230906 */:
                this.m_cCameraView.setRunOnCameraPress(isChecked);
                break;
            case R.id.CheckBoxTurnOffSounds /* 2131230908 */:
                this.m_cCameraView.setTurnOffSounds(isChecked);
                break;
            case R.id.CheckBoxMaxBrightness /* 2131230910 */:
                this.m_cCameraView.m_bUseMaxBrightness = isChecked;
                if (this.m_cCameraView.m_bUseMaxBrightness) {
                    SetWindowBrightness(1.0f);
                    break;
                } else {
                    SetWindowBrightness(this.m_fBrightness);
                    break;
                }
            case R.id.CheckBoxSensorFocus /* 2131230912 */:
                this.m_cCameraView.setAllowSensorFocus(isChecked);
                break;
            case R.id.CheckBoxForcedAF /* 2131230914 */:
                this.m_cCameraView.setForcedAF(isChecked);
                break;
            case R.id.CheckBoxLongClickShutter /* 2131230916 */:
                this.m_cCameraView.m_bLongClickShutter = isChecked;
                break;
            case R.id.CheckBoxSaveDebugLog /* 2131230918 */:
                DebugLog.m_bDebug = isChecked;
                break;
            case R.id.CheckBoxRestartCamera /* 2131230949 */:
                this.m_cCameraView.m_bRestartCamera = isChecked;
                break;
            case R.id.CheckBoxVideoStabilization /* 2131230961 */:
                this.m_cCameraView.setVideoStab(isChecked);
                break;
            case R.id.CheckBoxAGCOff /* 2131230968 */:
                this.m_cCameraView.SetAGCOff(isChecked);
                break;
            case R.id.CheckBoxStereoSound /* 2131230971 */:
                if (isChecked) {
                    this.m_cCameraView.setAudioChannels(2);
                    break;
                } else {
                    this.m_cCameraView.setAudioChannels(1);
                    break;
                }
        }
        UpdateControls();
    }

    private void SetWindowBrightness(float fBrightness) {
        Window cWindow = getWindow();
        WindowManager.LayoutParams cParams = cWindow.getAttributes();
        cParams.screenBrightness = fBrightness;
        cWindow.setAttributes(cParams);
    }

    @Override // rubberbigpepper.CommonCtrl.ZoomView.OnZoomViewValueChanged
    public void onValueChanged(boolean bFromUser) {
        if (bFromUser) {
            this.m_cCameraView.setZoomValue(this.m_cZoomProgress.getProgress() + 1);
        }
    }

    private void SelectJPGQualityDlg() {
        JPGQualityDlg cDlg = new JPGQualityDlg(this, new JPGQualityDlg.OnQualityChangedListener() { // from class: com.android.camera.MainWindow.43
            @Override // com.android.camera.JPGQualityDlg.OnQualityChangedListener
            public void qualityChanged(int quality) {
                MainWindow.this.m_cCameraView.setJPGQuality(quality + 1);
                MainWindow.this.UpdateControls();
            }
        }, this.m_cCameraView.getJPGQuality() - 1);
        cDlg.show();
    }

    private void StartGallery() {
        if (this.m_cCameraView.m_cSaveThread.getCount() <= 0) {
            try {
                CAMERA_IMAGE_BUCKET_NAME = CameraView.getFolder();
                Uri.Builder cBuilder = MediaStore.Images.Media.EXTERNAL_CONTENT_URI.buildUpon();
                String str = CAMERA_IMAGE_BUCKET_NAME.toLowerCase();
                cBuilder.appendQueryParameter("bucketId", String.valueOf(str.hashCode()));
                Intent intent = new Intent("android.intent.action.VIEW", cBuilder.build());
                intent.addFlags(67108864);
                intent.putExtra("windowTitle", "lgCamera");
                intent.putExtra("mediaTypes", 5);
                startActivity(intent);
            } catch (Exception e) {
                try {
                    Intent intent2 = new Intent("com.htc.album.action.VIEW_PHOTO_FROM_CAMERA");
                    intent2.setType("image/*");
                    startActivity(intent2);
                } catch (Exception e2) {
                    try {
                        Intent intent3 = new Intent("android.intent.action.MAIN");
                        intent3.addCategory("android.intent.category.LAUNCHER");
                        intent3.setFlags(270532608);
                        intent3.setClassName("com.htc.album", "com.htc.album.AlbumMain.ActivityMainCarousel");
                        startActivity(intent3);
                    } catch (Exception e3) {
                        try {
                            Intent cOptIntent = new Intent();
                            cOptIntent.setClass(this, FileListActivity.class);
                            startActivity(cOptIntent);
                        } catch (Exception ex) {
                            Log.e("lgCamera exception=", ex.getMessage());
                        }
                    }
                }
            }
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CGridView.OnZeroAccelValue
    public void onZeroAccel() {
        if (!this.m_cCameraView.IsStarted() && this.m_bAntiShake && this.m_bUseAntiShake) {
            this.m_bUseAntiShake = false;
            this.m_cImageViewAntiShake.setVisibility(8);
            this.m_cCameraView.CapturePhoto(false);
        }
    }

    public void UpdateButtons() {
        boolean bStarted = this.m_cCameraView.IsStarted();
        boolean bCtrlPanelVisible = IsCtrlPanelShowing();
        boolean bBigPreview = this.m_cViewMainPreviewContainer.getVisibility() == 0;
        int nMaxZoom = this.m_cCameraView.getMaxZoom();
        boolean bFront = this.m_cCameraView.IsFrontCamera();
        this.m_cZoomProgress.setMax(nMaxZoom);
        boolean bPanoCapturing = (this.m_cCameraView.getPhotoMode() == 2) & (this.m_cCameraView.GetPanoMode() == 1);
        if (bPanoCapturing || this.m_bImageCaptureIntent) {
            this.m_btnRecord.setVisibility(4);
        } else {
            this.m_btnRecord.setVisibility(0);
        }
        if ((bStarted && this.m_cCameraView.m_nSDK < 14) || bCtrlPanelVisible || bBigPreview || bPanoCapturing) {
            this.m_cZoomProgress.setVisibility(4);
            this.m_btnGallery.setVisibility(4);
        } else {
            if (nMaxZoom == 0) {
                this.m_cZoomProgress.setVisibility(4);
            } else {
                this.m_cZoomProgress.setVisibility(0);
            }
            if (!bStarted && !this.m_bImageCaptureIntent && !this.m_bVideoCaptureIntent) {
                this.m_btnGallery.setVisibility(0);
            } else {
                this.m_btnGallery.setVisibility(4);
            }
        }
        if (bStarted && !bBigPreview) {
            this.m_cTextViewRecord.setVisibility(0);
        } else {
            this.m_cTextViewRecord.setText("");
            this.m_cTextViewRecord.setVisibility(4);
        }
        if ((!this.m_cCameraView.CanCaptureWhileRecording() && bStarted) || this.m_bVideoCaptureIntent) {
            this.m_btnCapture.setVisibility(4);
        } else {
            this.m_btnCapture.setVisibility(0);
        }
        if (bCtrlPanelVisible || bBigPreview) {
            this.m_cViewMainButtonsInternal.setVisibility(4);
        } else {
            this.m_cViewMainButtonsInternal.setVisibility(0);
        }
        if (!bBigPreview && this.m_cCameraView.m_bShowStatus) {
            this.m_cViewStatus.setVisibility(0);
        } else {
            this.m_cViewStatus.setVisibility(4);
        }
        if (this.m_cCameraView.IsPauseExist() && bStarted) {
            ((View) this.m_btnPauseResume.getParent()).setVisibility(0);
        } else {
            ((View) this.m_btnPauseResume.getParent()).setVisibility(4);
        }
        if (this.m_cCameraView.GetCameraCount() <= 1 || bStarted || bCtrlPanelVisible || bBigPreview) {
            this.m_btnSwitchCamera.setVisibility(4);
        } else if (bPanoCapturing) {
            this.m_btnSwitchCamera.setVisibility(4);
        } else {
            this.m_btnSwitchCamera.setVisibility(0);
        }
        if (bStarted || bBigPreview) {
            ((View) this.m_btnFlashMode.getParent()).setVisibility(4);
            this.m_cCameraView.m_cGridView.setShowCross(false);
            this.m_btnAllSettings.setVisibility(4);
        } else {
            this.m_cTextViewRecord.setText("");
            ((View) this.m_btnFlashMode.getParent()).setVisibility(0);
            this.m_cCameraView.m_cGridView.setShowCross(this.m_bAntiShake);
            if (bPanoCapturing) {
                this.m_btnAllSettings.setVisibility(4);
            } else {
                this.m_btnAllSettings.setVisibility(0);
            }
        }
        switch (this.m_cCameraView.getEncoder()) {
            case 1:
                this.m_cTextViewVideoEncoder.setText("H.263");
                break;
            case 2:
                this.m_cTextViewVideoEncoder.setText("H.264");
                break;
            case 3:
                this.m_cTextViewVideoEncoder.setText("MPEG4");
                break;
            default:
                this.m_cTextViewVideoEncoder.setText("Default");
                break;
        }
        int nBitRate = this.m_cCameraView.getBitRate();
        if (bFront) {
            nBitRate = this.m_cCameraView.getBitRateFront();
        }
        if (nBitRate < 1000000) {
            this.m_cTextViewVideoBitRate.setText(String.format("%dKbit", Integer.valueOf(nBitRate / 1000)));
        } else {
            this.m_cTextViewVideoBitRate.setText(String.format("%dMbit", Integer.valueOf(nBitRate / 1000000)));
        }
        switch (this.m_cCameraView.getAudioEncoder()) {
            case 1:
                this.m_cTextViewAudioEncoder.setText("AMR_NB");
                break;
            case 2:
                this.m_cTextViewAudioEncoder.setText("AMR_WB");
                break;
            case 3:
                this.m_cTextViewAudioEncoder.setText("AAC");
                break;
            default:
                this.m_cTextViewAudioEncoder.setText("Default");
                break;
        }
        int nAudioBitRate = this.m_cCameraView.getAudioBitRate();
        if (nAudioBitRate > 0) {
            this.m_cTextViewAudioBitRate.setText(String.format("%d", Integer.valueOf(nAudioBitRate)));
        } else {
            this.m_cTextViewAudioBitRate.setText("Default");
        }
        if (this.m_cCameraView.getFormat() == 1) {
            this.m_cTextViewFormat.setText("3GPP");
        } else {
            this.m_cTextViewFormat.setText("MP4");
        }
        int nFPS = this.m_cCameraView.getFrameRates();
        if (nFPS == 0) {
            this.m_cTextViewFPS.setText("Auto");
        } else {
            this.m_cTextViewFPS.setText(String.format("%dFPS", Integer.valueOf(this.m_cCameraView.getFrameRates())));
        }
        List<String> strArFM = this.m_cCameraView.getSupportedFM();
        if (strArFM == null || strArFM.size() == 0) {
            this.m_btnFlashMode.setImageResource(R.drawable.flash_off);
        } else {
            String strFM = this.m_cCameraView.getFlashMode();
            if (strFM.equalsIgnoreCase("auto")) {
                this.m_btnFlashMode.setImageResource(R.drawable.flash_auto);
            }
            if (strFM.equalsIgnoreCase("on")) {
                this.m_btnFlashMode.setImageResource(R.drawable.flash_on);
            }
            if (strFM.equalsIgnoreCase("off")) {
                this.m_btnFlashMode.setImageResource(R.drawable.flash_off);
            }
            if (strFM.equalsIgnoreCase("torch") || strFM.equalsIgnoreCase("tourch")) {
                this.m_btnFlashMode.setImageResource(R.drawable.flash_torch);
            }
            if (strFM.equalsIgnoreCase("red-eye")) {
                this.m_btnFlashMode.setImageResource(R.drawable.flash_red_eye);
            }
        }
        if (this.m_cCameraView.IsStarted()) {
            this.m_btnCapture.setImageResource(R.drawable.camera);
            this.m_cLinearFullAngle.setVisibility(8);
        } else {
            switch (this.m_cCameraView.getPhotoMode()) {
                case 0:
                    this.m_btnCapture.setImageResource(R.drawable.camera);
                    this.m_cLinearFullAngle.setVisibility(8);
                    break;
                case 1:
                    this.m_btnCapture.setImageResource(R.drawable.serial);
                    this.m_cLinearFullAngle.setVisibility(8);
                    break;
                case 2:
                    this.m_cLinearFullAngle.setVisibility(0);
                    this.m_cCheckBoxFullAngle.setOnCheckedChangeListener(null);
                    this.m_cCheckBoxFullAngle.setChecked(this.m_cCameraView.m_bFullSweep);
                    this.m_cCheckBoxFullAngle.setOnCheckedChangeListener(this);
                    if (this.m_cCameraView.GetPanoMode() == 1) {
                        this.m_btnCapture.setImageResource(R.drawable.panorama_stop);
                        break;
                    } else {
                        this.m_btnCapture.setImageResource(R.drawable.panorama_start);
                        break;
                    }
            }
        }
        if (this.m_cCameraView.IsAELockSupported()) {
            if (this.m_cCameraView.getAELock()) {
                this.m_btnAELock.setImageResource(R.drawable.ae_lock);
            } else {
                this.m_btnAELock.setImageResource(R.drawable.ae_unlock);
            }
            if (bCtrlPanelVisible || bBigPreview) {
                this.m_btnAELock.setVisibility(4);
            } else {
                this.m_btnAELock.setVisibility(0);
            }
        } else {
            this.m_btnAELock.setVisibility(4);
        }
        if (this.m_cCameraView.IsWBLockSupported()) {
            if (this.m_cCameraView.getWBLock()) {
                this.m_btnWBLock.setImageResource(R.drawable.wb_lock);
            } else {
                this.m_btnWBLock.setImageResource(R.drawable.wb_unlock);
            }
            if (bCtrlPanelVisible || bBigPreview) {
                this.m_btnWBLock.setVisibility(4);
            } else {
                this.m_btnWBLock.setVisibility(0);
            }
        } else {
            this.m_btnWBLock.setVisibility(4);
        }
        if (bFront) {
            this.m_cTextViewResWidth.setText(String.format("%d(%d)", Integer.valueOf(this.m_cCameraView.getPhotoSizeFront().x), Integer.valueOf(this.m_cCameraView.getResolutionFront().x)));
            this.m_cTextViewResHeight.setText(String.format("%d(%d)", Integer.valueOf(this.m_cCameraView.getPhotoSizeFront().y), Integer.valueOf(this.m_cCameraView.getResolutionFront().y)));
        } else {
            this.m_cTextViewResWidth.setText(String.format("%d(%d)", Integer.valueOf(this.m_cCameraView.getPhotoSize().x), Integer.valueOf(this.m_cCameraView.getResolution().x)));
            this.m_cTextViewResHeight.setText(String.format("%d(%d)", Integer.valueOf(this.m_cCameraView.getPhotoSize().y), Integer.valueOf(this.m_cCameraView.getResolution().y)));
        }
        this.m_cTextViewDelayCount.setText(String.format("%d", Integer.valueOf(this.m_cCameraView.getJpegDelayCount())));
        this.m_cTextViewMaxDelayCount.setText(String.format("%d", Integer.valueOf(this.m_cCameraView.getMaxJpegDelayCount())));
        switch (this.m_cCameraView.getPhotoMode()) {
            case 0:
                this.m_btnCapture.setImageResource(R.drawable.camera);
                return;
            case 1:
                this.m_btnCapture.setImageResource(R.drawable.serial);
                return;
            case 2:
                if (this.m_cCameraView.GetPanoMode() == 1) {
                    this.m_btnCapture.setImageResource(R.drawable.panorama_stop);
                    return;
                } else {
                    this.m_btnCapture.setImageResource(R.drawable.panorama_start);
                    return;
                }
            default:
                return;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void ShowNormalScreen() {
        if (this.m_cBmpSmalPostView != null) {
            this.m_btnGalleryInternal.setImageBitmap(this.m_cBmpSmalPostView);
            this.m_cBmpSmalPostView = null;
        }
        if (this.m_bIndexInGallery) {
            this.m_cCameraView.IndexingPathInGallery(this.m_strLastFile);
        }
        this.m_cHandler.removeCallbacks(this.m_cShowNormalScreen);
        this.m_cCameraView.StartPreview(false);
        this.m_cViewPreviewButtons.setVisibility(8);
        this.m_cViewMainPreviewContainer.setVisibility(4);
        this.m_bPreviewMode = false;
        this.m_cCameraView.m_cGridView.setVisibility(0);
        this.m_cCameraPreview.setVisibility(0);
        UpdateButtons();
        this.m_cCameraView.StartPreview(false);
    }

    private void ShowPreviewScreen(final Bitmap cBmpBig, Bitmap cBmpSmall, final boolean bVideo) {
        if (this.m_cCameraView.m_nPreviewTime > 0 && cBmpBig != null && cBmpSmall != null) {
            runOnUiThread(new Runnable() { // from class: com.android.camera.MainWindow.44
                @Override // java.lang.Runnable
                public void run() {
                    if (cBmpBig != null) {
                        MainWindow.this.m_cIVPreview.setImageBitmap(cBmpBig);
                    }
                    MainWindow.this.m_bIndexInGallery = true;
                    MainWindow.this.m_cCameraPreview.setVisibility(4);
                    MainWindow.this.m_cViewMainButtonsInternal.setVisibility(8);
                    MainWindow.this.m_cViewPreviewButtons.setVisibility(0);
                    MainWindow.this.m_cViewMainPreviewContainer.setVisibility(0);
                    MainWindow.this.m_cViewMainPreviewContainer.bringToFront();
                    if (bVideo) {
                        MainWindow.this.m_btnPlay.setVisibility(0);
                    } else {
                        MainWindow.this.m_btnPlay.setVisibility(8);
                    }
                    MainWindow.this.m_cCameraView.m_cGridView.setVisibility(4);
                    MainWindow.this.UpdateButtons();
                }
            });
            this.m_cBmpSmalPostView = cBmpSmall;
            this.m_cHandler.postDelayed(this.m_cShowNormalScreen, this.m_cCameraView.m_nPreviewTime);
            this.m_bPreviewMode = true;
            return;
        }
        this.m_cBmpSmalPostView = cBmpSmall;
        runOnUiThread(new Runnable() { // from class: com.android.camera.MainWindow.45
            @Override // java.lang.Runnable
            public void run() {
                MainWindow.this.ShowNormalScreen();
            }
        });
    }

    private void ShowPreviewScreen(boolean bBig) {
        Bitmap cBmp = null;
        MediaMetadataRetriever cRetreiver = new MediaMetadataRetriever();
        try {
            InvokeHelper.InvokeMethod((Object) cRetreiver, "setMode", 2);
            InvokeHelper.InvokeMethod(cRetreiver, "setDataSource", this.m_strLastFile);
            Object oBmp = InvokeHelper.InvokeMethod(cRetreiver, "captureFrame");
            Object oBmp2 = oBmp;
            if (oBmp == null) {
                oBmp2 = InvokeHelper.InvokeMethod(cRetreiver, "getFrameAtTime");
            }
            cBmp = (Bitmap) oBmp2;
        } catch (Exception e) {
        }
        if (cBmp != null) {
            ShowPreviewScreen(bBig ? cBmp : null, cBmp, true);
        }
    }

    public void ShowPostviewImage(byte[] data, boolean bShowBig) {
        Bitmap cBmpBig = null;
        Bitmap cBmpSmall = null;
        boolean bVideo = false;
        if (bShowBig) {
            try {
                BitmapFactory.Options cOpt = new BitmapFactory.Options();
                cOpt.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(data, 0, data.length, cOpt);
                long lSize = cOpt.outWidth * cOpt.outHeight;
                if (lSize > 8000000) {
                    cOpt.inSampleSize = 4;
                } else {
                    cOpt.inSampleSize = 2;
                }
                cOpt.inJustDecodeBounds = false;
                while (true) {
                    try {
                        cBmpBig = BitmapFactory.decodeByteArray(data, 0, data.length, cOpt);
                        break;
                    } catch (OutOfMemoryError e) {
                        cOpt.inSampleSize *= 2;
                    }
                }
                bVideo = true;
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        try {
            BitmapFactory.Options cOpt2 = new BitmapFactory.Options();
            cOpt2.inSampleSize = 16;
            cOpt2.inJustDecodeBounds = false;
            cBmpSmall = BitmapFactory.decodeByteArray(data, 0, data.length, cOpt2);
            bVideo = false;
        } catch (Exception ex2) {
            ex2.printStackTrace();
        }
        ShowPreviewScreen(cBmpBig, cBmpSmall, bVideo);
    }

    private void UpdateSettingsTab() {
        String strText;
        String strText2;
        String strText3;
        this.m_cCheckBoxShowGrid.setChecked(this.m_cCameraView.m_cGridView.getShowGrid());
        this.m_cCheckBoxAutoStartNew.setChecked(this.m_cCameraView.m_bStartRecordNewAfterStop);
        this.m_cCheckBoxFlashOnFocus.setChecked(this.m_cCameraView.m_bFlashOnFocus);
        this.m_cCheckBoxVibrate.setChecked(this.m_cCameraView.m_bVibrate);
        this.m_cCheckBoxRunOnCameraButton.setChecked(this.m_cCameraView.getRunOnCameraPress());
        this.m_cCheckBoxTurnOffSounds.setChecked(this.m_cCameraView.getTurnOffSounds());
        this.m_cCheckBoxMaxBrightness.setChecked(this.m_cCameraView.m_bUseMaxBrightness);
        this.m_cCheckBoxSensorFocus.setChecked(this.m_cCameraView.getAllowSensorFocus());
        this.m_cCheckBoxForcedAF.setChecked(this.m_cCameraView.getForcedAF());
        this.m_cCheckBoxLongClickShutter.setChecked(this.m_cCameraView.m_bLongClickShutter);
        this.m_cCheckBoxSaveDebugLog.setChecked(DebugLog.m_bDebug);
        this.m_cCheckBoxUseSEC.setOnCheckedChangeListener(null);
        this.m_cCheckBoxUseSEC.setChecked(this.m_cCameraView.IsUseSEC());
        if (SecCameraWrapper.IsSECSupported()) {
            this.m_viewUseSEC.setVisibility(0);
        } else {
            this.m_viewUseSEC.setVisibility(8);
        }
        this.m_cCheckBoxUseSEC.setOnCheckedChangeListener(this);
        File cFile = new File(DebugLog.m_strFileName);
        if (cFile.exists() && cFile.length() > 10000) {
            findViewById(R.id.buttonSendLog).setOnClickListener(this);
            findViewById(R.id.buttonSendLog).setVisibility(0);
        } else {
            findViewById(R.id.buttonSendLog).setVisibility(8);
        }
        Resources cRes = getResources();
        String[] strArButtons = cRes.getStringArray(R.array.PreviewTime);
        switch (this.m_cCameraView.m_nPreviewTime) {
            case 0:
                strText = strArButtons[0];
                break;
            case 3000:
                strText = strArButtons[1];
                break;
            case 5000:
                strText = strArButtons[2];
                break;
            default:
                strText = strArButtons[3];
                break;
        }
        ((TextView) this.m_btnPreviewTime.findViewById(16908309)).setText(strText);
        String[] strArButtons2 = cRes.getStringArray(R.array.ShutterFocusButtons);
        switch (this.m_cCameraView.m_nFocusKeyCode) {
            case 5:
                strText2 = strArButtons2[5];
                break;
            case CameraView.PANORAMA_CANCELED /* 23 */:
                strText2 = strArButtons2[3];
                break;
            case 24:
                strText2 = strArButtons2[6];
                break;
            case 25:
                strText2 = strArButtons2[7];
                break;
            case 27:
                strText2 = strArButtons2[1];
                break;
            case 66:
                strText2 = strArButtons2[2];
                break;
            case 84:
                strText2 = strArButtons2[4];
                break;
            default:
                strText2 = strArButtons2[0];
                break;
        }
        ((TextView) this.m_btnFocusButton.findViewById(16908309)).setText(strText2);
        switch (this.m_cCameraView.m_nShutterKeyCode) {
            case 5:
                strText3 = strArButtons2[5];
                break;
            case CameraView.PANORAMA_CANCELED /* 23 */:
                strText3 = strArButtons2[3];
                break;
            case 24:
                strText3 = strArButtons2[6];
                break;
            case 25:
                strText3 = strArButtons2[7];
                break;
            case 66:
                strText3 = strArButtons2[2];
                break;
            case 80:
                strText3 = strArButtons2[0];
                break;
            case 84:
                strText3 = strArButtons2[4];
                break;
            default:
                strText3 = strArButtons2[1];
                break;
        }
        ((TextView) this.m_btnShutterButton.findViewById(16908309)).setText(strText3);
        if (this.m_cCameraView.getSaveInIMAGEVIDEO()) {
            ((TextView) this.m_btnFileNaming.findViewById(16908309)).setText(cRes.getStringArray(R.array.FormatFileName)[1]);
        } else {
            ((TextView) this.m_btnFileNaming.findViewById(16908309)).setText(cRes.getStringArray(R.array.FormatFileName)[0]);
        }
        ((TextView) this.m_btnFolderSave.findViewById(16908309)).setText(CameraView.getFolder());
    }

    private void ShowCameraScriptDlg() {
        EditCameraScriptDlg cDlg = new EditCameraScriptDlg(this, this.m_cCameraView.m_strScript, new EditCameraScriptDlg.OnScriptChangedListener() { // from class: com.android.camera.MainWindow.46
            @Override // com.android.camera.EditCameraScriptDlg.OnScriptChangedListener
            public void scriptDefault(EditCameraScriptDlg cDlg2) {
                cDlg2.FillScript(MainWindow.this.m_cCameraView.m_strScriptDefault);
            }

            @Override // com.android.camera.EditCameraScriptDlg.OnScriptChangedListener
            public void scriptChanged(String strFolder) {
                String[] strArFields = strFolder.replace("\n", ";").replace("\r", ";").replace(";;", ";").split(";");
                StringBuilder cBuilder = new StringBuilder();
                for (String str : strArFields) {
                    String strRow = str.trim();
                    if (strRow.length() > 0) {
                        if (cBuilder.length() > 0) {
                            cBuilder.append(";");
                        }
                        cBuilder.append(strRow);
                    }
                }
                MainWindow.this.m_cCameraView.m_strScript = cBuilder.toString();
                MainWindow.this.m_cCameraView.StartPreview(false);
            }
        });
        cDlg.show();
    }

    private void SelectPreviewTimeDlg() {
        this.m_cTextViewListParamsTitle.setText(R.string.Preview);
        this.m_cListViewParamsWnd.setVisibility(0);
        ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, getResources().getStringArray(R.array.PreviewTime));
        this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
        this.m_cListViewParams.setChoiceMode(1);
        switch (this.m_cCameraView.m_nPreviewTime) {
            case 0:
                this.m_cListViewParams.setItemChecked(0, true);
                break;
            case 3000:
                this.m_cListViewParams.setItemChecked(1, true);
                break;
            case 5000:
                this.m_cListViewParams.setItemChecked(2, true);
                break;
            default:
                this.m_cListViewParams.setItemChecked(3, true);
                break;
        }
        this.m_cViewIncludeCameraSettings.setVisibility(4);
        this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.47
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                switch (arg2) {
                    case 0:
                        MainWindow.this.m_cCameraView.m_nPreviewTime = 0;
                        break;
                    case 1:
                        MainWindow.this.m_cCameraView.m_nPreviewTime = 3000;
                        break;
                    case 2:
                        MainWindow.this.m_cCameraView.m_nPreviewTime = 5000;
                        break;
                    case 3:
                        MainWindow.this.m_cCameraView.m_nPreviewTime = Integer.MAX_VALUE;
                        break;
                }
                MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                MainWindow.this.UpdateControls();
            }
        });
    }

    private void SelectFocusKeyCodeDlg() {
        int nSelItem;
        String[] strArray = getResources().getStringArray(R.array.ShutterFocusButtons);
        switch (this.m_cCameraView.m_nFocusKeyCode) {
            case 5:
                nSelItem = 5;
                break;
            case CameraView.PANORAMA_CANCELED /* 23 */:
                nSelItem = 3;
                break;
            case 24:
                nSelItem = 6;
                break;
            case 25:
                nSelItem = 7;
                break;
            case 27:
                nSelItem = 1;
                break;
            case 66:
                nSelItem = 2;
                break;
            case 84:
                nSelItem = 4;
                break;
            default:
                nSelItem = 0;
                break;
        }
        this.m_cTextViewListParamsTitle.setText(R.string.FocusButton);
        this.m_cListViewParamsWnd.setVisibility(0);
        ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, strArray);
        this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
        this.m_cListViewParams.setChoiceMode(1);
        if (nSelItem >= 0) {
            this.m_cListViewParams.setItemChecked(nSelItem, true);
        }
        this.m_cViewIncludeCameraSettings.setVisibility(4);
        this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.48
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                switch (arg2) {
                    case 1:
                        MainWindow.this.m_cCameraView.m_nFocusKeyCode = 27;
                        break;
                    case 2:
                        MainWindow.this.m_cCameraView.m_nFocusKeyCode = 66;
                        break;
                    case 3:
                        MainWindow.this.m_cCameraView.m_nFocusKeyCode = 23;
                        break;
                    case 4:
                        MainWindow.this.m_cCameraView.m_nFocusKeyCode = 84;
                        break;
                    case 5:
                        MainWindow.this.m_cCameraView.m_nFocusKeyCode = 5;
                        break;
                    case 6:
                        MainWindow.this.m_cCameraView.m_nFocusKeyCode = 24;
                        break;
                    case 7:
                        MainWindow.this.m_cCameraView.m_nFocusKeyCode = 25;
                        break;
                    default:
                        MainWindow.this.m_cCameraView.m_nFocusKeyCode = 80;
                        break;
                }
                MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                MainWindow.this.UpdateControls();
            }
        });
    }

    private void SelectShutterKeyCodeDlg() {
        int nSelItem;
        String[] strArray = getResources().getStringArray(R.array.ShutterFocusButtons);
        switch (this.m_cCameraView.m_nShutterKeyCode) {
            case 5:
                nSelItem = 5;
                break;
            case CameraView.PANORAMA_CANCELED /* 23 */:
                nSelItem = 3;
                break;
            case 24:
                nSelItem = 6;
                break;
            case 25:
                nSelItem = 7;
                break;
            case 66:
                nSelItem = 2;
                break;
            case 80:
                nSelItem = 0;
                break;
            case 84:
                nSelItem = 4;
                break;
            default:
                nSelItem = 1;
                break;
        }
        this.m_cTextViewListParamsTitle.setText(R.string.ShutterButton);
        this.m_cListViewParamsWnd.setVisibility(0);
        ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, strArray);
        this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
        this.m_cListViewParams.setChoiceMode(1);
        if (nSelItem >= 0) {
            this.m_cListViewParams.setItemChecked(nSelItem, true);
        }
        this.m_cViewIncludeCameraSettings.setVisibility(4);
        this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.49
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                switch (arg2) {
                    case 0:
                        MainWindow.this.m_cCameraView.m_nShutterKeyCode = 80;
                        break;
                    case 1:
                    default:
                        MainWindow.this.m_cCameraView.m_nShutterKeyCode = 27;
                        break;
                    case 2:
                        MainWindow.this.m_cCameraView.m_nShutterKeyCode = 66;
                        break;
                    case 3:
                        MainWindow.this.m_cCameraView.m_nShutterKeyCode = 23;
                        break;
                    case 4:
                        MainWindow.this.m_cCameraView.m_nShutterKeyCode = 84;
                        break;
                    case 5:
                        MainWindow.this.m_cCameraView.m_nShutterKeyCode = 5;
                        break;
                    case 6:
                        MainWindow.this.m_cCameraView.m_nShutterKeyCode = 24;
                        break;
                    case 7:
                        MainWindow.this.m_cCameraView.m_nShutterKeyCode = 25;
                        break;
                }
                MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                MainWindow.this.UpdateControls();
            }
        });
    }

    private void SelectAutoShutterDelayDlg() {
        int nSelItem;
        String[] strArray = getResources().getStringArray(R.array.AutoShutterTimer);
        switch (this.m_nAutoTimerSeconds) {
            case 5:
                nSelItem = 0;
                break;
            case 10:
                nSelItem = 1;
                break;
            case 30:
                nSelItem = 3;
                break;
            case 60:
                nSelItem = 4;
                break;
            default:
                nSelItem = 2;
                break;
        }
        this.m_cTextViewListParamsTitle.setText(R.string.AutoShutter);
        this.m_cListViewParamsWnd.setVisibility(0);
        ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, strArray);
        this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
        this.m_cListViewParams.setChoiceMode(1);
        if (nSelItem >= 0) {
            this.m_cListViewParams.setItemChecked(nSelItem, true);
        }
        this.m_cViewIncludeCameraSettings.setVisibility(4);
        this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.50
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                switch (arg2) {
                    case 0:
                        MainWindow.this.m_nAutoTimerSeconds = 5;
                        break;
                    case 1:
                        MainWindow.this.m_nAutoTimerSeconds = 10;
                        break;
                    case 2:
                    default:
                        MainWindow.this.m_nAutoTimerSeconds = 15;
                        break;
                    case 3:
                        MainWindow.this.m_nAutoTimerSeconds = 30;
                        break;
                    case 4:
                        MainWindow.this.m_nAutoTimerSeconds = 60;
                        break;
                }
                MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                MainWindow.this.UpdateControls();
            }
        });
    }

    private void SelectFileNameFormatDlg() {
        this.m_cTextViewListParamsTitle.setText(R.string.FileNaming);
        this.m_cListViewParamsWnd.setVisibility(0);
        ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, getResources().getStringArray(R.array.FormatFileName));
        this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
        this.m_cListViewParams.setChoiceMode(1);
        if (this.m_cCameraView.getSaveInIMAGEVIDEO()) {
            this.m_cListViewParams.setItemChecked(1, true);
        } else {
            this.m_cListViewParams.setItemChecked(0, true);
        }
        this.m_cViewIncludeCameraSettings.setVisibility(4);
        this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.51
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                MainWindow.this.m_cCameraView.setSaveInIMAGEVIDEO(arg2 == 1);
                MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                MainWindow.this.UpdateControls();
            }
        });
    }

    private void SelectFolderDlg(boolean bShowAccessWnd) {
        if (!bShowAccessWnd) {
            SelectFolderDialog cDlg = new SelectFolderDialog(this, CameraView.getFolder(), new SelectFolderDialog.OnFolderChangedListener() { // from class: com.android.camera.MainWindow.52
                @Override // com.android.camera.SelectFolderDialog.OnFolderChangedListener
                public void folderChanged(String strNewFolder) {
                    CameraView.setFolder(MainWindow.this.getApplicationContext(), strNewFolder);
                    MainWindow.this.UpdateControls();
                }

                @Override // com.android.camera.SelectFolderDialog.OnFolderChangedListener
                public void folderDefault(SelectFolderDialog cDlg2) {
                    cDlg2.SetFolder(String.valueOf(Environment.getExternalStorageDirectory().getAbsolutePath()) + "/DCIM/Camera");
                }
            }, true);
            cDlg.show();
            return;
        }
        RequestAccessToSDCard();
    }

    private String getAspectString(Point ptRes) {
        float fAspect = ptRes.x / ptRes.y;
        float fDiff = Math.abs(2.0f - fAspect);
        String strAspect = "2:1";
        if (Math.abs(1.5f - fAspect) < fDiff) {
            strAspect = "3:2";
            fDiff = Math.abs(1.5f - fAspect);
        }
        if (Math.abs(1.3333334f - fAspect) < fDiff) {
            strAspect = "4:3";
            fDiff = Math.abs(1.3333334f - fAspect);
        }
        if (Math.abs(1.6666666f - fAspect) < fDiff) {
            strAspect = "5:3";
            fDiff = Math.abs(1.6666666f - fAspect);
        }
        if (Math.abs(1.5f - fAspect) < fDiff) {
            strAspect = "15:10";
            fDiff = Math.abs(1.5f - fAspect);
        }
        if (Math.abs(1.7777778f - fAspect) < fDiff) {
            Math.abs(1.7777778f - fAspect);
            return "16:9";
        }
        return strAspect;
    }

    public void UpdateGalleryIcon() {
        try {
            MediaFile cMedia = getLatestFile();
            Bitmap thumbnail = null;
            if (cMedia != null) {
                if (cMedia.m_bVideo) {
                    thumbnail = MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), cMedia.m_lId, 1, null);
                } else {
                    thumbnail = MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(), cMedia.m_lId, 1, null);
                }
            }
            this.m_btnGalleryInternal.setImageBitmap(thumbnail);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public class MediaFile {
        public boolean m_bVideo;
        public long m_lId;
        public int m_nOrientation;

        MediaFile(long lId, boolean bVideo, int nOrientation) {
            this.m_lId = lId;
            this.m_bVideo = bVideo;
            this.m_nOrientation = nOrientation;
        }
    }

    private MediaFile getMediaFile(String strFileName) {
        MediaFile media;
        boolean bVideo = true;
        bVideo = (strFileName.indexOf(".jpg") > 0 || strFileName.indexOf(".JPG") > 0) ? false : false;
        Uri baseUri = bVideo ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        Uri query = baseUri.buildUpon().appendQueryParameter("limit", "1").build();
        String[] projection = bVideo ? new String[]{"_id", "datetaken"} : new String[]{"_id", "datetaken", "orientation"};
        String selection = "_data = '" + strFileName + "'";
        String order = bVideo ? "datetaken DESC,_id DESC" : "datetaken DESC,_id DESC";
        Cursor cursor = null;
        try {
            try {
                cursor = getContentResolver().query(query, projection, selection, null, order);
                if (cursor == null || !cursor.moveToFirst()) {
                    media = null;
                } else {
                    long lId = cursor.getLong(0);
                    int nOrientation = bVideo ? 0 : cursor.getInt(2);
                    media = new MediaFile(lId, bVideo, nOrientation);
                }
                if (cursor != null) {
                    cursor.close();
                    return media;
                }
                return media;
            } catch (Exception ex) {
                ex.printStackTrace();
                if (cursor == null) {
                    return null;
                }
                cursor.close();
                return null;
            }
        } catch (Throwable th) {
            if (cursor != null) {
                cursor.close();
            }
            throw th;
        }
    }

    private MediaFile getLatestFile() {
        File cDir = new File(CameraView.getFolder());
        File[] cArImages = cDir.listFiles(new FilenameFilter() { // from class: com.android.camera.MainWindow.53
            @Override // java.io.FilenameFilter
            public boolean accept(File dir, String filename) {
                int nPos = filename.lastIndexOf(46);
                if (nPos != -1) {
                    String strExt = filename.substring(nPos + 1);
                    if (strExt.equalsIgnoreCase("mp4") || strExt.equalsIgnoreCase("3gp") || strExt.equalsIgnoreCase("jpg")) {
                        return true;
                    }
                }
                return false;
            }
        });
        Arrays.sort(cArImages, new Comparator<File>() { // from class: com.android.camera.MainWindow.54
            @Override // java.util.Comparator
            public int compare(File lhs, File rhs) {
                if (lhs.lastModified() < rhs.lastModified()) {
                    return 1;
                }
                if (lhs.lastModified() > rhs.lastModified()) {
                    return -1;
                }
                return 0;
            }
        });
        for (File file : cArImages) {
            MediaFile cMedia = getMediaFile(file.getAbsolutePath());
            if (cMedia != null) {
                return cMedia;
            }
        }
        return null;
    }

    @Override // rubberbigpepper.CommonCtrl.CGridView.GridViewListener
    public void OnScale(float fScale) {
        if (this.m_cZoomProgress.getVisibility() == 0) {
            if (fScale > 1.0f) {
                this.m_cZoomProgress.setProgress(this.m_cZoomProgress.getProgress() + 1);
                this.m_cCameraView.setZoomValue(this.m_cZoomProgress.getProgress() + 1);
            }
            if (fScale < 1.0f) {
                this.m_cZoomProgress.setProgress(this.m_cZoomProgress.getProgress() - 1);
                this.m_cCameraView.setZoomValue(this.m_cZoomProgress.getProgress() + 1);
            }
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CGridView.GridViewListener
    public void OnLongClick() {
        if (this.m_cCameraView.m_bLongClickShutter) {
            if (this.m_cCameraView.IsStarted()) {
                this.m_cCameraView.StopRecord();
                return;
            }
            Log.e("lgCamera", "Long click shutter");
            boolean bLastForceAF = this.m_cCameraView.getForcedAF();
            this.m_cCameraView.setForcedAF(true);
            this.m_cCameraView.CapturePhoto(false);
            this.m_cCameraView.setForcedAF(bLastForceAF);
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CGridView.GridViewListener
    public void OnTap(float fX, float fY) {
        Log.e("lgCamera", String.format("X=%d, Y=%d", Integer.valueOf((int) fX), Integer.valueOf((int) fY)));
        float fX2 = (this.m_cCameraView.m_ptPreviewSize.x * fX) / this.m_ptPreviewSize.x;
        float fY2 = (this.m_cCameraView.m_ptPreviewSize.y * fY) / this.m_ptPreviewSize.y;
        String strFM = this.m_cCameraView.getFocusMode();
        if (!strFM.equals("fixed") && !strFM.equals("infinity") && !strFM.equals("macro")) {
            this.m_cCameraView.MakeFocus((int) fX2, (int) fY2);
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CGridView.GridViewListener
    public void OnSwipeLeftToRight() {
        if (!IsCtrlPanelShowing()) {
            ShowCtrlPanel();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CGridView.GridViewListener
    public void OnSwipeRightToLeft() {
        if (this.m_btnGallery.getVisibility() == 0) {
            this.m_btnGallery.performClick();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CGridView.GridViewListener
    public void OnSwipeTopToBottom() {
        if (this.m_btnSwitchCamera.getVisibility() == 0) {
            this.m_btnSwitchCamera.performClick();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CGridView.GridViewListener
    public void OnSwipeBottomToTop() {
        if (this.m_btnSwitchCamera.getVisibility() == 0) {
            this.m_btnSwitchCamera.performClick();
        }
    }

    private void SelectSlowMotionDlg() {
        this.m_cTextViewListParamsTitle.setText(R.string.SlowMotion);
        this.m_cListViewParamsWnd.setVisibility(0);
        ArrayAdapter<String> cAdapter = new ArrayAdapter<>(this, (int) R.layout.list_item, getResources().getStringArray(R.array.SlowfastMotionMultiply));
        this.m_cListViewParams.setAdapter((ListAdapter) cAdapter);
        this.m_cListViewParams.setChoiceMode(1);
        if (this.m_cCameraView.m_fSlowMotionModule <= 0.25f) {
            this.m_cListViewParams.setItemChecked(0, true);
        } else if (this.m_cCameraView.m_fSlowMotionModule <= 0.33f) {
            this.m_cListViewParams.setItemChecked(1, true);
        } else if (this.m_cCameraView.m_fSlowMotionModule <= 0.5f) {
            this.m_cListViewParams.setItemChecked(2, true);
        } else if (this.m_cCameraView.m_fSlowMotionModule >= 4.0f) {
            this.m_cListViewParams.setItemChecked(6, true);
        } else if (this.m_cCameraView.m_fSlowMotionModule >= 3.0f) {
            this.m_cListViewParams.setItemChecked(5, true);
        } else if (this.m_cCameraView.m_fSlowMotionModule >= 2.0f) {
            this.m_cListViewParams.setItemChecked(4, true);
        } else {
            this.m_cListViewParams.setItemChecked(3, true);
        }
        this.m_cViewIncludeCameraSettings.setVisibility(4);
        this.m_cListViewParams.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.android.camera.MainWindow.55
            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                switch (arg2) {
                    case 0:
                        MainWindow.this.m_cCameraView.m_fSlowMotionModule = 0.25f;
                        break;
                    case 1:
                        MainWindow.this.m_cCameraView.m_fSlowMotionModule = 0.33333334f;
                        break;
                    case 2:
                        MainWindow.this.m_cCameraView.m_fSlowMotionModule = 0.5f;
                        break;
                    case 3:
                    default:
                        MainWindow.this.m_cCameraView.m_fSlowMotionModule = 1.0f;
                        break;
                    case 4:
                        MainWindow.this.m_cCameraView.m_fSlowMotionModule = 2.0f;
                        break;
                    case 5:
                        MainWindow.this.m_cCameraView.m_fSlowMotionModule = 3.0f;
                        break;
                    case 6:
                        MainWindow.this.m_cCameraView.m_fSlowMotionModule = 4.0f;
                        break;
                }
                MainWindow.this.m_cListViewParamsWnd.setVisibility(4);
                MainWindow.this.m_cViewIncludeCameraSettings.setVisibility(0);
                MainWindow.this.UpdateControls();
            }
        });
    }

    protected void SetAppIcon(boolean bPro) {
        try {
            PackageManager cPM = getPackageManager();
            String strPN = getPackageName();
            if (bPro) {
                cPM.setComponentEnabledSetting(new ComponentName(strPN, String.valueOf(strPN) + ".MainWindowPro"), 1, 1);
                cPM.setComponentEnabledSetting(new ComponentName(strPN, String.valueOf(strPN) + ".MainWindowFree"), 2, 1);
            } else {
                cPM.setComponentEnabledSetting(new ComponentName(strPN, String.valueOf(strPN) + ".MainWindowFree"), 1, 1);
                cPM.setComponentEnabledSetting(new ComponentName(strPN, String.valueOf(strPN) + ".MainWindowPro"), 2, 1);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void RequestAccessToSDCard() {
        if (CameraView.m_treeUri != null) {
            List<UriPermission> cArPermiss = getContentResolver().getPersistedUriPermissions();
            for (int n = 0; n < cArPermiss.size(); n++) {
                UriPermission cUriPerm = cArPermiss.get(n);
                try {
                    if (cUriPerm.getUri().equals(CameraView.m_treeUri) && cUriPerm.isWritePermission()) {
                        SelectFolderDlg(false);
                        return;
                    }
                } catch (Exception e) {
                }
            }
        }
        AlertDialog.Builder cBuilder = new AlertDialog.Builder(this);
        cBuilder.setTitle(R.string.app_name);
        cBuilder.setMessage(R.string.SDCardPrompt);
        cBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() { // from class: com.android.camera.MainWindow.56
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface arg0, int arg1) {
                Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
                intent.putExtra("android.content.extra.SHOW_ADVANCED", true);
                MainWindow.this.startActivityForResult(intent, MainWindow.ACCESS_REQUEST_CODE);
            }
        });
        cBuilder.create().show();
    }

    @Override // android.app.Activity
    public void onActivityResult(int requestCode, int resultCode, Intent resultData) {
        if (requestCode == ACCESS_REQUEST_CODE && resultCode == -1) {
            Uri treeUri = resultData.getData();
            CameraView.m_treeUri = treeUri;
            grantUriPermission(getPackageName(), treeUri, 3);
            getContentResolver().takePersistableUriPermission(treeUri, 3);
        }
        SelectFolderDlg(false);
    }
}