package com.android.camera;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;

/* loaded from: classes.dex */
public class ColorPickerDialog extends Dialog {
    private int mInitialColor;
    private OnColorChangedListener mListener;

    /* loaded from: classes.dex */
    public interface OnColorChangedListener {
        void colorChanged(int i);
    }

    /* loaded from: classes.dex */
    private static class ColorPickerView extends View {
        private static final int CENTER_RADIUS = 32;
        private static final int CENTER_X = 100;
        private static final int CENTER_Y = 100;
        private static final float PI = 3.1415925f;
        private Paint mCenterPaint;
        private final int[] mColors;
        private boolean mHighlightCenter;
        private OnColorChangedListener mListener;
        private Paint mPaint;
        private boolean mTrackingCenter;

        ColorPickerView(Context c, OnColorChangedListener l, int color) {
            super(c);
            this.mListener = l;
            this.mColors = new int[]{-65536, -65281, -16776961, -16711681, -16711936, -256, -65536};
            Shader s = new SweepGradient(0.0f, 0.0f, this.mColors, (float[]) null);
            this.mPaint = new Paint(1);
            this.mPaint.setShader(s);
            this.mPaint.setStyle(Paint.Style.STROKE);
            this.mPaint.setStrokeWidth(32.0f);
            this.mCenterPaint = new Paint(1);
            this.mCenterPaint.setColor(color);
            this.mCenterPaint.setStrokeWidth(5.0f);
        }

        @Override // android.view.View
        protected void onDraw(Canvas canvas) {
            float r = 100.0f - (this.mPaint.getStrokeWidth() * 0.5f);
            canvas.translate(100.0f, 100.0f);
            canvas.drawOval(new RectF(-r, -r, r, r), this.mPaint);
            canvas.drawCircle(0.0f, 0.0f, 32.0f, this.mCenterPaint);
            if (this.mTrackingCenter) {
                int c = this.mCenterPaint.getColor();
                this.mCenterPaint.setStyle(Paint.Style.STROKE);
                if (this.mHighlightCenter) {
                    this.mCenterPaint.setAlpha(255);
                } else {
                    this.mCenterPaint.setAlpha(128);
                }
                canvas.drawCircle(0.0f, 0.0f, this.mCenterPaint.getStrokeWidth() + 32.0f, this.mCenterPaint);
                this.mCenterPaint.setStyle(Paint.Style.FILL);
                this.mCenterPaint.setColor(c);
            }
        }

        @Override // android.view.View
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            setMeasuredDimension(200, 200);
        }

        private int ave(int s, int d, float p) {
            return Math.round((d - s) * p) + s;
        }

        private int interpColor(int[] colors, float unit) {
            if (unit <= 0.0f) {
                return colors[0];
            }
            if (unit >= 1.0f) {
                return colors[colors.length - 1];
            }
            float p = unit * (colors.length - 1);
            int i = (int) p;
            float p2 = p - i;
            int c0 = colors[i];
            int c1 = colors[i + 1];
            int a = ave(Color.alpha(c0), Color.alpha(c1), p2);
            int r = ave(Color.red(c0), Color.red(c1), p2);
            int g = ave(Color.green(c0), Color.green(c1), p2);
            int b = ave(Color.blue(c0), Color.blue(c1), p2);
            return Color.argb(a, r, g, b);
        }

        /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
        /* JADX WARN: Removed duplicated region for block: B:14:0x0039  */
        /* JADX WARN: Removed duplicated region for block: B:17:0x0043  */
        @Override // android.view.View
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public boolean onTouchEvent(MotionEvent event) {
            float x = event.getX() - 100.0f;
            float y = event.getY() - 100.0f;
            boolean inCenter = Math.sqrt((double) ((x * x) + (y * y))) <= 32.0d;
            switch (event.getAction()) {
                case 0:
                    this.mTrackingCenter = inCenter;
                    if (inCenter) {
                        this.mHighlightCenter = true;
                        invalidate();
                        break;
                    }
                    if (!this.mTrackingCenter) {
                        if (this.mHighlightCenter != inCenter) {
                            this.mHighlightCenter = inCenter;
                            invalidate();
                            break;
                        }
                    } else {
                        float angle = (float) Math.atan2(y, x);
                        float unit = angle / 6.283185f;
                        if (unit < 0.0f) {
                            unit += 1.0f;
                        }
                        this.mCenterPaint.setColor(interpColor(this.mColors, unit));
                        invalidate();
                        break;
                    }
                    break;
                case 1:
                    if (this.mTrackingCenter) {
                        if (inCenter) {
                            this.mListener.colorChanged(this.mCenterPaint.getColor());
                        }
                        this.mTrackingCenter = false;
                        invalidate();
                        break;
                    }
                    break;
                case 2:
                    if (!this.mTrackingCenter) {
                    }
                    break;
            }
            return true;
        }
    }

    public ColorPickerDialog(Context context, OnColorChangedListener listener, int initialColor) {
        super(context);
        this.mListener = listener;
        this.mInitialColor = initialColor;
    }

    @Override // android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        OnColorChangedListener l = new OnColorChangedListener() { // from class: com.android.camera.ColorPickerDialog.1
            @Override // com.android.camera.ColorPickerDialog.OnColorChangedListener
            public void colorChanged(int color) {
                ColorPickerDialog.this.mListener.colorChanged(color);
                ColorPickerDialog.this.dismiss();
            }
        };
        setContentView(new ColorPickerView(getContext(), l, this.mInitialColor));
        setTitle(R.string.PickColor);
    }
}