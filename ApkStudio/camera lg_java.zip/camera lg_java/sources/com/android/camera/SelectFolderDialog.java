package com.android.camera;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import com.android.camera.CreateFolderDlg;
import java.io.File;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import rubberbigpepper.CommonCtrl.DocumentFile;

/* loaded from: classes.dex */
public class SelectFolderDialog extends Dialog implements AdapterView.OnItemClickListener, Comparator<File>, View.OnClickListener {
    private boolean m_bShowCreate;
    private Context m_cContext;
    private ListView m_cLVFolders;
    private OnFolderChangedListener m_cListener;
    private TextView m_cTextViewFolder;
    private String m_strFolder;

    /* loaded from: classes.dex */
    public interface OnFolderChangedListener {
        void folderChanged(String str);

        void folderDefault(SelectFolderDialog selectFolderDialog);
    }

    public SelectFolderDialog(Context context, String strFolder, OnFolderChangedListener cListener, boolean bShowCreate) {
        super(context);
        this.m_strFolder = "";
        this.m_cListener = null;
        this.m_bShowCreate = true;
        this.m_cContext = context;
        this.m_strFolder = strFolder;
        this.m_cListener = cListener;
        this.m_bShowCreate = bShowCreate;
    }

    public void SetFolder(String strFolder) {
        FillFolderList(strFolder);
    }

    @Override // android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_folder);
        this.m_cTextViewFolder = (TextView) findViewById(R.id.textViewSelectedFolder);
        this.m_cLVFolders = (ListView) findViewById(R.id.listViewFolder);
        this.m_cLVFolders.setOnItemClickListener(this);
        findViewById(R.id.buttonDefault).setOnClickListener(this);
        if (this.m_bShowCreate) {
            findViewById(R.id.buttonCreate).setOnClickListener(this);
        } else {
            findViewById(R.id.buttonCreate).setVisibility(8);
        }
        findViewById(R.id.buttonApply).setOnClickListener(this);
        findViewById(R.id.buttonCancel).setOnClickListener(this);
        FillFolderList(this.m_strFolder);
        setTitle(this.m_cContext.getResources().getString(R.string.SelectedFolder));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void FillFolderList(String strFolder) {
        HashMap<String, String> cMap;
        Log.e("SelectFolder", "Folder to fill=" + strFolder);
        File[] cArEntries = null;
        String strRootFolder = "/";
        while (strFolder.length() > 1) {
            try {
                File cFile = new File(strFolder);
                cArEntries = cFile.listFiles();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            if (cArEntries != null) {
                break;
            }
            int nPos = strFolder.lastIndexOf("/");
            if (nPos > 0) {
                strFolder = strFolder.substring(0, nPos);
            }
        }
        if (cArEntries != null) {
            Arrays.sort(cArEntries, this);
            this.m_strFolder = strFolder;
            this.m_cTextViewFolder.setText(strFolder);
            List<Map<String, ?>> cArItems = new Vector<>();
            HashMap<String, String> cMap2 = new HashMap<>();
            int nPos2 = strFolder.lastIndexOf("/");
            if (nPos2 > 0) {
                strRootFolder = strFolder.substring(0, nPos2);
            }
            Log.e("SelectFolder", "Root folder=" + strRootFolder);
            cMap2.put("Name", "..");
            cMap2.put("Path", strRootFolder);
            cArItems.add(cMap2);
            int n = 0;
            HashMap<String, String> cMap3 = cMap2;
            while (n < cArEntries.length) {
                try {
                    File cEntry = cArEntries[n];
                    if (cEntry.isDirectory()) {
                        cMap = new HashMap<>();
                        try {
                            cMap.put("Name", cEntry.getName());
                            cMap.put("Path", cEntry.getAbsolutePath());
                            cArItems.add(cMap);
                        } catch (Exception e) {
                        }
                    } else {
                        cMap = cMap3;
                    }
                    n++;
                    cMap3 = cMap;
                } catch (Exception e2) {
                }
            }
            SimpleAdapter cAdapter = new SimpleAdapter(this.m_cContext, cArItems, R.layout.folder_item, new String[]{"Name", "Path"}, new int[]{R.id.textFolderName, R.id.textFolderPath});
            this.m_cLVFolders.setAdapter((ListAdapter) cAdapter);
        }
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
        TextView cTVFolder = (TextView) arg1.findViewById(R.id.textFolderPath);
        String strFolder = cTVFolder.getText().toString();
        FillFolderList(strFolder);
    }

    @Override // java.util.Comparator
    public int compare(File arg0, File arg1) {
        return arg0.getName().compareToIgnoreCase(arg1.getName());
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View arg0) {
        switch (arg0.getId()) {
            case R.id.buttonCancel /* 2131230779 */:
                dismiss();
                return;
            case R.id.buttonDefault /* 2131230781 */:
                if (this.m_cListener != null) {
                    this.m_cListener.folderDefault(this);
                    return;
                }
                return;
            case R.id.buttonApply /* 2131230782 */:
                if (this.m_cListener != null) {
                    this.m_cListener.folderChanged(this.m_strFolder);
                }
                dismiss();
                return;
            case R.id.buttonCreate /* 2131230876 */:
                CreateFolderDlg cDlg = new CreateFolderDlg(this.m_cContext, new CreateFolderDlg.OnFolderCreate() { // from class: com.android.camera.SelectFolderDialog.1
                    @Override // com.android.camera.CreateFolderDlg.OnFolderCreate
                    public void onCreateFolder(String strFolder) {
                        if (SelectFolderDialog.this.m_strFolder.length() > 0 && SelectFolderDialog.this.m_strFolder.charAt(SelectFolderDialog.this.m_strFolder.length() - 1) != '/') {
                            SelectFolderDialog selectFolderDialog = SelectFolderDialog.this;
                            selectFolderDialog.m_strFolder = String.valueOf(selectFolderDialog.m_strFolder) + "/";
                        }
                        File cFile = new File(String.valueOf(SelectFolderDialog.this.m_strFolder) + strFolder);
                        DocumentFile.MkDirs(cFile, SelectFolderDialog.this.m_cContext.getApplicationContext(), CameraView.m_treeUri);
                        SelectFolderDialog.this.FillFolderList(cFile.getAbsolutePath());
                    }
                });
                cDlg.show();
                return;
            default:
                return;
        }
    }
}