package com.android.camera;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

/* loaded from: classes.dex */
public class CreateFolderDlg extends Dialog implements View.OnClickListener {
    private EditText m_cEditText;
    private OnFolderCreate m_cListener;

    /* loaded from: classes.dex */
    public interface OnFolderCreate {
        void onCreateFolder(String str);
    }

    public CreateFolderDlg(Context context, OnFolderCreate cListener) {
        super(context);
        this.m_cListener = null;
        this.m_cListener = cListener;
    }

    @Override // android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.FolderCreate);
        setContentView(R.layout.create_folder);
        this.m_cEditText = (EditText) findViewById(R.id.editTextFolder);
        findViewById(R.id.buttonOK).setOnClickListener(this);
        findViewById(R.id.buttonCancel).setOnClickListener(this);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View arg0) {
        switch (arg0.getId()) {
            case R.id.buttonOK /* 2131230778 */:
                if (this.m_cListener != null) {
                    String strFolder = this.m_cEditText.getText().toString().trim();
                    if (strFolder.length() > 0) {
                        this.m_cListener.onCreateFolder(strFolder);
                    }
                }
                dismiss();
                return;
            case R.id.buttonCancel /* 2131230779 */:
                dismiss();
                return;
            default:
                return;
        }
    }
}