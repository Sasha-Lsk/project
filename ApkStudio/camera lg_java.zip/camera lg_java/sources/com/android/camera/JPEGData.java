package com.android.camera;

import android.graphics.Point;
import android.text.format.Time;
import android.util.Log;
import java.io.FileOutputStream;
import rubberbigpepper.CommonCtrl.DebugLog;
import rubberbigpepper.CommonCtrl.DocumentFile;
import rubberbigpepper.CommonCtrl.JpegUtil;

/* loaded from: classes.dex */
public class JPEGData {
    protected byte[] m_byArData;
    protected String m_strFileName;
    protected long m_lDate = 0;
    protected CameraView m_cCameraView = null;
    protected boolean m_bFreeVersion = false;
    protected boolean m_bOverlay = false;
    protected Point m_szPhoto = new Point(0, 0);

    public JPEGData(byte[] byArData, String strFileName) {
        this.m_byArData = null;
        this.m_strFileName = "";
        this.m_byArData = byArData;
        this.m_strFileName = strFileName;
    }

    public void SaveJPEG() {
        JpegUtil cJpegUtil;
        try {
        } catch (Exception e) {
            ex = e;
        }
        try {
            if (this.m_bOverlay) {
                cJpegUtil = new JpegUtil(this.m_byArData);
                DebugLog.WriteDebug("cJpegUtil=new JpegUtil(byArData);");
                if (!cJpegUtil.IsAttached()) {
                    DebugLog.WriteDebug("JPEG not attached!");
                    Log.e("JPEGData", "JPEG not attached!");
                    cJpegUtil.Clear();
                    WriteFile(this.m_strFileName, this.m_byArData);
                } else {
                    DebugLog.WriteDebug("JPEG attached!");
                    UpdateEXIFData(cJpegUtil);
                    cJpegUtil.Save(this.m_strFileName);
                    DebugLog.WriteDebug("cJpegUtil.Save(m_strFileName);");
                    cJpegUtil.Clear();
                }
            } else {
                cJpegUtil = new JpegUtil();
                UpdateEXIFData(cJpegUtil);
                DebugLog.WriteDebug("JPEG file saving");
                cJpegUtil.Clear();
                WriteFile(this.m_strFileName, this.m_byArData);
            }
        } catch (Exception e2) {
            ex = e2;
            ex.printStackTrace();
            DebugLog.WriteDebug("SaveJPEG() failed " + ex.getMessage());
        }
    }

    private void UpdateEXIFData(JpegUtil cJpegUtil) {
        Time cTime = new Time();
        cTime.set(this.m_lDate);
        if (this.m_bOverlay) {
            String strText = cTime.format(" %x %X");
            if (this.m_bFreeVersion) {
                strText = String.valueOf(strText) + " (free version)";
            }
            cJpegUtil.OverlayJPEGText(strText, this.m_cCameraView);
        }
    }

    private void WriteFile(String strFileName, byte[] byData) {
        try {
            FileOutputStream cStream = new FileOutputStream(DocumentFile.WriteFile(strFileName, this.m_cCameraView.getMainWnd().getApplicationContext(), CameraView.m_treeUri));
            cStream.write(byData);
            cStream.close();
        } catch (Exception ex) {
            ex.printStackTrace();
            DebugLog.WriteDebug("JPEGUtil WriteFile error: " + ex.getMessage());
        }
    }
}