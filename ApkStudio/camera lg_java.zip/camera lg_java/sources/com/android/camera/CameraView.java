package com.android.camera;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.YuvImage;
import android.hardware.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.media.AudioManager;
import android.media.CamcorderProfile;
import android.media.MediaPlayer;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.text.format.Time;
import android.util.Log;
import android.view.SurfaceHolder;
import android.widget.Toast;
import com.android.camera.PanoramaCollection;
import com.android.camera.PanoramaWaitDlg;
import com.android.camera.SaveFileThread;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.OutputStream;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Vector;
import rubberbigpepper.CommonCtrl.BitrateSampleRateHelper;
import rubberbigpepper.CommonCtrl.CGridView;
import rubberbigpepper.CommonCtrl.CameraParamWrapper;
import rubberbigpepper.CommonCtrl.CameraWrapper;
import rubberbigpepper.CommonCtrl.DebugLog;
import rubberbigpepper.CommonCtrl.DocumentFile;
import rubberbigpepper.CommonCtrl.InvokeHelper;
import rubberbigpepper.CommonCtrl.ScriptCompile;
import rubberbigpepper.CommonCtrl.SecCameraWrapper;

/* loaded from: classes.dex */
public class CameraView implements SurfaceHolder.Callback, SensorEventListener, SaveFileThread.SaveFileListener, CameraWrapper.OnCameraWrapperEventListener, PanoramaCollection.PanoramaListener {
    public static final int AUTOFOCUSCOMPLETE = 10;
    public static final int AUTOFOCUSERROR = 14;
    public static final int BURSTPHOTO_CAPTURED = 15;
    public static final int CAMERA_SELECTED = 5;
    public static final int FOCUS_RESET = 18;
    public static final int ICSBURSTPHOTO_CAPTURED = 16;
    public static final int InsufficientSize = 7;
    public static final int MANUALFOCUS_SET = 17;
    public static final int PANORAMA_CANCELED = 23;
    public static final int PANORAMA_CREATED = 21;
    public static final int PANORAMA_CREATING = 20;
    public static final int PANORAMA_FAILED = 22;
    public static final int PANORAMA_STARTED = 19;
    public static final int PHOTO_CAPTURED = 13;
    public static final int PREVIEW_FAILED = 4;
    public static final int PUSHBUTTONDISABLE = 9;
    public static final int PUSHBUTTONENABLE = 8;
    public static final int RECORD_FAILED = 3;
    public static final int RECORD_PAUSED = 11;
    public static final int RECORD_RESUMED = 12;
    public static final int RECORD_STARTED = 1;
    public static final int RECORD_STOPPED = 2;
    public static final int VIDEO_SELECTED = 6;
    private static String m_strFolder = String.valueOf(Environment.getExternalStorageDirectory().getAbsolutePath()) + "/DCIM/Camera";
    protected static Uri m_treeUri = null;
    private boolean m_bUseSEC;
    private AudioManager m_cAudioManager;
    private CameraWrapper m_cCameraWrapper;
    protected CGridView m_cGridView;
    private SurfaceHolder m_cHolder;
    protected MainWindow m_cMainWnd;
    private int m_nExynos;
    private int m_nManufacturer;
    private int m_nModel;
    private Point m_ptSize = new Point(0, 0);
    private Point m_ptSizeFront = new Point(0, 0);
    private int m_nEncoder = 1;
    private int m_nFormat = 1;
    private boolean m_bStarted = false;
    private int m_nBitRate = 1000000;
    private int m_nBitRateFront = 1000000;
    private boolean m_bCanShot = true;
    private String m_strWB = "";
    private String m_strEffect = "";
    private String m_strFlash = "";
    private String m_strScene = "";
    private String m_strFocusMode = "";
    private String m_strAntiBanding = "";
    private String m_strISOValue = "auto";
    private String m_strAutoExposure = "";
    private int m_nExposure = 0;
    private String m_strBrightness = "";
    private String m_strSaturation = "";
    private String m_strSharpness = "";
    private String m_strContrast = "";
    private String m_strWBFront = "";
    private String m_strEffectFront = "";
    private String m_strFlashFront = "";
    private String m_strSceneFront = "";
    private String m_strFocusModeFront = "";
    private String m_strAntiBandingFront = "";
    private String m_strISOValueFront = "auto";
    private String m_strAutoExposureFront = "";
    private int m_nExposureFront = 0;
    private String m_strBrightnessFront = "";
    private String m_strSaturationFront = "";
    private String m_strSharpnessFront = "";
    private String m_strContrastFront = "";
    private int m_nSamplingRate = -1;
    private int m_nAudioBitRate = -1;
    private int m_nFrameRates = 0;
    private int m_nAutoFrameRates = 30;
    protected String m_strFileName = "";
    private int m_nAudioEncoder = 1;
    private int m_nAudioSource = 1;
    private Point m_szPhoto = new Point(0, 0);
    private Point m_szPhotoFront = new Point(0, 0);
    private Point m_szPhotoVideo = new Point(0, 0);
    private Point m_szPhotoVideoFront = new Point(0, 0);
    private boolean m_bFirstInit = true;
    private boolean m_bShutterOnScreenTouch = false;
    private boolean m_bTurnOffSounds = false;
    private boolean m_bRunOnCameraPress = true;
    private boolean m_bUseGPSEXIF = false;
    private SensorManager m_cSensorManager = null;
    private boolean m_bNeedSensorFocus = false;
    private long m_lLastTimeFocus = System.currentTimeMillis();
    private boolean m_bAllowSensorFocus = false;
    private boolean m_bOverlayDateTime = false;
    private int m_nPictureFormat = 0;
    private boolean m_bSaveInIMGVIDFile = true;
    private int m_nLastIMGIndex = 0;
    private int m_nLastVIDIndex = 0;
    private int m_nAudioChannels = 1;
    private boolean m_bForceAF = false;
    protected boolean m_bFreeVersion = true;
    protected SaveFileThread m_cSaveThread = new SaveFileThread(this, this);
    private int m_nMaxJPGSave = 5;
    private int m_nJPEGQuality = 100;
    protected boolean m_bAutoRotate = false;
    private boolean m_bPauseExist = false;
    private boolean m_bPaused = false;
    private int m_nLastSystemVolume = 0;
    private int m_nLastMusicVolume = 0;
    private int m_nCameraNum = 0;
    private int m_nMaxZoom = -1;
    private String m_strISOParamName = "";
    private String m_strMeteringParamName = "";
    private List<String> m_strArSupportedAB = null;
    private List<Integer> m_cArBitRate = new Vector();
    private List<String> m_cArAudioEncoder = new Vector();
    private List<Integer> m_cArSamplingRate = new Vector();
    private List<String> m_cArAutoExposures = null;
    private List<String> m_cArBrightnessValues = null;
    private List<String> m_cArSupportedCE = null;
    private List<String> m_cArContrastValues = null;
    private List<String> m_cArSupportedExposure = null;
    private List<String> m_cArSupportedFM = null;
    private List<String> m_cArFocusMode = null;
    private List<Integer> m_cArSupportedFrameRates = new Vector();
    private List<String> m_cArISOValues = null;
    private List<Point> m_cArPhotoSizes = null;
    private List<String> m_cArSaturationValues = null;
    private List<String> m_cArScenes = null;
    private List<String> m_cArSharpnessValues = null;
    private List<Point> m_cArVideoRes = null;
    private List<String> m_cArSupportedWB = null;
    private Class<?> m_cAudioSystemClass = null;
    protected String m_strModel = Build.MODEL.toUpperCase();
    private float[] m_fArGeomagnetic = null;
    private float[] m_fArAccelClear = null;
    private float[] m_fArR = new float[9];
    private float[] m_fArI = new float[9];
    private float[] m_fArOrient = new float[3];
    private float[] m_fArAngles = new float[3];
    protected Point m_ptPreviewSize = new Point(0, 0);
    public int m_nOverlayColor = Color.argb(192, 255, 255, 0);
    public int m_nOverlayGravity = 3;
    public String m_strOverlayFont = "normal";
    public int m_nOverlayFontSize = 30;
    public boolean m_bOverlayGPS = false;
    public boolean m_bOverlay12HourFormat = false;
    public String m_strOverlayAddText = "";
    public int m_nOverlayDateTimeFormat = 3;
    private boolean m_bVStab = false;
    private boolean m_bFocusFlash = false;
    protected int m_nPreviewTime = 3000;
    protected int m_nFocusKeyCode = 80;
    protected int m_nShutterKeyCode = 27;
    protected boolean m_bUseMaxBrightness = true;
    protected boolean m_bLongClickShutter = false;
    protected boolean m_bVibrate = false;
    protected boolean m_bFlashOnFocus = false;
    protected int m_nSDK = Build.VERSION.SDK_INT;
    private boolean m_bICSPhotoBusy = false;
    private String m_strFileNameICS = "";
    private int m_nPhotoMode = 0;
    private boolean m_bICSBurstPhotoMode = false;
    protected boolean m_bRestartCamera = true;
    private PanoramaCollection m_cPanoramaCollection = new PanoramaCollection();
    private int m_nZoom = 0;
    protected String m_strScript = "";
    protected String m_strScriptDefault = "";
    protected boolean m_bStartRecordNewAfterStop = true;
    private int m_nForceAutofocusing = 0;
    protected boolean m_bMTKDevice = false;
    private boolean m_bAELock = false;
    private boolean m_bWBLock = false;
    protected boolean m_bShowStatus = true;
    protected float m_fSlowMotionModule = 1.0f;
    private boolean m_bPanoramaTakingPic = false;
    private float m_fPanoTakeAngle = 0.0f;
    private PanoramaWaitDlg m_cWaitDlg = null;
    protected boolean m_bFullSweep = false;
    private boolean m_bAGCOff = false;
    private Runnable m_cUpdateFilesRunnable = new Runnable() { // from class: com.android.camera.CameraView.1
        @Override // java.lang.Runnable
        public void run() {
            if (CameraView.this.m_cSaveThread.getCount() < CameraView.this.m_nMaxJPGSave) {
                CameraView.this.m_bCanShot = true;
                CameraView.this.m_cMainWnd.onCameraViewAction(8);
                return;
            }
            CameraView.this.m_bCanShot = false;
            CameraView.this.m_cMainWnd.onCameraViewAction(9);
        }
    };
    private Runnable m_cUpdateButtons = new Runnable() { // from class: com.android.camera.CameraView.2
        @Override // java.lang.Runnable
        public void run() {
            CameraView.this.m_cMainWnd.UpdateControls();
            CameraView.this.m_cMainWnd.UpdateButtons();
        }
    };
    private Runnable m_cRestoreFM = new Runnable() { // from class: com.android.camera.CameraView.3
        @Override // java.lang.Runnable
        public void run() {
            CameraView.this.ResetManualFocus();
        }
    };
    private Runnable m_cUpdateGalIcon = new Runnable() { // from class: com.android.camera.CameraView.4
        @Override // java.lang.Runnable
        public void run() {
            CameraView.this.m_cMainWnd.UpdateGalleryIcon();
        }
    };
    private Runnable m_cRestorePanMess = new Runnable() { // from class: com.android.camera.CameraView.5
        @Override // java.lang.Runnable
        public void run() {
            CameraView.this.m_cMainWnd.m_cTextViewPanoMess.removeCallbacks(CameraView.this.m_cRestorePanMess);
            CameraView.this.m_cMainWnd.m_cTextViewPanoMess.setText(R.string.PanoMess);
        }
    };

    public void CancelAF() {
        if (this.m_cCameraWrapper.Initialized()) {
            this.m_cCameraWrapper.cancelAutoFocus();
        }
    }

    public MainWindow getMainWnd() {
        return this.m_cMainWnd;
    }

    public int getMaxDelayedFiles() {
        return this.m_nMaxJPGSave;
    }

    public void setMaxDelayedFiles(int nCount) {
        this.m_nMaxJPGSave = nCount;
    }

    public static String getFolder() {
        return m_strFolder;
    }

    public static void setFolder(Context cContext, String strFolder) {
        m_strFolder = strFolder;
        if (Build.VERSION.SDK_INT >= 21) {
            DocumentFile.MkDirs(strFolder, cContext, m_treeUri);
            return;
        }
        try {
            File cFile = new File(strFolder);
            cFile.mkdirs();
        } catch (Exception e) {
        }
    }

    public boolean getAutoRotate() {
        return this.m_bAutoRotate;
    }

    public void setAutoRotate(boolean bValue) {
        this.m_bAutoRotate = bValue;
    }

    public int getMaxJpegDelayCount() {
        return this.m_nMaxJPGSave;
    }

    public int getJpegDelayCount() {
        return this.m_cSaveThread.getCount();
    }

    public int getJPGQuality() {
        return this.m_nJPEGQuality;
    }

    public void setJPGQuality(int nValue) {
        this.m_nJPEGQuality = nValue;
    }

    public int getImageIndex() {
        return this.m_nLastIMGIndex;
    }

    public void setImageIndex(int nIndex) {
        this.m_nLastIMGIndex = nIndex;
    }

    public int getVideoIndex() {
        return this.m_nLastVIDIndex;
    }

    public void setVideoIndex(int nIndex) {
        this.m_nLastVIDIndex = nIndex;
    }

    public boolean getForcedAF() {
        return this.m_bForceAF;
    }

    public void setForcedAF(boolean bValue) {
        this.m_bForceAF = bValue;
    }

    public int getAudioChannels() {
        return this.m_nAudioChannels;
    }

    public void setAudioChannels(int nChannels) {
        this.m_nAudioChannels = nChannels;
    }

    public boolean getSaveInIMAGEVIDEO() {
        return this.m_bSaveInIMGVIDFile;
    }

    public void setSaveInIMAGEVIDEO(boolean bValue) {
        this.m_bSaveInIMGVIDFile = bValue;
    }

    public int getPictureFormat() {
        return this.m_nPictureFormat;
    }

    public void setPictureFormat(int nFormat) {
        this.m_nPictureFormat = nFormat;
    }

    public boolean getOverlayDateTime() {
        return this.m_bOverlayDateTime;
    }

    public void setOverlayDateTime(boolean bValue) {
        this.m_bOverlayDateTime = bValue;
    }

    public boolean getAllowSensorFocus() {
        return this.m_bAllowSensorFocus;
    }

    public void setAllowSensorFocus(boolean bValue) {
        this.m_bAllowSensorFocus = bValue;
    }

    public boolean getVideoStab() {
        return this.m_bVStab;
    }

    public void setVideoStab(boolean bVStab) {
        this.m_bVStab = bVStab;
    }

    public String getBrightness() {
        if (this.m_strBrightness.length() == 0 && this.m_nCameraNum != 1) {
            try {
                if (getSupportedBrightnessValues().size() > 0) {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    int nValue = cParams.getInt("brightness");
                    this.m_strBrightness = String.valueOf(nValue);
                }
            } catch (Exception e) {
            }
        }
        return this.m_strBrightness;
    }

    public void setBrightness(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strBrightness = strValue;
            if (this.m_strBrightness.length() > 0 && this.m_nCameraNum != 1) {
                try {
                    if (getSupportedBrightnessValues().size() > 0) {
                        CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                        cParams.set("brightness", this.m_strBrightness);
                        this.m_cCameraWrapper.SetParameters(cParams);
                    }
                } catch (Exception e) {
                }
            }
        }
    }

    public String getBrightnessFront() {
        if (this.m_strBrightnessFront.length() == 0 && this.m_nCameraNum == 1) {
            try {
                if (getSupportedBrightnessValues().size() > 0) {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    int nValue = cParams.getInt("brightness");
                    this.m_strBrightnessFront = String.valueOf(nValue);
                }
            } catch (Exception e) {
            }
        }
        return this.m_strBrightnessFront;
    }

    public void setBrightnessFront(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strBrightnessFront = strValue;
            if (this.m_strBrightnessFront.length() > 0 && this.m_nCameraNum == 1) {
                try {
                    if (getSupportedBrightnessValues().size() > 0) {
                        CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                        cParams.set("brightness", this.m_strBrightness);
                        this.m_cCameraWrapper.SetParameters(cParams);
                    }
                } catch (Exception e) {
                }
            }
        }
    }

    public String getSaturation() {
        if (this.m_strSaturation.length() == 0 && this.m_nCameraNum != 1) {
            try {
                if (getSupportedSaturationValues().size() > 0) {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    int nValue = cParams.getInt("saturation");
                    this.m_strSaturation = String.valueOf(nValue);
                }
            } catch (Exception e) {
            }
        }
        return this.m_strSaturation;
    }

    public void setSaturation(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strSaturation = strValue;
            if (this.m_strSaturation.length() > 0 && this.m_nCameraNum != 1) {
                try {
                    if (getSupportedSaturationValues().size() > 0) {
                        CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                        cParams.set("saturation", this.m_strSaturation);
                        this.m_cCameraWrapper.SetParameters(cParams);
                    }
                } catch (Exception e) {
                }
            }
        }
    }

    public String getSaturationFront() {
        if (this.m_strSaturationFront.length() == 0 && this.m_nCameraNum == 1) {
            try {
                if (getSupportedSaturationValues().size() > 0) {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    int nValue = cParams.getInt("saturation");
                    this.m_strSaturationFront = String.valueOf(nValue);
                }
            } catch (Exception e) {
            }
        }
        return this.m_strSaturationFront;
    }

    public void setSaturationFront(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strSaturationFront = strValue;
            if (this.m_strSaturationFront.length() > 0 && this.m_nCameraNum == 1) {
                try {
                    if (getSupportedSaturationValues().size() > 0) {
                        CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                        cParams.set("saturation", this.m_strSaturation);
                        this.m_cCameraWrapper.SetParameters(cParams);
                    }
                } catch (Exception e) {
                }
            }
        }
    }

    public String getContrast() {
        if (this.m_strContrast.length() == 0 && this.m_nCameraNum != 1) {
            try {
                if (getSupportedContrastValues().size() > 0) {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    int nValue = cParams.getInt("contrast");
                    this.m_strContrast = String.valueOf(nValue);
                }
            } catch (Exception e) {
            }
        }
        return this.m_strContrast;
    }

    public void setContrast(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strContrast = strValue;
            if (this.m_strContrast.length() > 0 && this.m_nCameraNum != 1) {
                try {
                    if (getSupportedContrastValues().size() > 0) {
                        CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                        cParams.set("contrast", this.m_strContrast);
                        this.m_cCameraWrapper.SetParameters(cParams);
                    }
                } catch (Exception e) {
                }
            }
        }
    }

    public String getContrastFront() {
        if (this.m_strContrastFront.length() == 0 && this.m_nCameraNum == 1) {
            try {
                if (getSupportedContrastValues().size() > 0) {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    int nValue = cParams.getInt("contrast");
                    this.m_strContrastFront = String.valueOf(nValue);
                }
            } catch (Exception e) {
            }
        }
        return this.m_strContrastFront;
    }

    public void setContrastFront(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strContrastFront = strValue;
            if (this.m_strContrastFront.length() > 0 && this.m_nCameraNum == 1) {
                try {
                    if (getSupportedContrastValues().size() > 0) {
                        CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                        cParams.set("contrast", this.m_strContrast);
                        this.m_cCameraWrapper.SetParameters(cParams);
                    }
                } catch (Exception e) {
                }
            }
        }
    }

    public String getSharpness() {
        if (this.m_strSharpness.length() == 0 && this.m_nCameraNum != 1) {
            try {
                if (getSupportedSharpnessValues().size() > 0) {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    int nValue = cParams.getInt("sharpness");
                    this.m_strSharpness = String.valueOf(nValue);
                }
            } catch (Exception e) {
            }
        }
        return this.m_strSharpness;
    }

    public void setSharpness(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strSharpness = strValue;
            if (this.m_strSharpness.length() > 0 && this.m_nCameraNum != 1) {
                try {
                    if (getSupportedSharpnessValues().size() > 0) {
                        CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                        cParams.set("sharpness", this.m_strSharpness);
                        this.m_cCameraWrapper.SetParameters(cParams);
                    }
                } catch (Exception e) {
                }
            }
        }
    }

    public String getSharpnessFront() {
        if (this.m_strSharpnessFront.length() == 0 && this.m_nCameraNum == 1) {
            try {
                if (getSupportedSharpnessValues().size() > 0) {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    int nValue = cParams.getInt("sharpness");
                    this.m_strSharpnessFront = String.valueOf(nValue);
                }
            } catch (Exception e) {
            }
        }
        return this.m_strSharpnessFront;
    }

    public void setSharpnessFront(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strSharpnessFront = strValue;
            if (this.m_strSharpnessFront.length() > 0 && this.m_nCameraNum == 1) {
                try {
                    if (getSupportedSharpnessValues().size() > 0) {
                        CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                        cParams.set("sharpness", this.m_strSharpness);
                        this.m_cCameraWrapper.SetParameters(cParams);
                    }
                } catch (Exception e) {
                }
            }
        }
    }

    public int getAudioSource() {
        return this.m_nAudioSource;
    }

    public void setAudioSource(int nValue) {
        this.m_nAudioSource = nValue;
    }

    public boolean isBusy() {
        return !this.m_bCanShot;
    }

    public MainWindow getMainWindow() {
        return this.m_cMainWnd;
    }

    public boolean getUseGPSEXIF() {
        return this.m_bUseGPSEXIF;
    }

    public void setUseGPSEXIF(boolean bValue) {
        this.m_bUseGPSEXIF = bValue;
    }

    public boolean getRunOnCameraPress() {
        return this.m_bRunOnCameraPress;
    }

    public void setRunOnCameraPress(boolean bValue) {
        this.m_bRunOnCameraPress = bValue;
    }

    public boolean getShutterOnScreenTouch() {
        return this.m_bShutterOnScreenTouch;
    }

    public void setShutterOnScreenTouch(boolean bValue) {
        this.m_bShutterOnScreenTouch = bValue;
    }

    public boolean getTurnOffSounds() {
        return this.m_bTurnOffSounds;
    }

    public void setTurnOffSounds(boolean bValue) {
        this.m_bTurnOffSounds = bValue;
    }

    public int getFormat() {
        return this.m_nFormat;
    }

    public void setFormat(int nFormat) {
        this.m_nFormat = nFormat;
    }

    public int getAudioEncoder() {
        return this.m_nAudioEncoder;
    }

    public void setAudioEncoder(int nValue) {
        this.m_nAudioEncoder = nValue;
    }

    public int getFrameRates() {
        return this.m_nFrameRates;
    }

    public void setFrameRates(int nValue) {
        this.m_nFrameRates = nValue;
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                if (this.m_nFrameRates != 0) {
                    cParams.setPreviewFrameRate(this.m_nFrameRates);
                } else {
                    cParams.setPreviewFrameRate(this.m_nAutoFrameRates);
                }
                this.m_cCameraWrapper.SetParameters(cParams);
            } catch (Exception e) {
            }
            this.m_cCameraWrapper.StartPreview();
        }
    }

    public int getSamplingRate() {
        return this.m_nSamplingRate;
    }

    public void setSamplingRate(int nValue) {
        this.m_nSamplingRate = nValue;
    }

    public int getAudioBitRate() {
        return this.m_nAudioBitRate;
    }

    public void setAudioBitRate(int nValue) {
        this.m_nAudioBitRate = nValue;
    }

    public String getEffect() {
        return this.m_strEffect;
    }

    public void setEffect(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strEffect = strValue;
            if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum != 1) {
                try {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    cParams.setColorEffect(strValue);
                    this.m_cCameraWrapper.SetParameters(cParams);
                } catch (Exception e) {
                }
            }
        }
    }

    public String getEffectFront() {
        return this.m_strEffectFront;
    }

    public void setEffectFront(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strEffectFront = strValue;
            if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum == 1) {
                try {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    cParams.setColorEffect(strValue);
                    this.m_cCameraWrapper.SetParameters(cParams);
                } catch (Exception e) {
                }
            }
        }
    }

    public String getFocusMode() {
        return this.m_strFocusMode;
    }

    public void setFocusMode(String strValue) {
        this.m_cMainWnd.m_cHandler.removeCallbacks(this.m_cRestoreFM);
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strFocusMode = strValue;
            if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum != 1) {
                try {
                    this.m_cCameraWrapper.StopFaceDetection();
                    this.m_cCameraWrapper.cancelAutoFocus();
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(true);
                    if (strValue.equalsIgnoreCase("face detection")) {
                        cParams.setFocusMode("continuous-video");
                        this.m_cCameraWrapper.StartFaceDetection();
                    } else {
                        cParams.setFocusMode(strValue);
                    }
                    cParams.setFocusAreas(null);
                    Log.e("lgCamera", "Setting FM to " + strValue);
                    this.m_cCameraWrapper.SetParameters(cParams);
                } catch (Exception e) {
                }
            }
        }
    }

    public String getFocusModeFront() {
        return this.m_strFocusModeFront;
    }

    public void setFocusModeFront(String strValue) {
        this.m_cMainWnd.m_cHandler.removeCallbacks(this.m_cRestoreFM);
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strFocusModeFront = strValue;
            if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum == 1) {
                try {
                    this.m_cCameraWrapper.StopFaceDetection();
                    this.m_cCameraWrapper.cancelAutoFocus();
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(true);
                    if (strValue.equalsIgnoreCase("face detection")) {
                        cParams.setFocusMode("continuous-video");
                        this.m_cCameraWrapper.StartFaceDetection();
                    } else {
                        cParams.setFocusMode(strValue);
                    }
                    cParams.setFocusAreas(null);
                    this.m_cCameraWrapper.SetParameters(cParams);
                } catch (Exception e) {
                }
            }
        }
    }

    public String getAntiBanding() {
        return this.m_strAntiBanding;
    }

    public void setAntiBanding(String strAntiBanding) {
        if (strAntiBanding != null && strAntiBanding.length() != 0 && !strAntiBanding.equalsIgnoreCase("null")) {
            this.m_strAntiBanding = strAntiBanding;
            if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum != 1) {
                try {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    cParams.setAntibanding(this.m_strAntiBanding);
                    this.m_cCameraWrapper.SetParameters(cParams);
                } catch (Exception e) {
                }
            }
        }
    }

    public String getAntiBandingFront() {
        return this.m_strAntiBandingFront;
    }

    public void setAntiBandingFront(String strAntiBanding) {
        if (strAntiBanding != null && strAntiBanding.length() != 0 && !strAntiBanding.equalsIgnoreCase("null")) {
            this.m_strAntiBandingFront = strAntiBanding;
            if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum == 1) {
                try {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    cParams.setAntibanding(this.m_strAntiBanding);
                    this.m_cCameraWrapper.SetParameters(cParams);
                } catch (Exception e) {
                }
            }
        }
    }

    public String getFlashMode() {
        return this.m_strFlash;
    }

    public void setFlashMode(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            boolean bRestartPreview = false;
            this.m_strFlash = strValue;
            if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum != 1) {
                bRestartPreview = (strValue.equalsIgnoreCase("off") || this.m_strFlash.equalsIgnoreCase("off")) ? true : true;
                if (bRestartPreview) {
                    try {
                        this.m_cCameraWrapper.StopPreview();
                    } catch (Exception e) {
                        return;
                    }
                }
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                cParams.setFlashMode(strValue);
                this.m_cCameraWrapper.SetParameters(cParams);
                if (bRestartPreview) {
                    this.m_cCameraWrapper.StartPreview();
                }
            }
        }
    }

    public String getFlashModeFront() {
        return this.m_strFlashFront;
    }

    public void setFlashModeFront(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            boolean bRestartPreview = false;
            this.m_strFlashFront = strValue;
            if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum == 1) {
                bRestartPreview = (strValue.equalsIgnoreCase("off") || this.m_strFlash.equalsIgnoreCase("off")) ? true : true;
                if (bRestartPreview) {
                    try {
                        this.m_cCameraWrapper.StopPreview();
                    } catch (Exception e) {
                        return;
                    }
                }
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                cParams.setFlashMode(strValue);
                this.m_cCameraWrapper.SetParameters(cParams);
                if (bRestartPreview) {
                    this.m_cCameraWrapper.StartPreview();
                }
            }
        }
    }

    public String getSceneMode() {
        return this.m_strScene;
    }

    public void setSceneMode(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strScene = strValue;
            if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum != 1) {
                try {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    cParams.setSceneMode(strValue);
                    this.m_cCameraWrapper.SetParameters(cParams);
                } catch (Exception e) {
                }
            }
        }
    }

    public String getSceneModeFront() {
        return this.m_strSceneFront;
    }

    public void setSceneModeFront(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strSceneFront = strValue;
            if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum == 1) {
                try {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    cParams.setSceneMode(strValue);
                    this.m_cCameraWrapper.SetParameters(cParams);
                } catch (Exception e) {
                }
            }
        }
    }

    public String getISO() {
        return this.m_strISOValue;
    }

    public void setISO(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strISOValue = strValue;
            if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum != 1) {
                try {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    cParams.set(getISOParameterName(), strValue);
                    this.m_cCameraWrapper.SetParameters(cParams);
                } catch (Exception e) {
                }
            }
        }
    }

    public String getISOFront() {
        return this.m_strISOValueFront;
    }

    public void setISOFront(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strISOValueFront = strValue;
            if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum == 1) {
                try {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    cParams.set(getISOParameterName(), strValue);
                    this.m_cCameraWrapper.SetParameters(cParams);
                } catch (Exception e) {
                }
            }
        }
    }

    public String getAutoExposure() {
        return this.m_strAutoExposure;
    }

    public void setAutoExposure(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strAutoExposure = strValue;
            if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum != 1) {
                try {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    cParams.set("metering", strValue);
                    cParams.set("meter-mode", strValue);
                    cParams.set("metering-mode", strValue);
                    cParams.set("auto-exposure", strValue);
                    this.m_cCameraWrapper.SetParameters(cParams);
                } catch (Exception e) {
                }
            }
        }
    }

    public String getAutoExposureFront() {
        return this.m_strAutoExposureFront;
    }

    public void setAutoExposureFront(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strAutoExposureFront = strValue;
            if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum == 1) {
                try {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    cParams.set("metering", strValue);
                    cParams.set("meter-mode", strValue);
                    cParams.set("metering-mode", strValue);
                    cParams.set("auto-exposure", strValue);
                    this.m_cCameraWrapper.SetParameters(cParams);
                } catch (Exception e) {
                }
            }
        }
    }

    public boolean IsAELockSupported() {
        try {
            CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
            return cParams.isAutoExposureLockSupported();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean getAELock() {
        return this.m_bAELock;
    }

    public void setAELock(boolean bLock) {
        this.m_bAELock = bLock;
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                cParams.setAutoExposureLock(bLock);
                this.m_cCameraWrapper.SetParameters(cParams);
            } catch (Exception e) {
            }
        }
    }

    public boolean IsWBLockSupported() {
        try {
            CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
            return cParams.isAutoWhiteBalanceLockSupported();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean getWBLock() {
        return this.m_bWBLock;
    }

    public void setWBLock(boolean bLock) {
        this.m_bWBLock = bLock;
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                cParams.setAutoWhiteBalanceLock(bLock);
                this.m_cCameraWrapper.SetParameters(cParams);
            } catch (Exception e) {
            }
        }
    }

    public int getBitRate() {
        return this.m_nBitRate;
    }

    public void setBitRate(int nValue) {
        this.m_nBitRate = nValue;
    }

    public int getBitRateFront() {
        return this.m_nBitRateFront;
    }

    public void setBitRateFront(int nValue) {
        this.m_nBitRateFront = nValue;
    }

    public boolean IsStarted() {
        return this.m_bStarted;
    }

    public Point getResolution() {
        return this.m_ptSize;
    }

    public void setResolution(Point ptSize) {
        this.m_ptSize.x = ptSize.x;
        this.m_ptSize.y = ptSize.y;
    }

    public Point getResolutionFront() {
        return this.m_ptSizeFront;
    }

    public void setResolutionFront(Point ptSize) {
        this.m_ptSizeFront.x = ptSize.x;
        this.m_ptSizeFront.y = ptSize.y;
    }

    public int getEncoder() {
        return this.m_nEncoder;
    }

    public void setEncoder(int nEncoder) {
        this.m_nEncoder = nEncoder;
    }

    public int getExposure() {
        return this.m_nExposure;
    }

    public void setExposure(int nValue) {
        this.m_nExposure = nValue;
        if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum != 1) {
            try {
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                cParams.setExposureCompensation(nValue);
                this.m_cCameraWrapper.SetParameters(cParams);
            } catch (Exception e) {
            }
        }
    }

    public int getExposureFront() {
        return this.m_nExposureFront;
    }

    public void setExposureFront(int nValue) {
        this.m_nExposureFront = nValue;
        if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum == 1) {
            try {
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                cParams.setExposureCompensation(nValue);
                this.m_cCameraWrapper.SetParameters(cParams);
            } catch (Exception e) {
            }
        }
    }

    private String getISOParameterName() {
        if (this.m_strISOParamName.length() > 0) {
            return this.m_strISOParamName;
        }
        this.m_strISOParamName = "iso";
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                String strFlatten = cParams.flatten();
                String[] strArFields = strFlatten.split(";");
                for (int n = 0; n < strArFields.length; n++) {
                    if (strArFields[n].indexOf("nv-picture-iso-values") == 0) {
                        this.m_strISOParamName = "nv-picture-iso";
                        break;
                    } else if (strArFields[n].indexOf("picture-iso-values") == 0) {
                        this.m_strISOParamName = "picture-iso";
                        break;
                    } else if (strArFields[n].indexOf("iso-values") == 0) {
                        this.m_strISOParamName = "iso";
                        break;
                    } else if (strArFields[n].indexOf("iso-speed-values") == 0) {
                        this.m_strISOParamName = "iso-speed";
                        break;
                    }
                }
            } catch (Exception e) {
            }
        }
        return this.m_strISOParamName;
    }

    public List<String> getSupportedISOValues() {
        if (this.m_cArISOValues != null) {
            return this.m_cArISOValues;
        }
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                this.m_cArISOValues = new Vector();
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                String strFlatten = cParams.flatten();
                String[] strArFields = strFlatten.split(";");
                for (int n = 0; n < strArFields.length; n++) {
                    if (strArFields[n].indexOf("iso-values") == 0) {
                        String strValue = strArFields[n].substring(11);
                        String[] strArValues = strValue.split(",");
                        for (String strISO : strArValues) {
                            this.m_cArISOValues.add(strISO);
                        }
                    }
                    if (strArFields[n].indexOf("iso-speed-values") == 0) {
                        String strValue2 = strArFields[n].substring(17);
                        String[] strArValues2 = strValue2.split(",");
                        for (String strISO2 : strArValues2) {
                            this.m_cArISOValues.add(strISO2);
                        }
                    }
                    if (strArFields[n].indexOf("picture-iso-values") == 0) {
                        String strValue3 = strArFields[n].substring(19);
                        String[] strArValues3 = strValue3.split(",");
                        for (String strISO3 : strArValues3) {
                            this.m_cArISOValues.add(strISO3);
                        }
                    }
                    if (strArFields[n].indexOf("nv-picture-iso-values") == 0) {
                        String strValue4 = strArFields[n].substring(22);
                        String[] strArValues4 = strValue4.split(",");
                        for (String strISO4 : strArValues4) {
                            this.m_cArISOValues.add(strISO4);
                        }
                    }
                }
                if (this.m_cArISOValues.size() == 0) {
                    if (this.m_nExynos > 0) {
                        this.m_cArISOValues.add("auto");
                        this.m_cArISOValues.add("50");
                        this.m_cArISOValues.add("100");
                        this.m_cArISOValues.add("200");
                        this.m_cArISOValues.add("400");
                        this.m_cArISOValues.add("800");
                        this.m_cArISOValues.add("sports");
                        this.m_cArISOValues.add("night");
                    }
                    if (this.m_strModel.indexOf("P970") >= 0 || this.m_strModel.indexOf("P920") >= 0) {
                        this.m_cArISOValues.add("auto");
                        this.m_cArISOValues.add("100");
                        this.m_cArISOValues.add("200");
                        this.m_cArISOValues.add("400");
                        this.m_cArISOValues.add("800");
                    }
                }
                return this.m_cArISOValues;
            } catch (Exception e) {
            }
        }
        return null;
    }

    public List<String> getSupportedSharpnessValues() {
        int nPos;
        if (this.m_cArSharpnessValues != null) {
            return this.m_cArSharpnessValues;
        }
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                this.m_cArSharpnessValues = new Vector();
                if (this.m_nManufacturer == 2) {
                    for (int n = 0; n < 30; n++) {
                        this.m_cArSharpnessValues.add(String.valueOf(n));
                    }
                    return this.m_cArSharpnessValues;
                }
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                String strFlatten = cParams.flatten();
                String[] strArFields = strFlatten.split(";");
                int nMinValue = -9999;
                int nMaxValue = -9999;
                int nValue = -9999;
                for (int n2 = 0; n2 < strArFields.length; n2++) {
                    if (strArFields[n2].indexOf("max-sharpness=") == 0 || strArFields[n2].indexOf("sharpness-max=") == 0) {
                        int nPos2 = strArFields[n2].indexOf("=");
                        if (nPos2 > 0) {
                            String strValue = strArFields[n2].substring(nPos2 + 1);
                            nMaxValue = Integer.valueOf(strValue).intValue();
                        }
                    } else if (strArFields[n2].indexOf("min-sharpness=") == 0 || strArFields[n2].indexOf("sharpness-min=") == 0) {
                        int nPos3 = strArFields[n2].indexOf("=");
                        if (nPos3 > 0) {
                            String strValue2 = strArFields[n2].substring(nPos3 + 1);
                            nMinValue = Integer.valueOf(strValue2).intValue();
                        }
                    } else {
                        if (strArFields[n2].indexOf("sharpness=") == 0 && (nPos = strArFields[n2].indexOf("=")) > 0) {
                            String strValue3 = strArFields[n2].substring(nPos + 1);
                            nValue = Integer.valueOf(strValue3).intValue();
                            if (this.m_strSaturation.length() == 0) {
                                this.m_strSaturation = strValue3;
                            }
                        }
                        if (strArFields[n2].indexOf("sharpness-values=") == 0) {
                            String strValue4 = strArFields[n2].substring(17);
                            String[] strArValues = strValue4.split(",");
                            for (String strItem : strArValues) {
                                this.m_cArSharpnessValues.add(strItem);
                            }
                        }
                        if ((nMinValue != -9999 && nMaxValue != -9999 && nValue != -9999 && nMaxValue > nMinValue) || this.m_cArSharpnessValues.size() > 0) {
                            break;
                        }
                    }
                }
                if (nMinValue != -9999 && nMaxValue != -9999 && nValue != -9999 && nMaxValue > nMinValue) {
                    for (int n3 = nMinValue; n3 <= nMaxValue; n3++) {
                        this.m_cArSharpnessValues.add(String.valueOf(n3));
                    }
                }
                return this.m_cArSharpnessValues;
            } catch (Exception e) {
            }
        }
        return null;
    }

    public List<String> getSupportedBrightnessValues() {
        int nPos;
        if (this.m_cArBrightnessValues != null) {
            return this.m_cArBrightnessValues;
        }
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                this.m_cArBrightnessValues = new Vector();
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                String strFlatten = cParams.flatten();
                String[] strArFields = strFlatten.split(";");
                int nMinValue = -9999;
                int nMaxValue = -9999;
                int nValue = -9999;
                for (int n = 0; n < strArFields.length; n++) {
                    if (strArFields[n].indexOf("max-brightness=") == 0 || strArFields[n].indexOf("brightness-max=") == 0) {
                        int nPos2 = strArFields[n].indexOf("=");
                        if (nPos2 > 0) {
                            String strValue = strArFields[n].substring(nPos2 + 1);
                            nMaxValue = Integer.valueOf(strValue).intValue();
                        }
                    } else if (strArFields[n].indexOf("min-brightness=") == 0 || strArFields[n].indexOf("brightness-min=") == 0) {
                        int nPos3 = strArFields[n].indexOf("=");
                        if (nPos3 > 0) {
                            String strValue2 = strArFields[n].substring(nPos3 + 1);
                            nMinValue = Integer.valueOf(strValue2).intValue();
                        }
                    } else {
                        if (strArFields[n].indexOf("brightness=") == 0 && (nPos = strArFields[n].indexOf("=")) > 0) {
                            String strValue3 = strArFields[n].substring(nPos + 1);
                            nValue = Integer.valueOf(strValue3).intValue();
                            if (this.m_strBrightness.length() == 0) {
                                this.m_strBrightness = strValue3;
                            }
                        }
                        if (strArFields[n].indexOf("brightness-values=") == 0) {
                            String strValue4 = strArFields[n].substring(18);
                            String[] strArValues = strValue4.split(",");
                            for (String strItem : strArValues) {
                                this.m_cArBrightnessValues.add(strItem);
                            }
                        }
                        if ((nMinValue != -9999 && nMaxValue != -9999 && nValue != -9999 && nMaxValue > nMinValue) || this.m_cArBrightnessValues.size() > 0) {
                            break;
                        }
                    }
                }
                if (nMinValue != -9999 && nMaxValue != -9999 && nValue != -9999 && nMaxValue > nMinValue) {
                    for (int n2 = nMinValue; n2 <= nMaxValue; n2++) {
                        this.m_cArBrightnessValues.add(String.valueOf(n2));
                    }
                }
                if ((this.m_strModel.indexOf("P970") >= 0 || this.m_strModel.indexOf("P920") >= 0) && this.m_cArBrightnessValues.size() == 0) {
                    for (int n3 = 0; n3 <= 100; n3 += 10) {
                        this.m_cArBrightnessValues.add(String.valueOf(n3));
                    }
                }
                return this.m_cArBrightnessValues;
            } catch (Exception e) {
            }
        }
        return null;
    }

    public List<String> getSupportedContrastValues() {
        int nPos;
        if (this.m_cArContrastValues != null) {
            return this.m_cArContrastValues;
        }
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                this.m_cArContrastValues = new Vector();
                if (this.m_nManufacturer == 2) {
                    for (int n = 0; n < 30; n++) {
                        this.m_cArContrastValues.add(String.valueOf(n));
                    }
                    return this.m_cArContrastValues;
                }
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                String strFlatten = cParams.flatten();
                String[] strArFields = strFlatten.split(";");
                int nMinValue = -9999;
                int nMaxValue = -9999;
                int nValue = -9999;
                for (int n2 = 0; n2 < strArFields.length; n2++) {
                    if (strArFields[n2].indexOf("max-contrast=") == 0 || strArFields[n2].indexOf("contrast-max=") == 0) {
                        int nPos2 = strArFields[n2].indexOf("=");
                        if (nPos2 > 0) {
                            String strValue = strArFields[n2].substring(nPos2 + 1);
                            nMaxValue = Integer.valueOf(strValue).intValue();
                        }
                    } else if (strArFields[n2].indexOf("min-contrast=") == 0 || strArFields[n2].indexOf("contrast-min=") == 0) {
                        int nPos3 = strArFields[n2].indexOf("=");
                        if (nPos3 > 0) {
                            String strValue2 = strArFields[n2].substring(nPos3 + 1);
                            nMinValue = Integer.valueOf(strValue2).intValue();
                        }
                    } else {
                        if (strArFields[n2].indexOf("contrast=") == 0 && (nPos = strArFields[n2].indexOf("=")) > 0) {
                            String strValue3 = strArFields[n2].substring(nPos + 1);
                            nValue = Integer.valueOf(strValue3).intValue();
                            if (this.m_strContrast.length() == 0) {
                                this.m_strContrast = strValue3;
                            }
                        }
                        if (strArFields[n2].indexOf("contrast-values=") == 0) {
                            String strValue4 = strArFields[n2].substring(16);
                            String[] strArValues = strValue4.split(",");
                            for (String strItem : strArValues) {
                                this.m_cArContrastValues.add(strItem);
                            }
                        }
                        if ((nMinValue != -9999 && nMaxValue != -9999 && nValue != -9999 && nMaxValue > nMinValue) || this.m_cArContrastValues.size() > 0) {
                            break;
                        }
                    }
                }
                if (nMinValue != -9999 && nMaxValue != -9999 && nValue != -9999 && nMaxValue > nMinValue) {
                    for (int n3 = nMinValue; n3 <= nMaxValue; n3++) {
                        this.m_cArContrastValues.add(String.valueOf(n3));
                    }
                }
                if ((this.m_strModel.indexOf("P970") >= 0 || this.m_strModel.indexOf("P920") >= 0) && this.m_cArContrastValues.size() == 0) {
                    for (int n4 = 0; n4 <= 100; n4 += 10) {
                        this.m_cArContrastValues.add(String.valueOf(n4));
                    }
                }
                return this.m_cArContrastValues;
            } catch (Exception e) {
            }
        }
        return null;
    }

    public List<String> getSupportedSaturationValues() {
        int nPos;
        if (this.m_cArSaturationValues != null) {
            return this.m_cArSaturationValues;
        }
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                this.m_cArSaturationValues = new Vector();
                if (this.m_nManufacturer == 2) {
                    for (int n = 0; n < 30; n++) {
                        this.m_cArSaturationValues.add(String.valueOf(n));
                    }
                    return this.m_cArSaturationValues;
                }
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                String strFlatten = cParams.flatten();
                String[] strArFields = strFlatten.split(";");
                int nMinValue = -9999;
                int nMaxValue = -9999;
                Log.e("lgCamera", "Getting saturation");
                for (int n2 = 0; n2 < strArFields.length; n2++) {
                    if (strArFields[n2].indexOf("max-saturation=") == 0 || strArFields[n2].indexOf("saturation-max=") == 0) {
                        int nPos2 = strArFields[n2].indexOf("=");
                        if (nPos2 > 0) {
                            String strValue = strArFields[n2].substring(nPos2 + 1);
                            nMaxValue = Integer.valueOf(strValue).intValue();
                        }
                    } else if (strArFields[n2].indexOf("min-saturation=") == 0 || strArFields[n2].indexOf("saturation-min=") == 0) {
                        int nPos3 = strArFields[n2].indexOf("=");
                        if (nPos3 > 0) {
                            String strValue2 = strArFields[n2].substring(nPos3 + 1);
                            nMinValue = Integer.valueOf(strValue2).intValue();
                        }
                    } else {
                        if ((strArFields[n2].indexOf("saturation=") == 0 || strArFields[n2].indexOf("saturation-def=") == 0) && (nPos = strArFields[n2].indexOf("=")) > 0) {
                            String strValue3 = strArFields[n2].substring(nPos + 1);
                            if (this.m_strSaturation.length() == 0) {
                                this.m_strSaturation = strValue3;
                            }
                        }
                        if (strArFields[n2].indexOf("saturation-values=") == 0) {
                            String strValue4 = strArFields[n2].substring(18);
                            String[] strArValues = strValue4.split(",");
                            for (String strItem : strArValues) {
                                this.m_cArSaturationValues.add(strItem);
                            }
                        }
                        if ((nMinValue != -9999 && nMaxValue != -9999 && nMaxValue > nMinValue) || this.m_cArSaturationValues.size() > 0) {
                            break;
                        }
                    }
                }
                if (nMinValue != -9999 && nMaxValue != -9999 && nMaxValue > nMinValue) {
                    for (int n3 = nMinValue; n3 <= nMaxValue; n3++) {
                        this.m_cArSaturationValues.add(String.valueOf(n3));
                    }
                }
                return this.m_cArSaturationValues;
            } catch (Exception e) {
            }
        }
        return null;
    }

    private String getMeteringParameterName() {
        if (this.m_strMeteringParamName.length() > 0) {
            return this.m_strMeteringParamName;
        }
        this.m_strMeteringParamName = "";
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                String strFlatten = cParams.flatten();
                String[] strArFields = strFlatten.split(";");
                for (int n = 0; n < strArFields.length; n++) {
                    if (strArFields[n].indexOf("meter-mode") == 0) {
                        this.m_strMeteringParamName = "meter-mode";
                        break;
                    } else if (strArFields[n].indexOf("metering-mode") == 0) {
                        this.m_strMeteringParamName = "metering-mode";
                        break;
                    } else if (strArFields[n].indexOf("metering") == 0) {
                        this.m_strMeteringParamName = "metering";
                        break;
                    } else if (strArFields[n].indexOf("auto-exposure") == 0) {
                        this.m_strMeteringParamName = "auto-exposure";
                        break;
                    }
                }
            } catch (Exception e) {
            }
        }
        return this.m_strMeteringParamName;
    }

    /* JADX WARN: Code restructure failed: missing block: B:38:0x009b, code lost:
        r4 = r5[r3].indexOf(61);
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x00a3, code lost:
        if (r4 < 0) goto L57;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x00a5, code lost:
        r6 = r5[r3].substring(r4 + 1).split(",");
        r10.m_cArAutoExposures = new java.util.Vector();
        r2 = 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00bc, code lost:
        if (r2 >= r6.length) goto L44;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00be, code lost:
        r10.m_cArAutoExposures.add(r6[r2]);
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00c5, code lost:
        r2 = r2 + 1;
     */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0091 A[Catch: Exception -> 0x00cc, TryCatch #0 {Exception -> 0x00cc, blocks: (B:12:0x001b, B:13:0x002d, B:15:0x0030, B:17:0x0034, B:20:0x003d, B:36:0x0091, B:38:0x009b, B:40:0x00a5, B:41:0x00bb, B:43:0x00be, B:23:0x0043, B:25:0x004d, B:27:0x0057, B:35:0x008e, B:29:0x0061, B:31:0x006b, B:32:0x0081, B:34:0x0084), top: B:48:0x001b }] */
    /* JADX WARN: Removed duplicated region for block: B:55:0x0040 A[EDGE_INSN: B:55:0x0040->B:22:0x0040 ?: BREAK  , SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public List<String> getSupportedAutoExposures() {
        int n;
        if (this.m_cArAutoExposures != null) {
            return this.m_cArAutoExposures;
        }
        if (this.m_cCameraWrapper.Initialized() && (this.m_cArAutoExposures == null || this.m_cArAutoExposures.size() == 0)) {
            try {
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                String strFlatten = cParams.flatten();
                String[] strArFields = strFlatten.split(";");
                for (int n2 = 0; n2 < strArFields.length; n2++) {
                    if (strArFields[n2].indexOf("meter-mode-value") == 0 || strArFields[n2].indexOf("metering-mode-value") == 0 || strArFields[n2].indexOf("metering-value") == 0) {
                        int nPos = strArFields[n2].indexOf(61);
                        if (nPos >= 0) {
                            String[] strArValues = strArFields[n2].substring(nPos + 1).split(",");
                            this.m_cArAutoExposures = new Vector();
                            for (String str : strArValues) {
                                this.m_cArAutoExposures.add(str);
                            }
                        }
                        if (this.m_cArAutoExposures != null || this.m_cArAutoExposures.size() == 0) {
                            n = 0;
                            while (true) {
                                if (n >= strArFields.length) {
                                    break;
                                } else if (strArFields[n].indexOf("auto-exposure-value") == 0) {
                                    break;
                                } else {
                                    n++;
                                }
                            }
                        }
                    }
                }
                if (this.m_cArAutoExposures != null) {
                }
                n = 0;
                while (true) {
                    if (n >= strArFields.length) {
                    }
                    n++;
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return this.m_cArAutoExposures;
    }

    public List<String> getSupportedFocusMode() {
        if (this.m_cArFocusMode != null) {
            return this.m_cArFocusMode;
        }
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                this.m_cArFocusMode = this.m_cCameraWrapper.GetParameters(false).getSupportedFocusModes();
                if (this.m_cCameraWrapper.CanDetectFaces() && this.m_cArFocusMode.indexOf("continuous-video") >= 0) {
                    this.m_cArFocusMode.add("face detection");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return this.m_cArFocusMode;
    }

    public List<String> getSupportedAntiBanding() {
        if (this.m_strArSupportedAB != null) {
            return this.m_strArSupportedAB;
        }
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                this.m_strArSupportedAB = this.m_cCameraWrapper.GetParameters(false).getSupportedAntibanding();
            } catch (Exception e) {
            }
        }
        return this.m_strArSupportedAB;
    }

    public List<String> getSupportedScenes() {
        if (this.m_cArScenes != null) {
            return this.m_cArScenes;
        }
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                this.m_cArScenes = this.m_cCameraWrapper.GetParameters(false).getSupportedSceneModes();
            } catch (Exception e) {
            }
        }
        return this.m_cArScenes;
    }

    public List<Integer> getSupportedFrameRates() {
        if (this.m_cArSupportedFrameRates.size() > 0) {
            return this.m_cArSupportedFrameRates;
        }
        this.m_cArSupportedFrameRates.add(2);
        this.m_cArSupportedFrameRates.add(5);
        this.m_cArSupportedFrameRates.add(10);
        this.m_cArSupportedFrameRates.add(15);
        this.m_cArSupportedFrameRates.add(18);
        this.m_cArSupportedFrameRates.add(20);
        this.m_cArSupportedFrameRates.add(24);
        this.m_cArSupportedFrameRates.add(25);
        this.m_cArSupportedFrameRates.add(30);
        this.m_cArSupportedFrameRates.add(60);
        this.m_cArSupportedFrameRates.add(90);
        this.m_cArSupportedFrameRates.add(120);
        return this.m_cArSupportedFrameRates;
    }

    public List<String> getSupportedWB() {
        if (this.m_cArSupportedWB != null) {
            return this.m_cArSupportedWB;
        }
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                this.m_cArSupportedWB = this.m_cCameraWrapper.GetParameters(false).getSupportedWhiteBalance();
            } catch (Exception e) {
            }
        }
        return this.m_cArSupportedWB;
    }

    public List<String> getSupportedCE() {
        if (this.m_cArSupportedCE != null) {
            return this.m_cArSupportedCE;
        }
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                this.m_cArSupportedCE = this.m_cCameraWrapper.GetParameters(false).getSupportedColorEffects();
            } catch (Exception e) {
            }
        }
        return this.m_cArSupportedCE;
    }

    public List<String> getSupportedExposure() {
        if (this.m_cArSupportedExposure != null) {
            return this.m_cArSupportedExposure;
        }
        if (this.m_cCameraWrapper.Initialized()) {
            this.m_cArSupportedExposure = new Vector();
            try {
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                int nMinExposure = cParams.getMinExposureCompensation();
                int nMaxExposure = cParams.getMaxExposureCompensation();
                if (this.m_nManufacturer == 2 && this.m_strModel.indexOf("I9001") >= 0) {
                    nMinExposure = -4;
                    nMaxExposure = 4;
                }
                for (int n = nMinExposure; n <= nMaxExposure; n++) {
                    this.m_cArSupportedExposure.add(String.valueOf(n));
                }
            } catch (Exception e) {
            }
            return this.m_cArSupportedExposure;
        }
        return null;
    }

    public List<String> getSupportedFM() {
        if (this.m_cArSupportedFM != null) {
            return this.m_cArSupportedFM;
        }
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                this.m_cArSupportedFM = this.m_cCameraWrapper.GetParameters(false).getSupportedFlashModes();
                int n = 0;
                while (n < this.m_cArSupportedFM.size()) {
                    String strFM = this.m_cArSupportedFM.get(n);
                    if (!strFM.equals("auto") && !strFM.equals("off") && !strFM.equals("on") && !strFM.equals("torch") && !strFM.equals("red-eye")) {
                        this.m_cArSupportedFM.remove(n);
                        n--;
                    }
                    n++;
                }
            } catch (Exception e) {
            }
        }
        return this.m_cArSupportedFM;
    }

    public List<Point> getSupportedVideoRes() {
        if (this.m_cArVideoRes != null) {
            return this.m_cArVideoRes;
        }
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                this.m_cArVideoRes = this.m_cCameraWrapper.GetParameters(false).getSupportedPreviewSizes();
                Collections.sort(this.m_cArVideoRes, new Comparator<Point>() { // from class: com.android.camera.CameraView.6
                    @Override // java.util.Comparator
                    public int compare(Point lhs, Point rhs) {
                        if (lhs.x < rhs.x || (lhs.x == rhs.x && lhs.y < rhs.y)) {
                            return -1;
                        }
                        if (lhs.x == rhs.x && lhs.y == rhs.y) {
                            return 0;
                        }
                        return 1;
                    }
                });
                return this.m_cArVideoRes;
            } catch (Exception e) {
            }
        }
        return null;
    }

    public List<Point> getSupportedPhotoSizes() {
        if (this.m_cArPhotoSizes != null) {
            return this.m_cArPhotoSizes;
        }
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                this.m_cArPhotoSizes = this.m_cCameraWrapper.GetParameters(false).getSupportedPictureSizes();
                Collections.sort(this.m_cArPhotoSizes, new Comparator<Point>() { // from class: com.android.camera.CameraView.7
                    @Override // java.util.Comparator
                    public int compare(Point lhs, Point rhs) {
                        if (lhs.x < rhs.x || (lhs.x == rhs.x && lhs.y < rhs.y)) {
                            return -1;
                        }
                        if (lhs.x == rhs.x && lhs.y == rhs.y) {
                            return 0;
                        }
                        return 1;
                    }
                });
                return this.m_cArPhotoSizes;
            } catch (Exception e) {
            }
        }
        return null;
    }

    public List<Integer> getSupportedAudioBitRate() {
        if (this.m_cArBitRate.size() > 0) {
            return this.m_cArBitRate;
        }
        this.m_cArBitRate.add(12800);
        this.m_cArBitRate.add(25600);
        this.m_cArBitRate.add(51200);
        this.m_cArBitRate.add(62900);
        this.m_cArBitRate.add(102400);
        this.m_cArBitRate.add(204800);
        return this.m_cArBitRate;
    }

    public List<String> getSupportedAudioEncoders() {
        if (this.m_cArAudioEncoder.size() > 0) {
            return this.m_cArAudioEncoder;
        }
        this.m_cArAudioEncoder.add("Default");
        this.m_cArAudioEncoder.add("AMR-NB");
        this.m_cArAudioEncoder.add("AMR-WB");
        this.m_cArAudioEncoder.add("AAC");
        return this.m_cArAudioEncoder;
    }

    public List<Integer> getSupportedAudioSamplingRate() {
        if (this.m_cArSamplingRate.size() > 0) {
            return this.m_cArSamplingRate;
        }
        this.m_cArSamplingRate.add(8000);
        this.m_cArSamplingRate.add(10000);
        this.m_cArSamplingRate.add(11025);
        this.m_cArSamplingRate.add(12000);
        this.m_cArSamplingRate.add(16000);
        this.m_cArSamplingRate.add(22050);
        this.m_cArSamplingRate.add(24000);
        this.m_cArSamplingRate.add(32000);
        this.m_cArSamplingRate.add(44100);
        this.m_cArSamplingRate.add(48000);
        return this.m_cArSamplingRate;
    }

    public String getWB() {
        return this.m_strWB;
    }

    public void setWB(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strWB = strValue;
            if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum != 1) {
                try {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    cParams.setWhiteBalance(strValue);
                    this.m_cCameraWrapper.SetParameters(cParams);
                } catch (Exception e) {
                }
            }
        }
    }

    public String getWBFront() {
        return this.m_strWBFront;
    }

    public void setWBFront(String strValue) {
        if (strValue != null && strValue.length() != 0 && !strValue.equalsIgnoreCase("null")) {
            this.m_strWBFront = strValue;
            if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum == 1) {
                try {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                    cParams.setWhiteBalance(strValue);
                    this.m_cCameraWrapper.SetParameters(cParams);
                } catch (Exception e) {
                }
            }
        }
    }

    public int getZoom() {
        if (this.m_cCameraWrapper.Initialized()) {
            CameraParamWrapper cParams = null;
            if (0 == 0) {
                cParams = this.m_cCameraWrapper.GetParameters(true);
            }
            int nZoom = cParams.getZoom();
            this.m_nZoom = nZoom + 1;
        }
        return this.m_nZoom;
    }

    public Point getPhotoSize() {
        return this.m_szPhoto;
    }

    public void setPhotoSize(int nWidth, int nHeight) {
        this.m_szPhoto = new Point(nWidth, nHeight);
        if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum != 1) {
            try {
                this.m_cCameraWrapper.StopPreview();
                PrepareCamera(0);
                this.m_cCameraWrapper.StartPreview();
            } catch (Exception e) {
            }
        }
    }

    public Point getPhotoSizeFront() {
        return this.m_szPhotoFront;
    }

    public void setPhotoSizeFront(int nWidth, int nHeight) {
        this.m_szPhotoFront = new Point(nWidth, nHeight);
        if (this.m_cCameraWrapper.Initialized() && this.m_nCameraNum == 1) {
            try {
                this.m_cCameraWrapper.StopPreview();
                PrepareCamera(0);
                this.m_cCameraWrapper.StartPreview();
            } catch (Exception e) {
            }
        }
    }

    public Point getPhotoInVideoSize() {
        return this.m_szPhotoVideo;
    }

    public void setPhotoInVideoSize(int nWidth, int nHeight) {
        this.m_szPhotoVideo = new Point(nWidth, nHeight);
    }

    public Point getPhotoInVideoSizeFront() {
        return this.m_szPhotoVideoFront;
    }

    public void setPhotoInVideoSizeFront(int nWidth, int nHeight) {
        this.m_szPhotoVideoFront = new Point(nWidth, nHeight);
    }

    public CameraView(MainWindow cMainWindow, SurfaceHolder cHolder, boolean bUseSEC) {
        this.m_bUseSEC = true;
        this.m_cMainWnd = null;
        this.m_cAudioManager = null;
        this.m_nManufacturer = 0;
        this.m_nExynos = 0;
        this.m_nModel = 0;
        this.m_bUseSEC = bUseSEC;
        String strManufacturer = String.valueOf(InvokeHelper.GetStaticFieldValue(Build.class, "MANUFACTURER"));
        if (this.m_bUseSEC && strManufacturer.equalsIgnoreCase("samsung")) {
            this.m_nManufacturer = 2;
            if ((this.m_strModel.indexOf("I9100") >= 0 && this.m_strModel.indexOf("I9100G") < 0) || this.m_strModel.indexOf("N7000") >= 0 || this.m_strModel.indexOf("P6200") >= 0 || this.m_strModel.indexOf("P6201") >= 0 || this.m_strModel.indexOf("P6211") >= 0 || this.m_strModel.indexOf("P6210") >= 0 || this.m_strModel.indexOf("P6800") >= 0 || this.m_strModel.indexOf("P6810") >= 0 || this.m_strModel.indexOf("P3100") >= 0 || this.m_strModel.indexOf("P3110") >= 0 || this.m_strModel.indexOf("I777") >= 0 || this.m_strModel.indexOf("SPH-D710") >= 0) {
                this.m_nExynos = 1;
            }
            if (this.m_strModel.indexOf("I9300") >= 0 || this.m_strModel.indexOf("I9305") >= 0 || this.m_strModel.indexOf("N7100") >= 0 || this.m_strModel.indexOf("N7105") >= 0 || this.m_strModel.indexOf("N7102") >= 0 || this.m_strModel.indexOf("E210") >= 0 || this.m_strModel.indexOf("N8000") >= 0 || this.m_strModel.indexOf("N5100") >= 0 || this.m_strModel.indexOf("GC100") >= 0) {
                this.m_nExynos = 2;
            }
            if (this.m_strModel.indexOf("I9500") >= 0 || this.m_strModel.indexOf("I9502") >= 0 || this.m_strModel.indexOf("N900") >= 0) {
                this.m_nExynos = 3;
            }
            if (this.m_strModel.indexOf("G900") >= 0) {
                this.m_nExynos = 4;
            }
            SecCameraWrapper cSecWrapper = new SecCameraWrapper(cMainWindow.getApplicationContext(), this);
            if (cSecWrapper.IsSecInitialized()) {
                this.m_cCameraWrapper = cSecWrapper;
            }
        }
        if (this.m_cCameraWrapper == null) {
            this.m_cCameraWrapper = new CameraWrapper(cMainWindow.getApplicationContext(), this);
        }
        if (strManufacturer.equalsIgnoreCase("htc")) {
            this.m_nManufacturer = 1;
            if (this.m_strModel.indexOf("ONE X") >= 0 && this.m_strModel.indexOf("ONE XL") < 0) {
                this.m_nModel = 1;
            }
        }
        if (strManufacturer.indexOf("LG") == 0) {
            this.m_nManufacturer = 3;
        }
        if (strManufacturer.indexOf("SONY") == 0) {
            this.m_nManufacturer = 4;
        }
        try {
            AutoConfigure();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        this.m_cAudioManager = (AudioManager) cMainWindow.getSystemService("audio");
        this.m_cMainWnd = cMainWindow;
        this.m_cHolder = cHolder;
        this.m_cHolder.addCallback(this);
        this.m_cHolder.setType(3);
        this.m_cSaveThread.start();
    }

    public void ReadScript() {
        ScriptCompile cScriptCompile = new ScriptCompile();
        String strManufacturer = String.valueOf(InvokeHelper.GetStaticFieldValue(Build.class, "MANUFACTURER"));
        String[] strArRes = cScriptCompile.MakeScript(this.m_cMainWnd, strManufacturer, this.m_strModel);
        this.m_strScriptDefault = strArRes[0];
        if (this.m_strScript.length() == 0) {
            this.m_strScript = strArRes[0];
        }
    }

    private FileDescriptor getNewFileName() {
        String strName;
        String strName2;
        try {
            File cDir = new File(m_strFolder);
            cDir.mkdirs();
            String strExt = "3gp";
            if (this.m_nFormat == 2) {
                strExt = "mp4";
            }
            if (this.m_bSaveInIMGVIDFile) {
                while (true) {
                    strName2 = String.format("%s/VIDEO%05d", m_strFolder, Integer.valueOf(this.m_nLastVIDIndex));
                    File cFile1 = new File(String.valueOf(strName2) + ".3gp");
                    File cFile2 = new File(String.valueOf(strName2) + ".mp4");
                    if (!cFile1.exists() && !cFile2.exists()) {
                        break;
                    }
                    this.m_nLastVIDIndex++;
                }
                strName = String.valueOf(strName2) + "." + strExt;
            } else {
                Time cCurTime = new Time();
                cCurTime.setToNow();
                String strName3 = String.format("/%04d_%02d_%02d__%02d_%02d_%02d.%s", Integer.valueOf(cCurTime.year), Integer.valueOf(cCurTime.month + 1), Integer.valueOf(cCurTime.monthDay), Integer.valueOf(cCurTime.hour), Integer.valueOf(cCurTime.minute), Integer.valueOf(cCurTime.second), strExt);
                strName = String.valueOf(m_strFolder) + strName3;
            }
            return getNewFileName(strName);
        } catch (Exception e) {
            return null;
        }
    }

    private FileDescriptor getNewFileName(String strFileName) {
        try {
            this.m_strFileName = strFileName;
            return DocumentFile.WriteFile(this.m_strFileName, this.m_cMainWnd.getApplicationContext(), m_treeUri);
        } catch (Exception e) {
            return null;
        }
    }

    private String getNewFileNameJpeg() {
        String strName;
        try {
            File cDir = new File(m_strFolder);
            cDir.mkdirs();
            if (!this.m_bSaveInIMGVIDFile) {
                Time cCurTime = new Time();
                cCurTime.setToNow();
                if (this.m_nPhotoMode == 1 || this.m_bICSBurstPhotoMode) {
                    long lMS = System.currentTimeMillis() % 1000;
                    strName = String.format("/%04d_%02d_%02d__%02d_%02d_%02d_%03d.jpg", Integer.valueOf(cCurTime.year), Integer.valueOf(cCurTime.month + 1), Integer.valueOf(cCurTime.monthDay), Integer.valueOf(cCurTime.hour), Integer.valueOf(cCurTime.minute), Integer.valueOf(cCurTime.second), Long.valueOf(lMS));
                } else {
                    strName = String.format("/%04d_%02d_%02d__%02d_%02d_%02d.jpg", Integer.valueOf(cCurTime.year), Integer.valueOf(cCurTime.month + 1), Integer.valueOf(cCurTime.monthDay), Integer.valueOf(cCurTime.hour), Integer.valueOf(cCurTime.minute), Integer.valueOf(cCurTime.second));
                }
                return String.valueOf(m_strFolder) + strName;
            }
            while (true) {
                String strName2 = String.format("%s/IMAGE%05d", m_strFolder, Integer.valueOf(this.m_nLastIMGIndex));
                File cFile1 = new File(String.valueOf(strName2) + ".jpg");
                File cFile2 = new File(String.valueOf(strName2) + ".png");
                if (cFile1.exists() || cFile2.exists()) {
                    this.m_nLastIMGIndex++;
                } else {
                    return String.valueOf(strName2) + ".jpg";
                }
            }
        } catch (Exception e) {
            return null;
        }
    }

    public void StartPreview(boolean bVideoMode) {
        try {
            if (!this.m_cCameraWrapper.Initialized()) {
                InitCamera();
                Log.e("lgCamera", "Camera initialized");
                DebugLog.WriteDebug("InitCamera");
            }
            if (this.m_nModel == 1) {
                this.m_cCameraWrapper.SetPreviewDisplay(this.m_cHolder);
                this.m_cCameraWrapper.StartPreview();
            }
            PrepareCamera(bVideoMode ? 1 : 0);
            Log.e("lgCamera", "Camera prepared");
            DebugLog.WriteDebug("PrepareCamera");
            this.m_cCameraWrapper.SetPreviewDisplay(this.m_cHolder);
            Log.e("lgCamera", "Preview display set");
            this.m_cCameraWrapper.StartPreview();
            Log.e("lgCamera", "startPreview");
            if (this.m_nExynos == 1 && !bVideoMode) {
                MakeFocus(false);
                Log.e("lgCamera", "MakeFocus(m_ptPreviewSize.x/2,m_ptPreviewSize.y/2)");
            }
            this.m_nMaxZoom = -1;
            if (this.m_strFocusMode.equalsIgnoreCase("face detection")) {
                this.m_cCameraWrapper.StopFaceDetection();
                this.m_cCameraWrapper.StartFaceDetection();
            }
        } catch (Exception ex) {
            this.m_cMainWnd.onCameraViewAction(4);
            ex.printStackTrace();
        }
    }

    public int getMaxZoom() {
        if (this.m_nMaxZoom != -1) {
            return this.m_nMaxZoom;
        }
        this.m_nMaxZoom = 0;
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(true);
                this.m_nMaxZoom = cParams.getMaxZoom();
                if (this.m_nMaxZoom <= 0) {
                    this.m_nMaxZoom = cParams.getInt("taking-picture-zoom-max");
                }
            } catch (Exception e) {
            }
        }
        if (this.m_nMaxZoom <= 0 && this.m_nManufacturer == 2 && this.m_strModel.indexOf("I9001") >= 0) {
            this.m_nMaxZoom = 30;
        }
        return this.m_nMaxZoom;
    }

    public synchronized void setZoomValue(int nZoom) {
        if (this.m_cCameraWrapper.Initialized()) {
            CameraParamWrapper cParams = null;
            if (0 == 0) {
                try {
                    cParams = this.m_cCameraWrapper.GetParameters(true);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            int nZoom2 = nZoom - 1;
            int nMaxZoom = getMaxZoom();
            if (nZoom2 <= nMaxZoom && nZoom2 >= 0) {
                if (this.m_nManufacturer == 1) {
                    cParams.set("touch-focus", String.format("%d,%d", Integer.valueOf(nZoom2), Integer.valueOf(nZoom2)));
                    cParams.set("capture-mode", "normal");
                    cParams.set("picture-count", 1);
                    SetGPUEffect(cParams, "0_bypass");
                    SetGEParam(cParams, "GE-param0", 0, 0, 0, 0, false);
                    SetGEParam(cParams, "GE-param1", 0, 0, 0, 0, false);
                }
                cParams.setZoom(nZoom2);
                Log.e("lgCamera", String.format("Zoom value=%d", Integer.valueOf(nZoom2)));
                this.m_cCameraWrapper.SetParameters(cParams);
            }
        }
    }

    public synchronized void ZoomIn() {
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                int nZoom = getZoom() - 1;
                setZoomValue(nZoom + 1 + 1);
            } catch (Exception e) {
            }
        }
    }

    public synchronized void ZoomOut() {
        if (this.m_cCameraWrapper.Initialized()) {
            try {
                int nZoom = getZoom() - 1;
                setZoomValue((nZoom - 1) + 1);
            } catch (Exception e) {
            }
        }
    }

    public void PlaySound(Context cContext, String strFileName) {
        UnmuteStreams();
        try {
            MediaPlayer cPlayer = MediaPlayer.create(cContext, Uri.parse(strFileName));
            cPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { // from class: com.android.camera.CameraView.8
                @Override // android.media.MediaPlayer.OnCompletionListener
                public void onCompletion(MediaPlayer arg0) {
                    arg0.release();
                }
            });
            cPlayer.start();
        } catch (Exception e) {
        }
    }

    private synchronized void TakePicture(boolean bBurst) {
        synchronized (this) {
            MuteStreams();
            if (this.m_nSDK >= 14 && !this.m_bTurnOffSounds) {
                PlaySound(this.m_cMainWnd, "/system/media/audio/ui/camera_click.ogg");
            }
            this.m_strFileName = getNewFileNameJpeg();
            DebugLog.WriteDebug("JPG name = " + this.m_strFileName);
            try {
                DebugLog.WriteDebug("Setting camera parameters");
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(bBurst ? false : true);
                cParams.setJpegQuality(this.m_nJPEGQuality);
                cParams.setPictureFormat(256);
                if (this.m_bAutoRotate) {
                    switch (this.m_cMainWnd.m_nLastOrientation) {
                        case 0:
                        case 4:
                            if (this.m_nCameraNum == 1) {
                                cParams.setRotation(270);
                                break;
                            } else {
                                cParams.setRotation(90);
                                break;
                            }
                        case 1:
                            cParams.setRotation(180);
                            break;
                        case 2:
                            if (this.m_nCameraNum == 1) {
                                cParams.setRotation(90);
                                break;
                            } else {
                                cParams.setRotation(270);
                                break;
                            }
                        case 3:
                        default:
                            cParams.setRotation(0);
                            break;
                    }
                } else {
                    cParams.setRotation(0);
                }
                if (this.m_bUseGPSEXIF) {
                    Log.e("lgCamera", "Add GPS to exif");
                    Location cLoc = this.m_cMainWnd.getLastKnownLocation();
                    if (cLoc != null) {
                        Log.e("lgCamera", "GPS is not null, adding");
                        if (cLoc.hasAltitude()) {
                            cParams.setGpsAltitude(cLoc.getAltitude());
                        }
                        cParams.setGpsLatitude(cLoc.getLatitude());
                        cParams.setGpsLongitude(cLoc.getLongitude());
                        cParams.setGpsProcessingMethod(cLoc.getProvider());
                        Time cTime = new Time();
                        cTime.setToNow();
                        cParams.setGpsTimestamp(cTime.toMillis(true) / 1000);
                    }
                }
                this.m_cCameraWrapper.SetParameters(cParams);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            DebugLog.WriteDebug("Capturing photo");
            Log.e("lgCamera", "Capturing photo");
            this.m_cCameraWrapper.TakePicture();
        }
    }

    private long GetMaxFileSize() {
        StatFs cStatFS = new StatFs(m_strFolder);
        long lBlockSize = cStatFS.getBlockSize();
        long lAvailableBlock = cStatFS.getAvailableBlocks();
        long lAvailableSize = lAvailableBlock * lBlockSize;
        return lAvailableSize;
    }

    public boolean CapturePhoto(boolean bBurst) {
        boolean z = false;
        try {
            if (this.m_bCanShot) {
                long lAvailableSize = GetMaxFileSize();
                if (lAvailableSize < 10485760) {
                    this.m_cMainWnd.onCameraViewAction(7);
                } else {
                    this.m_bCanShot = false;
                    this.m_cMainWnd.onCameraViewAction(9);
                    if (this.m_bForceAF && this.m_nPhotoMode == 0) {
                        this.m_bCanShot = false;
                        this.m_nForceAutofocusing = 1;
                        this.m_cMainWnd.m_cHandler.removeCallbacks(this.m_cRestoreFM);
                        this.m_cCameraWrapper.AutoFocus();
                        z = true;
                    } else {
                        switch (this.m_nPhotoMode) {
                            case 2:
                                break;
                            default:
                                TakePicture(bBurst);
                                break;
                        }
                    }
                }
            }
        } catch (Exception e) {
            this.m_bCanShot = true;
            this.m_cMainWnd.onCameraViewAction(8);
        }
        return z;
    }

    public boolean RecordVideo() {
        boolean z = false;
        try {
            if (this.m_bCanShot) {
                long lAvailableSize = GetMaxFileSize();
                if (lAvailableSize < 104857600) {
                    this.m_cMainWnd.onCameraViewAction(7);
                } else {
                    this.m_bCanShot = false;
                    this.m_cMainWnd.onCameraViewAction(9);
                    if (this.m_bForceAF && this.m_nPhotoMode == 0) {
                        this.m_bCanShot = false;
                        this.m_nForceAutofocusing = 2;
                        this.m_cMainWnd.m_cHandler.removeCallbacks(this.m_cRestoreFM);
                        this.m_cCameraWrapper.AutoFocus();
                        z = true;
                    } else {
                        StartRecordInternal();
                        z = true;
                    }
                }
            }
        } catch (Exception e) {
            this.m_bCanShot = true;
            this.m_cMainWnd.onCameraViewAction(8);
        }
        return z;
    }

    public void StartRecordInternal() {
        FileDescriptor cFD;
        long lMaxFileSize;
        try {
            MuteStreams();
            if (this.m_bRestartCamera) {
                StopCamera();
            }
            StartPreview(true);
            Log.e("lgCamera", "StartPreview(true);");
            Log.e("lgCamera", "m_cCameraParam=m_cCameraWrapper.GetParameters();");
            DebugLog.WriteDebug(this.m_cCameraWrapper.GetParameters(true).flatten());
            if (this.m_nExynos == 1) {
                this.m_cCameraWrapper.StopPreview();
                Log.e("Cameraview", String.format("Focus mode=%s", this.m_cCameraWrapper.GetParameters(false).getFocusMode()));
            }
            InitMR();
            Log.e("lgCamera", "InitMR();");
            if (this.m_nManufacturer == 1 && this.m_nAudioChannels > 1) {
                EnableSoundEffects();
            }
            this.m_cCameraWrapper.SetAudioSource(this.m_nAudioSource);
            DebugLog.WriteDebug(String.format("m_cCameraWrapper.SetAudioSource(%d);", Integer.valueOf(this.m_nAudioSource)));
            this.m_cCameraWrapper.SetVideoSource(1);
            DebugLog.WriteDebug("m_cCameraWrapper.SetVideoSource(MediaRecorder.VideoSource.CAMERA);");
            this.m_cCameraWrapper.SetOutputFormat(this.m_nFormat);
            DebugLog.WriteDebug(String.format("m_cCameraWrapper.SetOutputFormat(%d)", Integer.valueOf(this.m_nFormat)));
            if (this.m_nFrameRates != 0) {
                this.m_cCameraWrapper.SetVideoFrameRate(this.m_nFrameRates);
                DebugLog.WriteDebug(String.format("m_cCameraWrapper.SetVideoFrameRate(%d)", Integer.valueOf(this.m_nFrameRates)));
            }
            if (this.m_fSlowMotionModule != 1.0f && this.m_nSDK >= 11) {
                this.m_cCameraWrapper.SetCaptureRate(this.m_nFrameRates * this.m_fSlowMotionModule);
            }
            Point ptSize = new Point(this.m_ptSize);
            if (this.m_nCameraNum == 1) {
                ptSize = new Point(this.m_ptSizeFront);
            }
            this.m_cCameraWrapper.SetVideoSize(ptSize.x, ptSize.y);
            DebugLog.WriteDebug(String.format("m_cCameraWrapper.SetVideoSize(%d,%d)", Integer.valueOf(ptSize.x), Integer.valueOf(ptSize.y)));
            if (this.m_nCameraNum == 1) {
                this.m_cCameraWrapper.SetVideoEncodingBitRate(this.m_nBitRateFront);
                DebugLog.WriteDebug(String.format("m_cCameraWrapper.SetVideoEncodingBitRate(%d)", Integer.valueOf(this.m_nBitRateFront)));
            } else {
                this.m_cCameraWrapper.SetVideoEncodingBitRate(this.m_nBitRate);
                DebugLog.WriteDebug(String.format("m_cCameraWrapper.SetVideoEncodingBitRate(%d)", Integer.valueOf(this.m_nBitRate)));
            }
            this.m_cCameraWrapper.SetVideoEncoder(this.m_nEncoder);
            DebugLog.WriteDebug(String.format("m_cCameraWrapper.SetVideoEncoder(%d)", Integer.valueOf(this.m_nEncoder)));
            if (this.m_nAudioEncoder == 3) {
                if (this.m_nAudioBitRate > 0) {
                    this.m_cCameraWrapper.SetAudioEncodingBitRate(this.m_nAudioBitRate);
                    DebugLog.WriteDebug(String.format("m_cCameraWrapper.SetAudioEncodingBitRate(%d)", Integer.valueOf(this.m_nAudioBitRate)));
                }
                if (this.m_nSamplingRate > 0) {
                    this.m_cCameraWrapper.SetAudioSamplingRate(this.m_nSamplingRate);
                    DebugLog.WriteDebug(String.format("m_cCameraWrapper.SetAudioSamplingRate(%d)", Integer.valueOf(this.m_nSamplingRate)));
                }
            }
            if (this.m_nAudioEncoder == 2) {
                this.m_cCameraWrapper.SetAudioEncodingBitRate(23850);
                this.m_cCameraWrapper.SetAudioSamplingRate(16000);
            }
            if (this.m_nAudioChannels > 1) {
                this.m_cCameraWrapper.SetAudioChannels(this.m_nAudioChannels);
                DebugLog.WriteDebug(String.format("m_cCameraWrapper.SetAudioChannels(%d)", Integer.valueOf(this.m_nAudioChannels)));
            }
            this.m_cCameraWrapper.SetAudioEncoder(this.m_nAudioEncoder);
            DebugLog.WriteDebug(String.format("m_cCameraWrapper.SetAudioEncoder(%d)", Integer.valueOf(this.m_nAudioEncoder)));
            this.m_cCameraWrapper.SetPreviewDisplay(this.m_cHolder.getSurface());
            DebugLog.WriteDebug("m_cCameraWrapper.SetPreviewDisplay");
            if (this.m_cMainWnd.m_bVideoCaptureIntent && this.m_cMainWnd.m_cUriSaveVideo != null) {
                Log.e("lgCamera", "Video URI " + this.m_cMainWnd.m_cUriSaveVideo.getPath());
                cFD = getNewFileName(this.m_cMainWnd.m_cUriSaveVideo.getPath());
            } else {
                if (this.m_cMainWnd.m_bVideoCaptureIntent) {
                    Log.e("lgCamera", "Video URI=NULL!");
                }
                cFD = getNewFileName();
            }
            if (cFD != null) {
                this.m_cCameraWrapper.SetOutputFile(cFD);
                DebugLog.WriteDebug("m_cCameraWrapper.SetOutputFile");
            }
            if (this.m_bAutoRotate) {
                int nAngle = 0;
                switch (this.m_cMainWnd.m_nLastOrientation) {
                    case 0:
                    case 4:
                        nAngle = 90;
                        break;
                    case 1:
                        nAngle = 180;
                        break;
                    case 2:
                        nAngle = 270;
                        break;
                }
                Log.e("lgCamera", "before m_cCameraWrapper.SetOrientationHint(nAngle);");
                this.m_cCameraWrapper.SetOrientationHint(nAngle);
                Log.e("lgCamera", "m_cCameraWrapper.SetOrientationHint(nAngle);");
                DebugLog.WriteDebug(String.format("m_cCameraWrapper.SetOrientationHint(%d)", Integer.valueOf(nAngle)));
            }
            long lMaxFileSize2 = GetMaxFileSize();
            if (lMaxFileSize2 < 4294967296L) {
                lMaxFileSize = (3 * lMaxFileSize2) / 4;
            } else {
                lMaxFileSize = 4294967296L;
            }
            this.m_cCameraWrapper.SetMaxFileSize(lMaxFileSize);
            DebugLog.WriteDebug(String.format("m_cCameraWrapper.SetMaxFileSize(%d)", Long.valueOf(lMaxFileSize)));
            this.m_cCameraWrapper.PrepareRecorder();
            DebugLog.WriteDebug("m_cCameraWrapper.PrepareRecorder();");
            try {
                Class<?> clsAGC = Class.forName("android.media.audiofx.AutomaticGainControl");
                if (clsAGC != null) {
                    this.m_cCameraWrapper.m_oAGC = InvokeHelper.InvokeStaticMethod(clsAGC, "create", 0);
                    InvokeHelper.InvokeMethodFast(this.m_cCameraWrapper.m_oAGC, "setEnabled", false);
                }
            } catch (Exception e) {
            }
            this.m_cCameraWrapper.StartRecording();
            DebugLog.WriteDebug("m_cCameraWrapper.StartRecording();");
            this.m_bStarted = true;
            Log.e("lgCamera", "before m_cCameraWrapper.ReconnectCamera();");
            if (this.m_nSDK >= 14) {
                try {
                    this.m_cCameraWrapper.ReconnectCamera();
                    Log.e("lgCamera", "m_cCameraWrapper.ReconnectCamera();");
                    DebugLog.WriteDebug("m_cCameraWrapper.ReconnectCamera();");
                    this.m_cCameraWrapper.SetParameters(this.m_cCameraWrapper.GetParameters(true));
                    Log.e("lgCamera", "m_cCameraWrapper.SetParameters(m_cCameraParam);");
                    DebugLog.WriteDebug("m_cCameraWrapper.SetParameters(m_cCameraParam);");
                } catch (Exception ex1) {
                    ex1.printStackTrace();
                }
            }
            this.m_cMainWnd.onCameraViewAction(1);
        } catch (Exception ex) {
            ex.printStackTrace();
            this.m_cMainWnd.onCameraViewAction(3);
            ClearMR();
            StopCamera();
            StartPreview(false);
            if (this.m_nManufacturer == 1 && this.m_nAudioChannels > 1) {
                DisableSoundEffects();
            }
        }
        UnmuteStreams();
        this.m_bCanShot = true;
        this.m_cMainWnd.onCameraViewAction(8);
    }

    public synchronized boolean StopRecord() {
        boolean z = true;
        synchronized (this) {
            if (this.m_bStarted) {
                try {
                    this.m_bCanShot = false;
                    this.m_cMainWnd.onCameraViewAction(9);
                    MuteStreams();
                    Log.e("lgCamera", "MuteStreams();");
                    this.m_cCameraWrapper.StopRecording();
                    if (this.m_nPreviewTime < 1000) {
                        IndexingPathInGallery(this.m_strFileName);
                    }
                    ClearMR();
                    Log.e("lgCamera", "ClearMR();");
                    if (this.m_nManufacturer == 1 && this.m_nAudioChannels > 1) {
                        DisableSoundEffects();
                    }
                    this.m_cAudioManager.setParameters("CAMCORDER_MODE=OFF");
                    if (this.m_cCameraWrapper.m_oAGC != null) {
                        try {
                            InvokeHelper.InvokeMethodFast(this.m_cCameraWrapper.m_oAGC, "setEnabled", true);
                            InvokeHelper.InvokeMethodFast(this.m_cCameraWrapper.m_oAGC, "release", true);
                        } catch (Exception e) {
                        }
                    }
                    this.m_cCameraWrapper.m_oAGC = null;
                    try {
                        this.m_cCameraWrapper.ReconnectCamera();
                    } catch (Exception ex1) {
                        ex1.printStackTrace();
                    }
                    if (this.m_bRestartCamera) {
                        Log.e("lgCamera", "Stopping camera");
                        StopCamera();
                    }
                    this.m_bStarted = false;
                    this.m_bPauseExist = false;
                    this.m_bPaused = false;
                    if (this.m_cMainWnd.m_bVideoCaptureIntent) {
                        File videoFile = new File(this.m_strFileName);
                        Uri videoFileUri = Uri.fromFile(videoFile);
                        Intent resultIntent = new Intent();
                        resultIntent.setData(videoFileUri);
                        this.m_cMainWnd.setResult(-1, resultIntent);
                        this.m_cMainWnd.finish();
                    } else {
                        StartPreview(false);
                        this.m_cMainWnd.onCameraViewAction(2);
                        UnmuteStreams();
                        this.m_bCanShot = true;
                        this.m_cMainWnd.onCameraViewAction(8);
                    }
                } catch (Exception e2) {
                    this.m_bStarted = false;
                    UnmuteStreams();
                    this.m_bCanShot = true;
                    this.m_cMainWnd.onCameraViewAction(8);
                    z = false;
                }
            }
        }
        return z;
    }

    private void InitMR() throws Exception {
        this.m_cCameraWrapper.InitRecorder();
        this.m_cCameraWrapper.Unlock();
        this.m_cCameraWrapper.LinkCamera();
        this.m_bPauseExist = this.m_cCameraWrapper.IsPauseExists();
    }

    private void ClearMR() {
        try {
            this.m_cCameraWrapper.ResetRecorder();
            this.m_cCameraWrapper.ReleaseRecorder();
        } catch (Exception e) {
        }
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceChanged(SurfaceHolder arg0, int arg1, int width, int height) {
        this.m_cMainWnd.AdjustAspectRatio();
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceCreated(SurfaceHolder holder) {
        this.m_cSensorManager = (SensorManager) this.m_cMainWnd.getSystemService("sensor");
        List<Sensor> cArSensors = this.m_cSensorManager.getSensorList(1);
        for (int n = 0; n < cArSensors.size(); n++) {
            this.m_cSensorManager.registerListener(this, cArSensors.get(n), 3);
        }
        StartPreview(false);
        CalcLastIndexVideo();
        CalcLastIndexJPG();
        this.m_cMainWnd.runOnUiThread(this.m_cUpdateButtons);
    }

    @Override // android.view.SurfaceHolder.Callback
    public void surfaceDestroyed(SurfaceHolder holder) {
        if (this.m_cSensorManager != null) {
            this.m_cSensorManager.unregisterListener(this);
        }
        if (this.m_bStarted) {
            StopRecord();
            ClearMR();
        }
        this.m_cPanoramaCollection.CancelPanorama();
        StopCamera();
    }

    private void InitCamera() {
        List<String> strAB;
        List<String> strArExp;
        List<String> strArISO;
        List<String> strAB2;
        List<String> strArExp2;
        List<String> strArISO2;
        try {
            this.m_cCameraWrapper.OpenCamera(this.m_nCameraNum);
            if (this.m_bFirstInit) {
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
                this.m_bFirstInit = false;
                this.m_nAutoFrameRates = cParams.getPreviewFrameRate();
                if (this.m_nCameraNum != 1) {
                    List<Point> cArSizes = getSupportedPhotoSizes();
                    Log.e("lgCamera", String.format("Photo sizes count=%d", Integer.valueOf(cArSizes.size())));
                    if (this.m_szPhoto.x == 0) {
                        for (int n = 0; n < cArSizes.size(); n++) {
                            if (cArSizes.get(n).x > this.m_szPhoto.x) {
                                this.m_szPhoto.x = cArSizes.get(n).x;
                                this.m_szPhoto.y = cArSizes.get(n).y;
                            }
                        }
                    }
                    if (this.m_szPhotoVideo.x == 0) {
                        for (int n2 = 0; n2 < cArSizes.size(); n2++) {
                            if (cArSizes.get(n2).x > this.m_szPhotoVideo.x) {
                                this.m_szPhotoVideo.x = cArSizes.get(n2).x;
                                this.m_szPhotoVideo.y = cArSizes.get(n2).y;
                            }
                            if (this.m_szPhoto.x > 0 && this.m_szPhotoVideo.x > 0) {
                                break;
                            }
                        }
                    }
                    if (this.m_strISOValue.equalsIgnoreCase("null") && (strArISO2 = getSupportedISOValues()) != null && strArISO2.size() > 0) {
                        this.m_strISOValue = strArISO2.get(0);
                    }
                    if (this.m_strAutoExposure.length() == 0) {
                        this.m_strAutoExposure = String.valueOf(InvokeHelper.InvokeMethodFast(cParams, "getAutoExposure"));
                    }
                    if (this.m_strAutoExposure.equalsIgnoreCase("null") && (strArExp2 = getSupportedAutoExposures()) != null && strArExp2.size() > 0) {
                        this.m_strAutoExposure = strArExp2.get(0);
                    }
                    if (this.m_strWB.length() == 0) {
                        this.m_strWB = cParams.getWhiteBalance();
                    }
                    if (this.m_strScene.length() == 0) {
                        this.m_strScene = cParams.getSceneMode();
                    }
                    if (this.m_strFocusMode.length() == 0 || this.m_strFocusMode.equalsIgnoreCase("null")) {
                        this.m_strFocusMode = "continuous-video";
                        if (this.m_nSDK < 9) {
                            this.m_strFocusMode = "auto";
                        }
                        List<String> strArFM = getSupportedFocusMode();
                        if (strArFM != null && strArFM.indexOf(this.m_strFocusMode) == -1 && strArFM.size() > 0) {
                            this.m_strFocusMode = strArFM.get(0);
                        }
                    }
                    if ((this.m_strAntiBanding.length() == 0 || this.m_strAntiBanding.equalsIgnoreCase("null")) && (strAB2 = getSupportedAntiBanding()) != null && strAB2.size() > 0) {
                        this.m_strAntiBanding = strAB2.get(0);
                    }
                    if (this.m_strEffect.length() == 0) {
                        this.m_strEffect = cParams.getColorEffect();
                    }
                    if (this.m_strFlash.length() == 0) {
                        this.m_strFlash = cParams.getFlashMode();
                    }
                    if (this.m_strContrast.length() == 0) {
                        this.m_strContrast = getContrast();
                    }
                    if (this.m_strBrightness.length() == 0) {
                        this.m_strBrightness = getBrightness();
                    }
                    if (this.m_strSaturation.length() == 0) {
                        this.m_strSaturation = getSaturation();
                    }
                    if (this.m_strSharpness.length() == 0) {
                        this.m_strSharpness = getSharpness();
                        return;
                    }
                    return;
                }
                List<Point> cArSizes2 = getSupportedPhotoSizes();
                Log.e("lgCamera", String.format("Photo sizes count=%d", Integer.valueOf(cArSizes2.size())));
                if (this.m_szPhotoFront.x == 0) {
                    for (int n3 = 0; n3 < cArSizes2.size(); n3++) {
                        if (cArSizes2.get(n3).x > this.m_szPhotoFront.x) {
                            this.m_szPhotoFront.x = cArSizes2.get(n3).x;
                            this.m_szPhotoFront.y = cArSizes2.get(n3).y;
                        }
                    }
                }
                if (this.m_szPhotoVideoFront.x == 0) {
                    for (int n4 = 0; n4 < cArSizes2.size(); n4++) {
                        if (cArSizes2.get(n4).x > this.m_szPhotoVideoFront.x) {
                            this.m_szPhotoVideoFront.x = cArSizes2.get(n4).x;
                            this.m_szPhotoVideoFront.y = cArSizes2.get(n4).y;
                        }
                        if (this.m_szPhotoFront.x > 0 && this.m_szPhotoVideoFront.x > 0) {
                            break;
                        }
                    }
                }
                if (this.m_strISOValueFront.equalsIgnoreCase("null") && (strArISO = getSupportedISOValues()) != null && strArISO.size() > 0) {
                    this.m_strISOValueFront = strArISO.get(0);
                }
                if (this.m_strAutoExposureFront.length() == 0) {
                    this.m_strAutoExposureFront = String.valueOf(InvokeHelper.InvokeMethodFast(cParams, "getAutoExposure"));
                }
                if (this.m_strAutoExposureFront.equalsIgnoreCase("null") && (strArExp = getSupportedAutoExposures()) != null && strArExp.size() > 0) {
                    this.m_strAutoExposureFront = strArExp.get(0);
                }
                if (this.m_strWBFront.length() == 0) {
                    this.m_strWBFront = cParams.getWhiteBalance();
                }
                if (this.m_strSceneFront.length() == 0) {
                    this.m_strSceneFront = cParams.getSceneMode();
                }
                if (this.m_strFocusModeFront.length() == 0 || this.m_strFocusModeFront.equalsIgnoreCase("null")) {
                    this.m_strFocusModeFront = "continuous-video";
                    if (this.m_nSDK < 9) {
                        this.m_strFocusModeFront = "auto";
                    }
                    List<String> strArFM2 = getSupportedFocusMode();
                    if (strArFM2 != null && strArFM2.indexOf(this.m_strFocusModeFront) == -1 && strArFM2.size() > 0) {
                        this.m_strFocusModeFront = strArFM2.get(0);
                    }
                }
                if ((this.m_strAntiBandingFront.length() == 0 || this.m_strAntiBandingFront.equalsIgnoreCase("null")) && (strAB = getSupportedAntiBanding()) != null && strAB.size() > 0) {
                    this.m_strAntiBandingFront = strAB.get(0);
                }
                if (this.m_strEffectFront.length() == 0) {
                    this.m_strEffectFront = cParams.getColorEffect();
                }
                if (this.m_strFlashFront.length() == 0) {
                    this.m_strFlashFront = cParams.getFlashMode();
                }
                if (this.m_strContrastFront.length() == 0) {
                    this.m_strContrastFront = getContrast();
                }
                if (this.m_strBrightnessFront.length() == 0) {
                    this.m_strBrightnessFront = getBrightness();
                }
                if (this.m_strSaturationFront.length() == 0) {
                    this.m_strSaturationFront = getSaturation();
                }
                if (this.m_strSharpnessFront.length() == 0) {
                    this.m_strSharpnessFront = getSharpness();
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void PrepareCamera(int nMode) {
        Point ptSize;
        Point ptSize2;
        String strComScript;
        CameraParamWrapper cParams = null;
        DebugLog.WriteDebug(String.format("PrepareCamera %d starts", Integer.valueOf(this.m_nCameraNum)));
        Log.e("lgCamera", "PrepareCamera starts");
        if (nMode != 1 || (this.m_bRestartCamera && nMode == 1)) {
            try {
                cParams = this.m_cCameraWrapper.GetParameters(true);
                if (this.m_nManufacturer == 1) {
                    cParams.set("touch-aec", "off");
                    cParams.set("enable-caf", "off");
                }
                cParams.setJpegQuality(this.m_nJPEGQuality);
                DebugLog.WriteDebug(String.format("setJpegQuality(%d)", Integer.valueOf(this.m_nJPEGQuality)));
                if (IsFrontCamera()) {
                    cParams.setExposureCompensation(this.m_nExposureFront);
                    DebugLog.WriteDebug(String.format("setExposureCompensation(%d)", Integer.valueOf(this.m_nExposureFront)));
                    if (this.m_strAntiBandingFront != null && this.m_strAntiBandingFront.length() > 0 && !this.m_strAntiBandingFront.equalsIgnoreCase("null")) {
                        cParams.setAntibanding(this.m_strAntiBandingFront);
                        DebugLog.WriteDebug(String.format("setAntibanding(%s)", this.m_strAntiBandingFront));
                    }
                    if (this.m_strFlashFront != null && this.m_strFlashFront.length() != 0 && !this.m_strFlashFront.equalsIgnoreCase("null")) {
                        cParams.setFlashMode(this.m_strFlashFront);
                        DebugLog.WriteDebug(String.format("setFlashMode(%s)", this.m_strFlashFront));
                    }
                    if (this.m_strWBFront != null && this.m_strWBFront.length() != 0 && !this.m_strWBFront.equalsIgnoreCase("null")) {
                        cParams.setWhiteBalance(this.m_strWBFront);
                        DebugLog.WriteDebug(String.format("setWhiteBalance(%s)", this.m_strWBFront));
                    }
                    if (this.m_strSceneFront != null && this.m_strSceneFront.length() != 0 && !this.m_strSceneFront.equalsIgnoreCase("null")) {
                        cParams.setSceneMode(this.m_strSceneFront);
                        DebugLog.WriteDebug(String.format("setSceneMode(%s)", this.m_strSceneFront));
                    }
                    if (this.m_strFocusModeFront.equalsIgnoreCase("face detection")) {
                        cParams.setFocusMode("continuous-video");
                        DebugLog.WriteDebug(String.format("setFocusMode(%s)", "continuous-video"));
                    } else if (this.m_strFocusModeFront != null && this.m_strFocusModeFront.length() != 0 && !this.m_strFocusModeFront.equalsIgnoreCase("null")) {
                        cParams.setFocusMode(this.m_strFocusModeFront);
                        DebugLog.WriteDebug(String.format("setFocusMode(%s)", this.m_strFocusModeFront));
                    }
                    if (this.m_strEffectFront != null && this.m_strEffectFront.length() != 0 && !this.m_strEffectFront.equalsIgnoreCase("null")) {
                        cParams.setColorEffect(this.m_strEffectFront);
                        DebugLog.WriteDebug(String.format("setColorEffect(%s)", this.m_strEffectFront));
                    }
                    if (this.m_strAutoExposureFront != null && this.m_strAutoExposureFront.length() > 0 && !this.m_strAutoExposureFront.equalsIgnoreCase("null")) {
                        cParams.set("metering", this.m_strAutoExposureFront);
                        cParams.set("meter-mode", this.m_strAutoExposureFront);
                        cParams.set("metering-mode", this.m_strAutoExposureFront);
                        cParams.set("auto-exposure", this.m_strAutoExposureFront);
                        DebugLog.WriteDebug(String.format("setMetering(%s)", this.m_strAutoExposureFront));
                    }
                    if (this.m_strISOValueFront != null && this.m_strISOValueFront.length() > 0 && !this.m_strISOValueFront.equalsIgnoreCase("null")) {
                        String strISOName = getISOParameterName();
                        if (strISOName.length() > 0) {
                            cParams.set(strISOName, this.m_strISOValueFront);
                            DebugLog.WriteDebug(String.format("setISO(%s)", this.m_strISOValueFront));
                        }
                    }
                    if (this.m_strSaturationFront != null && this.m_strSaturationFront.length() > 0 && getSupportedSaturationValues() != null && getSupportedSaturationValues().size() > 0) {
                        cParams.set("saturation", this.m_strSaturationFront);
                        DebugLog.WriteDebug(String.format("saturation(%s)", this.m_strSaturationFront));
                    }
                    if (this.m_strSharpnessFront != null && this.m_strSharpnessFront.length() > 0 && getSupportedSharpnessValues() != null && getSupportedSharpnessValues().size() > 0) {
                        cParams.set("sharpness", this.m_strSharpnessFront);
                        DebugLog.WriteDebug(String.format("sharpness(%s)", this.m_strSharpnessFront));
                    }
                    if (this.m_strBrightnessFront != null && this.m_strBrightnessFront.length() > 0 && getSupportedBrightnessValues() != null && getSupportedBrightnessValues().size() > 0) {
                        cParams.set("brightness", this.m_strBrightnessFront);
                        DebugLog.WriteDebug(String.format("brightness(%s)", this.m_strBrightnessFront));
                    }
                    if (this.m_strContrastFront != null && this.m_strContrastFront.length() > 0 && getSupportedContrastValues() != null && getSupportedContrastValues().size() > 0) {
                        cParams.set("contrast", this.m_strContrastFront);
                        DebugLog.WriteDebug(String.format("contrast(%s)", this.m_strContrastFront));
                    }
                } else {
                    cParams.setExposureCompensation(this.m_nExposure);
                    DebugLog.WriteDebug(String.format("setExposureCompensation(%d)", Integer.valueOf(this.m_nExposure)));
                    if (this.m_strAntiBanding != null && this.m_strAntiBanding.length() > 0 && !this.m_strAntiBanding.equalsIgnoreCase("null")) {
                        cParams.setAntibanding(this.m_strAntiBanding);
                        DebugLog.WriteDebug(String.format("setAntibanding(%s)", this.m_strAntiBanding));
                    }
                    if (this.m_strFlash != null && this.m_strFlash.length() != 0 && !this.m_strFlash.equalsIgnoreCase("null")) {
                        cParams.setFlashMode(this.m_strFlash);
                        DebugLog.WriteDebug(String.format("setFlashMode(%s)", this.m_strFlash));
                    }
                    if (this.m_strWB != null && this.m_strWB.length() != 0 && !this.m_strWB.equalsIgnoreCase("null")) {
                        cParams.setWhiteBalance(this.m_strWB);
                        DebugLog.WriteDebug(String.format("setWhiteBalance(%s)", this.m_strWB));
                    }
                    if (this.m_strScene != null && this.m_strScene.length() != 0 && !this.m_strScene.equalsIgnoreCase("null")) {
                        cParams.setSceneMode(this.m_strScene);
                        DebugLog.WriteDebug(String.format("setSceneMode(%s)", this.m_strScene));
                    }
                    Log.e("CameraView", "m_strFocusMode=" + this.m_strFocusMode);
                    if (this.m_strFocusMode.equalsIgnoreCase("face detection") || nMode == 2) {
                        cParams.setFocusMode("continuous-video");
                        DebugLog.WriteDebug(String.format("setFocusMode(%s)", "continuous-video"));
                    } else if (this.m_strFocusMode != null && this.m_strFocusMode.length() != 0 && !this.m_strFocusMode.equalsIgnoreCase("null")) {
                        cParams.setFocusMode(this.m_strFocusMode);
                        DebugLog.WriteDebug(String.format("setFocusMode(%s)", this.m_strFocusMode));
                    }
                    if (this.m_strEffect != null && this.m_strEffect.length() != 0 && !this.m_strEffect.equalsIgnoreCase("null")) {
                        cParams.setColorEffect(this.m_strEffect);
                        DebugLog.WriteDebug(String.format("setColorEffect(%s)", this.m_strEffect));
                    }
                    if (this.m_strAutoExposure != null && this.m_strAutoExposure.length() > 0 && !this.m_strAutoExposure.equalsIgnoreCase("null")) {
                        cParams.set("metering", this.m_strAutoExposure);
                        cParams.set("meter-mode", this.m_strAutoExposure);
                        cParams.set("metering-mode", this.m_strAutoExposure);
                        cParams.set("auto-exposure", this.m_strAutoExposure);
                        DebugLog.WriteDebug(String.format("setMetering(%s)", this.m_strAutoExposure));
                    }
                    if (this.m_strISOValue != null && this.m_strISOValue.length() > 0 && !this.m_strISOValue.equalsIgnoreCase("null")) {
                        String strISOName2 = getISOParameterName();
                        if (strISOName2.length() > 0) {
                            cParams.set(strISOName2, this.m_strISOValue);
                            DebugLog.WriteDebug(String.format("setISO(%s)", this.m_strISOValue));
                        }
                    }
                    if (this.m_strSaturation != null && this.m_strSaturation.length() > 0 && getSupportedSaturationValues() != null && getSupportedSaturationValues().size() > 0) {
                        cParams.set("saturation", this.m_strSaturation);
                        DebugLog.WriteDebug(String.format("saturation(%s)", this.m_strSaturation));
                    }
                    if (this.m_strSharpness != null && this.m_strSharpness.length() > 0 && getSupportedSharpnessValues() != null && getSupportedSharpnessValues().size() > 0) {
                        cParams.set("sharpness", this.m_strSharpness);
                        DebugLog.WriteDebug(String.format("sharpness(%s)", this.m_strSharpness));
                    }
                    if (this.m_strBrightness != null && this.m_strBrightness.length() > 0 && getSupportedBrightnessValues() != null && getSupportedBrightnessValues().size() > 0) {
                        cParams.set("brightness", this.m_strBrightness);
                        DebugLog.WriteDebug(String.format("brightness(%s)", this.m_strBrightness));
                    }
                    if (this.m_strContrast != null && this.m_strContrast.length() > 0 && getSupportedContrastValues() != null && getSupportedContrastValues().size() > 0) {
                        cParams.set("contrast", this.m_strContrast);
                        DebugLog.WriteDebug(String.format("contrast(%s)", this.m_strContrast));
                    }
                }
                Log.e("CameraView", "Focus mode=" + cParams.getFocusMode());
                this.m_cCameraWrapper.SetParameters(cParams);
                DebugLog.WriteDebug(cParams.flatten());
            } catch (Exception ex) {
                ex.printStackTrace();
                String strMess = ex.getMessage();
                if (strMess == null) {
                    DebugLog.WriteDebug("Exception in PrepareCamera");
                } else {
                    DebugLog.WriteDebug("Exception in PrepareCamera " + strMess);
                }
                if (cParams != null) {
                    DebugLog.WriteDebug("Wrong parameters: " + cParams.flatten());
                }
            }
        }
        try {
            CameraParamWrapper cParams2 = this.m_cCameraWrapper.GetParameters(true);
            Log.e("CameraView", "Focus mode=" + cParams2.getFocusMode());
            DebugLog.WriteDebug(cParams2.flatten());
            boolean bFront = IsFrontCamera();
            if (nMode == 1) {
                if (this.m_nFrameRates != 0 && this.m_nFrameRates <= 30) {
                    cParams2.setPreviewFrameRate(this.m_nFrameRates);
                    DebugLog.WriteDebug(String.format("cParams.setPreviewFrameRate(%d)", Integer.valueOf(this.m_nFrameRates)));
                }
                cParams2.setRecordingHint(true);
                DebugLog.WriteDebug("setRecordingHint(true)");
                Point szPref = cParams2.getPreferredPreviewSizeForVideo();
                if (bFront) {
                    ptSize2 = new Point(this.m_ptSizeFront);
                    if (CanCaptureWhileRecording()) {
                        cParams2.setPictureSize(this.m_szPhotoVideoFront.x, this.m_szPhotoVideoFront.y);
                        Log.e("lgCamera", String.format("setPictureSize(%d,%d)", Integer.valueOf(this.m_szPhotoVideoFront.x), Integer.valueOf(this.m_szPhotoVideoFront.y)));
                        DebugLog.WriteDebug(String.format("setPictureSize(%d,%d)", Integer.valueOf(this.m_szPhotoVideoFront.x), Integer.valueOf(this.m_szPhotoVideoFront.y)));
                    }
                } else {
                    ptSize2 = new Point(this.m_ptSize);
                    if (CanCaptureWhileRecording()) {
                        cParams2.setPictureSize(this.m_szPhotoVideo.x, this.m_szPhotoVideo.y);
                        Log.e("lgCamera", String.format("setPictureSize(%d,%d)", Integer.valueOf(this.m_szPhotoVideo.x), Integer.valueOf(this.m_szPhotoVideo.y)));
                        DebugLog.WriteDebug(String.format("setPictureSize(%d,%d)", Integer.valueOf(this.m_szPhotoVideo.x), Integer.valueOf(this.m_szPhotoVideo.y)));
                    }
                }
                if (szPref != null && ((szPref.y < ptSize2.y || szPref.x < ptSize2.x) && szPref.y > 0 && szPref.x > 0)) {
                    Log.e("lgCamera", String.format("Setting preffered size %dx%d", Integer.valueOf(szPref.x), Integer.valueOf(szPref.y)));
                    cParams2.setPreviewSize(szPref.x, szPref.y);
                    this.m_ptPreviewSize.x = szPref.x;
                    this.m_ptPreviewSize.y = szPref.y;
                } else {
                    cParams2.setPreviewSize(ptSize2.x, ptSize2.y);
                    Log.e("lgCamera", String.format("Setting preview size %dx%d", Integer.valueOf(ptSize2.x), Integer.valueOf(ptSize2.y)));
                    this.m_ptPreviewSize.x = ptSize2.x;
                    this.m_ptPreviewSize.y = ptSize2.y;
                }
                String strComScript2 = this.m_strScript;
                if (DebugLog.m_bDebug) {
                    DebugLog.WriteDebug("Using script: \n" + strComScript2);
                }
                if (szPref != null && this.m_nSDK >= 11) {
                    strComScript = strComScript2.replace("%pref_width%", String.valueOf(szPref.x)).replace("%pref_height%", String.valueOf(szPref.y));
                } else {
                    strComScript = strComScript2.replace("%pref_width%", String.valueOf(ptSize2.x)).replace("%pref_height%", String.valueOf(ptSize2.y));
                }
                String[] strArFields = strComScript.replace("%video_width%", String.valueOf(ptSize2.x)).replace("%video_height%", String.valueOf(ptSize2.y)).split(";");
                for (String strField : strArFields) {
                    int nPos = strField.indexOf(61);
                    if (nPos == -1) {
                        if (DebugLog.m_bDebug) {
                            DebugLog.WriteDebug("Error script line: " + strField);
                        }
                    } else {
                        cParams2.set(strField.substring(0, nPos), strField.substring(nPos + 1));
                        DebugLog.WriteDebug(String.format("set(%s,%s)", strField.substring(0, nPos), strField.substring(nPos + 1)));
                    }
                }
                DebugLog.WriteDebug(String.format("setPreviewSize(%d,%d)", Integer.valueOf(this.m_ptPreviewSize.x), Integer.valueOf(this.m_ptPreviewSize.y)));
                if (this.m_bMTKDevice) {
                    cParams2.set("cam-mode", "2");
                }
            } else {
                if (bFront) {
                    ptSize = new Point(this.m_szPhotoFront.x, this.m_szPhotoFront.y);
                } else {
                    ptSize = new Point(this.m_szPhoto.x, this.m_szPhoto.y);
                }
                cParams2.setPictureSize(ptSize.x, ptSize.y);
                Log.e("lgCamera", String.format("setPictureSize(%d,%d)", Integer.valueOf(ptSize.x), Integer.valueOf(ptSize.y)));
                DebugLog.WriteDebug(String.format("setPictureSize(%d,%d)", Integer.valueOf(ptSize.x), Integer.valueOf(ptSize.y)));
                cParams2.setRecordingHint(false);
                DebugLog.WriteDebug("setRecordingHint(false)");
                if (this.m_nManufacturer == 1) {
                    cParams2.set("cam-mode", 0);
                }
                List<Point> cArRes = getSupportedVideoRes();
                Point ptPreviewRes = new Point(0, 0);
                switch (nMode) {
                    case 2:
                        break;
                    default:
                        float fAspectNear = 0.0f;
                        float fAspectPhoto = ptSize.x / ptSize.y;
                        for (int n = 0; n < cArRes.size(); n++) {
                            Point ptRes = cArRes.get(n);
                            if (ptRes.x <= 1280) {
                                float fAspect = ptRes.x / ptRes.y;
                                if (fAspectNear == 0.0f || Math.abs(fAspect - fAspectPhoto) < Math.abs(fAspectNear - fAspectPhoto) || (Math.abs(fAspect - fAspectPhoto) == Math.abs(fAspectNear - fAspectPhoto) && ptRes.x > ptPreviewRes.x)) {
                                    fAspectNear = fAspect;
                                    ptPreviewRes = ptRes;
                                }
                            }
                        }
                        if (fAspectNear == 0.0f) {
                            cParams2.setPreviewSize(640, 480);
                            this.m_ptPreviewSize.x = 640;
                            this.m_ptPreviewSize.y = 480;
                            break;
                        } else {
                            cParams2.setPreviewSize(ptPreviewRes.x, ptPreviewRes.y);
                            this.m_ptPreviewSize = ptPreviewRes;
                            break;
                        }
                        break;
                }
                for (int n2 = 0; n2 < cArRes.size(); n2++) {
                    Point ptRes2 = cArRes.get(n2);
                    if (ptRes2.y <= 720 && (ptRes2.y > ptPreviewRes.y || (ptRes2.y == ptPreviewRes.y && ptRes2.x > ptPreviewRes.x))) {
                        ptPreviewRes = ptRes2;
                    }
                }
                cParams2.setPreviewSize(ptPreviewRes.x, ptPreviewRes.y);
                cParams2.setPreviewFormat(17);
                this.m_ptPreviewSize = ptPreviewRes;
                DebugLog.WriteDebug(String.format("setPreviewSize(%d,%d)", Integer.valueOf(this.m_ptPreviewSize.x), Integer.valueOf(this.m_ptPreviewSize.y)));
                Log.e("lgCamera", String.format("Preview size is %dx%d", Integer.valueOf(ptPreviewRes.x), Integer.valueOf(ptPreviewRes.y)));
                if (this.m_nExynos > 0) {
                    cParams2.set("cam_mode", 0);
                    DebugLog.WriteDebug("cam_mode=0");
                }
            }
            cParams2.setAutoExposureLock(this.m_bAELock);
            cParams2.setAutoWhiteBalanceLock(this.m_bWBLock);
            DebugLog.WriteDebug(cParams2.flatten());
            this.m_cCameraWrapper.SetParameters(cParams2);
            DebugLog.WriteDebug("m_cCameraWrapper.SetParameters(cParams);");
            Log.e("CameraView", "Focus mode=" + cParams2.getFocusMode());
        } catch (Exception ex2) {
            ex2.printStackTrace();
            String strMess2 = ex2.getMessage();
            if (strMess2 == null) {
                DebugLog.WriteDebug("Exception in PrepareCamera");
            } else {
                DebugLog.WriteDebug("Exception in PrepareCamera " + strMess2);
            }
        }
        DebugLog.WriteDebug("PrepareCamera ends");
        Log.e("lgCamera", "PrepareCamera ends");
        getMaxZoom();
    }

    public void StopCamera() {
        this.m_cMainWnd.m_cHandler.removeCallbacks(this.m_cRestoreFM);
        if (this.m_cCameraWrapper.Initialized()) {
            this.m_cCameraWrapper.StopFaceDetection();
            Log.e("lgCamera", "Stop camera!");
            try {
                this.m_cCameraWrapper.StopPreview();
            } catch (Exception e) {
            }
            try {
                this.m_cCameraWrapper.ReleaseCamera();
            } catch (Exception e2) {
            }
            this.m_strArSupportedAB = null;
            this.m_cArAutoExposures = null;
            this.m_cArBrightnessValues = null;
            this.m_cArSupportedCE = null;
            this.m_cArContrastValues = null;
            this.m_cArSupportedExposure = null;
            this.m_cArSupportedFM = null;
            this.m_cArFocusMode = null;
            this.m_cArISOValues = null;
            this.m_cArPhotoSizes = null;
            this.m_cArSaturationValues = null;
            this.m_cArScenes = null;
            this.m_cArSharpnessValues = null;
            this.m_cArVideoRes = null;
            this.m_cArSupportedWB = null;
            this.m_bICSPhotoBusy = false;
        }
    }

    public void IndexingPathInGallery(String strFileName) {
        File cFile = new File(strFileName);
        if (!cFile.isDirectory() && cFile.exists()) {
            MediaScannerConnection.scanFile(this.m_cMainWnd, new String[]{cFile.getAbsolutePath()}, null, new MediaScannerConnection.OnScanCompletedListener() { // from class: com.android.camera.CameraView.9
                @Override // android.media.MediaScannerConnection.OnScanCompletedListener
                public void onScanCompleted(String path, Uri uri) {
                    CameraView.this.m_cMainWnd.runOnUiThread(CameraView.this.m_cUpdateGalIcon);
                }
            });
        }
    }

    public synchronized void MakeFocus(boolean bFromSensor) {
        if (this.m_cCameraWrapper.Initialized() && ((!this.m_bStarted || this.m_bPaused) && this.m_bCanShot)) {
            long lCurTime = System.currentTimeMillis();
            if (!bFromSensor || lCurTime - this.m_lLastTimeFocus >= 2000) {
                this.m_lLastTimeFocus = lCurTime;
                this.m_cCameraWrapper.cancelAutoFocus();
                Log.e("lgCamera", "invoking autofocus");
                this.m_cMainWnd.m_cHandler.removeCallbacks(this.m_cRestoreFM);
                this.m_cCameraWrapper.AutoFocus();
                this.m_cMainWnd.UpdateFocusRect(-1, -1);
                this.m_bNeedSensorFocus = false;
            }
        }
    }

    private boolean MakeFocusICS(int nX, int nY) {
        DebugLog.WriteDebug(String.format("MakeFocusICS(%d, %d)", Integer.valueOf(nX), Integer.valueOf(nY)));
        if (!this.m_cCameraWrapper.Initialized()) {
            Log.e("CameraView", "ICS focus failed, m_cCamera==null");
            DebugLog.WriteDebug("ICS focus failed, m_cCamera==null");
            return false;
        }
        try {
            CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(true);
            int nFocusAreasCount = cParams.getMaxNumFocusAreas();
            if (nFocusAreasCount > 0) {
                Log.e("CameraView", String.format("Trying ICS focusmode, (W=%d,H=%d)", Integer.valueOf(this.m_ptPreviewSize.x), Integer.valueOf(this.m_ptPreviewSize.y)));
                int nXFocus = ((nX * 2000) / this.m_ptPreviewSize.x) - 1000;
                int nYFocus = ((nY * 2000) / this.m_ptPreviewSize.y) - 1000;
                int nLeftFocus = nXFocus - 100;
                int nRightFocus = nXFocus + 100;
                if (nLeftFocus < -1000) {
                    nLeftFocus = -1000;
                    nRightFocus = (-1000) + 200;
                }
                if (nRightFocus > 1000) {
                    nRightFocus = 1000;
                    nLeftFocus = 1000 - 200;
                }
                int nTopFocus = nYFocus - 100;
                int nBottomFocus = nYFocus + 100;
                if (nTopFocus < -1000) {
                    nTopFocus = -1000;
                    nBottomFocus = (-1000) + 200;
                }
                if (nBottomFocus > 1000) {
                    nBottomFocus = 1000;
                    nTopFocus = 1000 - 200;
                }
                Rect rcArea = new Rect(nLeftFocus, nTopFocus, nRightFocus, nBottomFocus);
                Log.e("CameraView", String.format("Focus area(%d,%d,%d,%d)", Integer.valueOf(nLeftFocus), Integer.valueOf(nTopFocus), Integer.valueOf(nRightFocus), Integer.valueOf(nBottomFocus)));
                List<Rect> rcAreas = new Vector<>();
                rcAreas.add(rcArea);
                try {
                    cParams.setFocusAreas(rcAreas);
                    this.m_cCameraWrapper.SetParameters(cParams);
                    Log.e("CameraView", "ICS focus updating focus rect");
                    this.m_cMainWnd.UpdateFocusRect(nX, nY);
                    DebugLog.WriteDebug(String.format("m_cMainWnd.UpdateFocusRect(%d, %d)", Integer.valueOf(nX), Integer.valueOf(nY)));
                    this.m_cMainWnd.m_cHandler.removeCallbacks(this.m_cRestoreFM);
                    this.m_cCameraWrapper.AutoFocus();
                    this.m_cMainWnd.onCameraViewAction(17);
                    return true;
                } catch (Exception ex) {
                    ex.printStackTrace();
                    DebugLog.WriteDebug("Make ICS focus (x,y) error " + ex.getMessage());
                    Log.e("CameraView", "ICS focus failed");
                }
            }
        } catch (Exception ex2) {
            ex2.printStackTrace();
        }
        Log.e("CameraView", "ICS focus failed");
        DebugLog.WriteDebug("ICS focus failed");
        return false;
    }

    public synchronized void MakeFocus(int nX, int nY) {
        if (this.m_cCameraWrapper.Initialized()) {
            this.m_bNeedSensorFocus = false;
            this.m_lLastTimeFocus = System.currentTimeMillis();
            try {
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(true);
                if (!this.m_bStarted) {
                    String strFlash = this.m_strFlash;
                    if (this.m_bFlashOnFocus && !strFlash.equalsIgnoreCase("torch")) {
                        cParams.setFlashMode("torch");
                        this.m_bFocusFlash = true;
                    }
                }
                String strFocusMode = cParams.getFocusMode();
                Log.e("lgCamera", "Focus mode=" + strFocusMode);
                if (strFocusMode != null && !strFocusMode.equals("auto")) {
                    cParams.setFocusMode("auto");
                    this.m_cCameraWrapper.SetParameters(cParams);
                    cParams = this.m_cCameraWrapper.GetParameters(true);
                }
                if (this.m_nSDK < 14 || !MakeFocusICS(nX, nY)) {
                    Log.e("CameraView", "MakeFocus old mode");
                    DebugLog.WriteDebug("MakeFocus old mode");
                    if (this.m_nManufacturer == 1) {
                        Log.e("lgCamera", "touch autofocusing");
                        try {
                            cParams.set("touch-focus", nX + "," + nY);
                            this.m_cMainWnd.UpdateFocusRect(nX, nY);
                            cParams.set("touch-aec", "on");
                            cParams.set("enable-caf", "off");
                            cParams.set("capture-mode", "normal");
                            SetGPUEffect(cParams, "0_bypass");
                            SetGEParam(cParams, "GE-param0", 0, 0, 0, 0, false);
                            SetGEParam(cParams, "GE-param1", 0, 0, 0, 0, false);
                            this.m_cCameraWrapper.SetParameters(cParams);
                            this.m_cMainWnd.m_cHandler.removeCallbacks(this.m_cRestoreFM);
                            this.m_cCameraWrapper.AutoFocus();
                            this.m_cMainWnd.onCameraViewAction(17);
                        } catch (Exception ex) {
                            Log.e("lgCamera touch focus exception", ex.getMessage());
                        }
                    } else if (this.m_nManufacturer == 2 && InvokeHelper.IsMethodExist(this.m_cCameraWrapper, "setObjectTrackingPosition")) {
                        this.m_cMainWnd.UpdateFocusRect(nX, nY);
                        InvokeHelper.InvokeMethodFast(this.m_cCameraWrapper, "stopTouchAutoFocus");
                        InvokeHelper.InvokeMethodFast(this.m_cCameraWrapper, "setObjectTrackingPosition", nX, nY);
                        InvokeHelper.InvokeMethodFast(this.m_cCameraWrapper, "startTouchAutoFocus");
                        this.m_cMainWnd.m_cHandler.removeCallbacks(this.m_cRestoreFM);
                        this.m_cCameraWrapper.AutoFocus();
                        this.m_cMainWnd.onCameraViewAction(17);
                    } else {
                        Log.e("lgCamera", "simple autofocusing");
                        MakeFocus(false);
                    }
                }
            } catch (Exception ex1) {
                ex1.printStackTrace();
            }
        }
    }

    @Override // android.hardware.SensorEventListener
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    @Override // android.hardware.SensorEventListener
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == 1) {
            this.m_cGridView.setAcceleration(event.values[0], event.values[1], event.values[2]);
            if (this.m_bAllowSensorFocus) {
                double dG = Math.abs(Math.sqrt((Math.pow(event.values[0], 2.0d) + Math.pow(event.values[1], 2.0d)) + Math.pow(event.values[2], 2.0d)) - 10.0d);
                if (dG < 0.20000000298023224d) {
                    if (this.m_bNeedSensorFocus) {
                        MakeFocus(true);
                    }
                    this.m_bNeedSensorFocus = false;
                } else {
                    this.m_bNeedSensorFocus = true;
                }
            }
            this.m_fArAccelClear = (float[]) event.values.clone();
        }
    }

    private void CalcLastIndexJPG() {
        try {
            File cFile = new File(m_strFolder);
            cFile.list(new FilenameFilter() { // from class: com.android.camera.CameraView.10
                @Override // java.io.FilenameFilter
                public boolean accept(File dir, String filename) {
                    int nPos;
                    int nPos2 = filename.lastIndexOf(47);
                    if (nPos2 != -1) {
                        String filename2 = filename.substring(nPos2 + 1).toLowerCase();
                        if (filename2.indexOf("image") == 0 && (nPos = filename2.lastIndexOf(46)) != -1) {
                            String strExt = filename2.substring(nPos + 1);
                            if (strExt.equals("jpg") || strExt.equals("png")) {
                                int nIndex = Integer.valueOf(filename2.substring(5, nPos)).intValue();
                                CameraView.this.m_nLastIMGIndex = Math.max(nIndex, CameraView.this.m_nLastIMGIndex);
                            }
                        }
                    }
                    return false;
                }
            });
        } catch (Exception e) {
        }
    }

    private void CalcLastIndexVideo() {
        try {
            File cFile = new File(m_strFolder);
            cFile.list(new FilenameFilter() { // from class: com.android.camera.CameraView.11
                @Override // java.io.FilenameFilter
                public boolean accept(File dir, String filename) {
                    int nPos;
                    int nPos2 = filename.lastIndexOf(47);
                    if (nPos2 != -1) {
                        String filename2 = filename.substring(nPos2 + 1).toLowerCase();
                        if (filename2.indexOf("video") == 0 && (nPos = filename2.lastIndexOf(46)) != -1) {
                            String strExt = filename2.substring(nPos + 1);
                            if (strExt.equals("3gp") || strExt.equals("mp4")) {
                                int nIndex = Integer.valueOf(filename2.substring(5, nPos)).intValue();
                                CameraView.this.m_nLastVIDIndex = Math.max(nIndex, CameraView.this.m_nLastVIDIndex);
                            }
                        }
                    }
                    return false;
                }
            });
        } catch (Exception e) {
        }
    }

    public void ReleaseCameraViewAndExit() {
        try {
            this.m_cSaveThread.Exit();
            this.m_cSaveThread.join();
        } catch (Exception e) {
        }
        if (this.m_cSensorManager != null) {
            this.m_cSensorManager.unregisterListener(this);
        }
    }

    @Override // com.android.camera.SaveFileThread.SaveFileListener
    public void onFileSaved(String strFileName, boolean bIndexingInGallery) {
        if (bIndexingInGallery && (this.m_cMainWnd.m_bIndexInGallery || this.m_nPreviewTime < 1000)) {
            IndexingPathInGallery(strFileName);
        }
        this.m_cMainWnd.runOnUiThread(this.m_cUpdateFilesRunnable);
    }

    protected void AutoConfigure() {
        CamcorderProfile cCamCorderProfile = CamcorderProfile.get(1);
        this.m_nBitRate = BitrateSampleRateHelper.getNearestVideoBitrate(cCamCorderProfile.videoBitRate);
        this.m_nEncoder = cCamCorderProfile.videoCodec;
        this.m_nFormat = cCamCorderProfile.fileFormat;
        this.m_ptSize.x = cCamCorderProfile.videoFrameWidth;
        this.m_ptSize.y = cCamCorderProfile.videoFrameHeight;
        this.m_nFrameRates = cCamCorderProfile.videoFrameRate;
        this.m_nAudioEncoder = cCamCorderProfile.audioCodec;
        this.m_nAudioBitRate = BitrateSampleRateHelper.getNearestAudioBitrate(cCamCorderProfile.audioBitRate);
        this.m_nSamplingRate = BitrateSampleRateHelper.getNearestAudioSamplerate(cCamCorderProfile.audioSampleRate);
        this.m_nAudioChannels = cCamCorderProfile.audioChannels;
        CamcorderProfile cCamCorderProfile2 = null;
        try {
            cCamCorderProfile2 = (CamcorderProfile) InvokeHelper.InvokeStaticMethod(Class.forName("android.media.CamcorderProfile"), "get", 1, 1);
        } catch (Exception e) {
        }
        if (cCamCorderProfile2 == null) {
            cCamCorderProfile2 = CamcorderProfile.get(0);
        }
        this.m_ptSizeFront.x = cCamCorderProfile2.videoFrameWidth;
        this.m_ptSizeFront.y = cCamCorderProfile2.videoFrameHeight;
        try {
            this.m_cCameraWrapper.ReleaseCamera();
        } catch (Exception e2) {
        }
    }

    public boolean IsPauseExist() {
        return this.m_bPauseExist;
    }

    public boolean IsPaused() {
        return this.m_bPaused;
    }

    public synchronized void Pause() {
        if (this.m_bPauseExist && !this.m_bPaused) {
            try {
                MuteStreams();
                DebugLog.WriteDebug("Pausing");
                this.m_cCameraWrapper.PauseRecording();
                this.m_bPaused = true;
                this.m_cMainWnd.onCameraViewAction(11);
                DebugLog.WriteDebug("Paused");
            } catch (Exception ex) {
                DebugLog.WriteDebug("Pause error " + ex.toString() + " " + ex.getMessage());
            }
            UnmuteStreams();
        } else {
            DebugLog.WriteDebug("Pausing is not allowed");
        }
    }

    public synchronized void Resume() {
        if (this.m_bPauseExist && this.m_bPaused) {
            try {
                MuteStreams();
                DebugLog.WriteDebug("Resuming");
                this.m_cCameraWrapper.ResumeRecording();
                this.m_bPaused = false;
                this.m_cMainWnd.onCameraViewAction(12);
                DebugLog.WriteDebug("Resumed");
            } catch (Exception ex) {
                ex.printStackTrace();
                DebugLog.WriteDebug("Resume error " + ex.toString() + " " + ex.getMessage());
            }
            UnmuteStreams();
        } else {
            DebugLog.WriteDebug("Resuming is not allowed");
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper.OnCameraWrapperEventListener
    public void onShutter() {
        Log.e("lgCamera", "onShutter");
        if (this.m_nPhotoMode != 1) {
            this.m_cGridView.ShowSparkle();
        }
    }

    public int GetCameraCount() {
        try {
            return Integer.valueOf(String.valueOf(InvokeHelper.InvokeStaticMethod(Camera.class, "getNumberOfCameras"))).intValue();
        } catch (Exception e) {
            return 1;
        }
    }

    public void SwitchCamera() {
        this.m_cMainWnd.m_cHandler.removeCallbacks(this.m_cRestoreFM);
        try {
            if (this.m_bStarted) {
                StopRecord();
            }
            StopCamera();
            this.m_bFirstInit = true;
            int nCameras = GetCameraCount();
            this.m_nCameraNum++;
            if (this.m_nCameraNum >= nCameras) {
                this.m_nCameraNum = 0;
            }
            StartPreview(false);
        } catch (Exception ex) {
            ex.printStackTrace();
            DebugLog.WriteDebug(ex.getLocalizedMessage());
        }
    }

    private void MuteStreams() {
        if (this.m_bTurnOffSounds) {
            this.m_nLastSystemVolume = this.m_cAudioManager.getStreamVolume(1);
            this.m_nLastMusicVolume = this.m_cAudioManager.getStreamVolume(3);
            this.m_cAudioManager.setStreamVolume(1, 0, 0);
            this.m_cAudioManager.setStreamVolume(3, 0, 0);
            this.m_cAudioManager.setStreamMute(1, true);
            this.m_cAudioManager.setStreamMute(3, true);
        }
    }

    private void UnmuteStreams() {
        if (this.m_bTurnOffSounds) {
            this.m_cAudioManager.setStreamMute(1, false);
            this.m_cAudioManager.setStreamMute(3, false);
            this.m_cAudioManager.setStreamVolume(1, this.m_nLastSystemVolume, 0);
            this.m_cAudioManager.setStreamVolume(3, this.m_nLastMusicVolume, 0);
        }
    }

    public void SwitchFlashMode() {
        List<String> strArFM = getSupportedFM();
        if (!this.m_bStarted && strArFM != null && strArFM.size() != 0) {
            int nIndex = -1;
            String strFlash = IsFrontCamera() ? this.m_strFlashFront : this.m_strFlash;
            int n = 0;
            while (true) {
                if (n >= strArFM.size()) {
                    break;
                } else if (!strFlash.equalsIgnoreCase(strArFM.get(n))) {
                    n++;
                } else {
                    nIndex = n;
                    break;
                }
            }
            int nIndex2 = nIndex + 1;
            if (nIndex2 >= strArFM.size()) {
                nIndex2 = 0;
            }
            if (IsFrontCamera()) {
                setFlashModeFront(strArFM.get(nIndex2));
            } else {
                setFlashMode(strArFM.get(nIndex2));
            }
        }
    }

    private void SetGEParam(Object cParams, String str, int nPar1, int nPar2, int nPar3, int nPar4, boolean bVal) {
        InvokeHelper.InvokeMethodFast(cParams, "set", "GE-param3", "1,1," + nPar3 + "," + nPar4);
        InvokeHelper.InvokeMethodFast(cParams, "set", str, nPar1 + "," + nPar2 + "," + nPar3 + "," + nPar4);
    }

    private void SetGPUEffect(Object cParams, String strEffect) {
        InvokeHelper.InvokeMethodFast(cParams, "set", "GPU-effect", strEffect);
    }

    private void EnableSoundEffects() {
        try {
            this.m_cAudioManager.setParameters("CAMCORDER_MODE=ON");
            if (this.m_cAudioSystemClass == null) {
                this.m_cAudioSystemClass = Class.forName("android.media.AudioSystem");
            }
            if (this.m_cAudioSystemClass != null) {
                if (this.m_bAutoRotate) {
                    switch (this.m_cMainWnd.m_nLastOrientation) {
                        case 0:
                        case 4:
                            InvokeHelper.InvokeStaticMethod(this.m_cAudioSystemClass, "setParameters", "active_ap=Camcorder;dolby_srs_eq=Portrait");
                            break;
                        case 1:
                            InvokeHelper.InvokeStaticMethod(this.m_cAudioSystemClass, "setParameters", "active_ap=Camcorder;dolby_srs_eq=Landscape_Left");
                            break;
                        case 2:
                            InvokeHelper.InvokeStaticMethod(this.m_cAudioSystemClass, "setParameters", "active_ap=Camcorder;dolby_srs_eq=Landscape_Right");
                            break;
                    }
                    InvokeHelper.InvokeStaticMethod(this.m_cAudioSystemClass, "setParameters", "active_ap=Camcorder;dolby_srs_eq=Landscape_Left");
                } else {
                    InvokeHelper.InvokeStaticMethod(this.m_cAudioSystemClass, "setParameters", "active_ap=Camcorder;dolby_srs_eq=Landscape_Left");
                }
                InvokeHelper.InvokeStaticMethod(this.m_cAudioSystemClass, "setParameters", "active_ap=Camcorder;sound_effect_enable=on");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            DebugLog.WriteDebug("Set audioeffect error " + ex.toString() + " " + ex.getMessage());
        }
    }

    private void DisableSoundEffects() {
        try {
            if (this.m_cAudioSystemClass == null) {
                this.m_cAudioSystemClass = Class.forName("android.media.AudioSystem");
            }
            if (this.m_cAudioSystemClass != null) {
                InvokeHelper.InvokeStaticMethod(this.m_cAudioSystemClass, "setParameters", "active_ap=Camcorder;sound_effect_enable=off");
            }
        } catch (Exception ex) {
            DebugLog.WriteDebug("Set audioeffect error " + ex.toString() + " " + ex.getMessage());
        }
    }

    public boolean CanCaptureWhileRecording() {
        if (this.m_nExynos <= 1 || this.m_nSDK < 14 || this.m_bVStab) {
            try {
                if (this.m_cCameraWrapper.Initialized()) {
                    CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(true);
                    return cParams.isVideoSnapshotSupported();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return false;
        }
        return true;
    }

    public synchronized void TakePictureICS(boolean bBurst) {
        synchronized (this) {
            if (this.m_nSDK >= 14) {
                if (this.m_bICSPhotoBusy) {
                    Log.e("lgCamera", "ICS photo is busy");
                } else if (!this.m_bCanShot) {
                    Log.e("lgCamera", "ICS photo can not shot");
                } else {
                    this.m_bICSBurstPhotoMode = bBurst;
                    this.m_bICSPhotoBusy = true;
                    this.m_strFileNameICS = getNewFileNameJpeg();
                    DebugLog.WriteDebug("JPG name = " + this.m_strFileNameICS);
                    try {
                        DebugLog.WriteDebug("Setting camera parameters");
                        CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(bBurst ? false : true);
                        cParams.setJpegQuality(this.m_nJPEGQuality);
                        cParams.setPictureFormat(256);
                        if (IsFrontCamera()) {
                            cParams.setPictureSize(this.m_szPhotoVideoFront.x, this.m_szPhotoVideoFront.y);
                            Log.e("lgCamera", String.format("setPictureSize(%d,%d)", Integer.valueOf(this.m_szPhotoVideoFront.x), Integer.valueOf(this.m_szPhotoVideoFront.y)));
                            DebugLog.WriteDebug(String.format("setPictureSize(%d,%d)", Integer.valueOf(this.m_szPhotoVideoFront.x), Integer.valueOf(this.m_szPhotoVideoFront.y)));
                        } else {
                            cParams.setPictureSize(this.m_szPhotoVideo.x, this.m_szPhotoVideo.y);
                            Log.e("lgCamera", String.format("setPictureSize(%d,%d)", Integer.valueOf(this.m_szPhotoVideo.x), Integer.valueOf(this.m_szPhotoVideo.y)));
                            DebugLog.WriteDebug(String.format("setPictureSize(%d,%d)", Integer.valueOf(this.m_szPhotoVideo.x), Integer.valueOf(this.m_szPhotoVideo.y)));
                        }
                        if (this.m_bAutoRotate) {
                            switch (this.m_cMainWnd.m_nLastOrientation) {
                                case 0:
                                case 4:
                                    if (this.m_nCameraNum == 1) {
                                        cParams.setRotation(270);
                                        break;
                                    } else {
                                        cParams.setRotation(90);
                                        break;
                                    }
                                case 1:
                                    cParams.setRotation(180);
                                    break;
                                case 2:
                                    if (this.m_nCameraNum == 1) {
                                        cParams.setRotation(90);
                                        break;
                                    } else {
                                        cParams.setRotation(270);
                                        break;
                                    }
                                case 3:
                                default:
                                    cParams.setRotation(0);
                                    break;
                            }
                        } else {
                            cParams.setRotation(0);
                        }
                        if (this.m_bUseGPSEXIF) {
                            Log.e("lgCamera", "Add GPS to exif");
                            Location cLoc = this.m_cMainWnd.getLastKnownLocation();
                            if (cLoc != null) {
                                Log.e("lgCamera", "GPS is not null, adding");
                                if (cLoc.hasAltitude()) {
                                    cParams.setGpsAltitude(cLoc.getAltitude());
                                }
                                cParams.setGpsLatitude(cLoc.getLatitude());
                                cParams.setGpsLongitude(cLoc.getLongitude());
                                cParams.setGpsProcessingMethod(cLoc.getProvider());
                                Time cTime = new Time();
                                cTime.setToNow();
                                cParams.setGpsTimestamp(cTime.toMillis(true) / 1000);
                            }
                        }
                        this.m_cCameraWrapper.SetParameters(cParams);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                    Log.e("lgCamera", "Capturing photo ICS, name=" + this.m_strFileNameICS);
                    DebugLog.WriteDebug("Capturing photo ICS, name=" + this.m_strFileNameICS);
                    try {
                        this.m_cCameraWrapper.TakePicture();
                    } catch (Exception ex2) {
                        ex2.printStackTrace();
                        this.m_bICSPhotoBusy = false;
                        DebugLog.WriteDebug("Capturing photo ICS error!");
                    }
                }
            }
        }
    }

    public int getPhotoMode() {
        return this.m_nPhotoMode;
    }

    public void setPhotoMode(int nMode) {
        this.m_nPhotoMode = nMode;
    }

    public synchronized void StartPanoramaTakingPictures() {
        if (this.m_cPanoramaCollection.GetMode() == 0) {
            this.m_bPanoramaTakingPic = false;
            PrepareCamera(2);
            setZoomValue(0);
            Point ptSize = this.m_cCameraWrapper.GetParameters(true).getPreviewSize();
            this.m_nPhotoMode = 2;
            this.m_cPanoramaCollection.SetPanoramaListener(this);
            this.m_cPanoramaCollection.InitPanorama(ptSize.x, ptSize.y, this.m_cMainWnd.m_nLastOrientation, this.m_bFullSweep);
            this.m_cGridView.setDrawPanoramaRect(true, this.m_cMainWnd.m_nLastOrientation);
            this.m_cCameraWrapper.StartPreviewCallback();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper.OnCameraWrapperEventListener
    public void onRecordError(int what, int extra) {
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper.OnCameraWrapperEventListener
    public void onRecordInfo(int what, int extra) {
        switch (what) {
            case 800:
            case 801:
                if (this.m_bStartRecordNewAfterStop) {
                    try {
                        this.m_bCanShot = false;
                        this.m_cMainWnd.onCameraViewAction(9);
                        MuteStreams();
                        this.m_cCameraWrapper.StopRecording();
                        IndexingPathInGallery(this.m_strFileName);
                        ClearMR();
                        if (this.m_nManufacturer == 1 && this.m_nAudioChannels > 1) {
                            DisableSoundEffects();
                        }
                        this.m_cAudioManager.setParameters("CAMCORDER_MODE=OFF");
                        Log.e("lgCamera", "Reconnect camera");
                        try {
                            this.m_cCameraWrapper.ReconnectCamera();
                        } catch (Exception ex1) {
                            ex1.printStackTrace();
                        }
                        if (this.m_bRestartCamera) {
                            Log.e("lgCamera", "Stopping camera");
                            StopCamera();
                        }
                        this.m_bStarted = false;
                        this.m_bPauseExist = false;
                        this.m_bPaused = false;
                        StartRecordInternal();
                        return;
                    } catch (Exception e) {
                        StopRecord();
                        StartPreview(false);
                        return;
                    }
                }
                StopRecord();
                StartPreview(false);
                return;
            default:
                return;
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper.OnCameraWrapperEventListener
    public void onAutoFocus(boolean bSuccess) {
        Log.e("lgCamera", "onAutoFocus");
        CameraParamWrapper cParams = null;
        try {
            cParams = this.m_cCameraWrapper.GetParameters(true);
            if (!this.m_bStarted) {
                this.m_cMainWnd.m_cHandler.removeCallbacks(this.m_cRestoreFM);
                this.m_cMainWnd.m_cHandler.postDelayed(this.m_cRestoreFM, 5000L);
            }
            if (this.m_bFocusFlash) {
                String strFlash = this.m_strFlash;
                cParams.setFlashMode(strFlash);
            }
            this.m_cCameraWrapper.SetParameters(cParams);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        switch (this.m_nForceAutofocusing) {
            case 1:
                TakePicture(false);
                this.m_nForceAutofocusing = 0;
                return;
            case 2:
                StartRecordInternal();
                this.m_nForceAutofocusing = 0;
                return;
            default:
                this.m_bNeedSensorFocus = false;
                if (cParams != null) {
                    try {
                        if (cParams.getFocusMode().indexOf("continuous-") == -1) {
                            if (bSuccess) {
                                this.m_cMainWnd.onCameraViewAction(10);
                            } else {
                                this.m_cMainWnd.onCameraViewAction(14);
                            }
                        }
                    } catch (Exception e) {
                    }
                }
                this.m_lLastTimeFocus = System.currentTimeMillis();
                return;
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper.OnCameraWrapperEventListener
    public void onPictureTaken(byte[] data) {
        DebugLog.WriteDebug("onPictureTaken reached, leng " + data.length);
        Log.e("CameraView", "onPictureTaken reached, size " + data.length + " mode " + this.m_nPhotoMode);
        if (data != null) {
            switch (this.m_nPhotoMode) {
                case 1:
                    Log.e("CameraView", "onPictureTaken burst mode");
                    try {
                        JPEGData cJPEGData = new JPEGData(data, this.m_strFileName);
                        DebugLog.WriteDebug("JPEGData cJPEGData=new JPEGData(data,m_strFileName);");
                        cJPEGData.m_bFreeVersion = this.m_bFreeVersion;
                        cJPEGData.m_lDate = System.currentTimeMillis();
                        cJPEGData.m_szPhoto = this.m_szPhoto;
                        if (this.m_nCameraNum == 1) {
                            cJPEGData.m_szPhoto = this.m_szPhotoFront;
                        }
                        if (this.m_bUseGPSEXIF) {
                            cJPEGData.m_cCameraView = this;
                        }
                        this.m_cSaveThread.AddJPEGData(cJPEGData);
                        DebugLog.WriteDebug("m_cSaveThread.AddJPEGData(cJPEGData);");
                    } catch (Exception ex) {
                        Log.e("lgCamera", ex.getMessage());
                        DebugLog.WriteDebug("Jpeg add failed " + ex.getMessage());
                    }
                    Log.e("CameraView", "JPEGData added");
                    this.m_cCameraWrapper.StartPreview();
                    this.m_bCanShot = true;
                    this.m_cMainWnd.onCameraViewAction(15);
                    Log.e("CameraView", "m_cMainWnd.onCameraViewAction(BURSTPHOTO_CAPTURED);");
                    return;
                default:
                    Log.e("lgCamera", "m_bICSPhotoBusy=" + this.m_bICSPhotoBusy);
                    if (this.m_bICSPhotoBusy) {
                        Log.e("lgCamera", "onPictureTaken ICS reached");
                        DebugLog.WriteDebug("onPictureTaken ICS reached");
                        if (data != null) {
                            try {
                                JPEGData cJPEGData2 = new JPEGData(data, this.m_strFileNameICS);
                                DebugLog.WriteDebug("JPEGData cJPEGData=new JPEGData(data,m_strFileName);");
                                cJPEGData2.m_bFreeVersion = this.m_bFreeVersion;
                                cJPEGData2.m_lDate = System.currentTimeMillis();
                                if (!this.m_bICSBurstPhotoMode) {
                                    cJPEGData2.m_bOverlay = this.m_bOverlayDateTime;
                                }
                                cJPEGData2.m_szPhoto = this.m_szPhoto;
                                if (this.m_nCameraNum == 1) {
                                    cJPEGData2.m_szPhoto = this.m_szPhotoFront;
                                }
                                if (this.m_bUseGPSEXIF) {
                                    cJPEGData2.m_cCameraView = this;
                                }
                                this.m_cSaveThread.AddJPEGData(cJPEGData2);
                                DebugLog.WriteDebug("m_cSaveThread.AddJPEGData(cJPEGData);");
                            } catch (Exception ex2) {
                                Log.e("lgCamera", ex2.getMessage());
                                DebugLog.WriteDebug("Jpeg add failed " + ex2.getMessage());
                            }
                        }
                        this.m_bICSPhotoBusy = false;
                        if (!this.m_bICSBurstPhotoMode) {
                            this.m_cMainWnd.runOnUiThread(this.m_cUpdateFilesRunnable);
                            return;
                        } else {
                            this.m_cMainWnd.onCameraViewAction(16);
                            return;
                        }
                    }
                    this.m_cGridView.ShowSparkle();
                    if (!this.m_cMainWnd.m_bImageCaptureIntent) {
                        this.m_cMainWnd.ShowPostviewImage(data, true);
                        DebugLog.WriteDebug("onPictureTaken");
                        Log.e("CameraView", "ShowPostView");
                    }
                    UnmuteStreams();
                    Log.e("CameraView", "UnmuteStreams();");
                    if (this.m_cMainWnd.m_bImageCaptureIntent) {
                        SavePhotoIntent(data);
                        return;
                    }
                    try {
                        JPEGData cJPEGData3 = new JPEGData(data, this.m_strFileName);
                        DebugLog.WriteDebug("JPEGData cJPEGData=new JPEGData(data,m_strFileName);");
                        cJPEGData3.m_bFreeVersion = this.m_bFreeVersion;
                        cJPEGData3.m_lDate = System.currentTimeMillis();
                        cJPEGData3.m_bOverlay = this.m_bOverlayDateTime;
                        cJPEGData3.m_szPhoto = this.m_szPhoto;
                        if (this.m_nCameraNum == 1) {
                            cJPEGData3.m_szPhoto = this.m_szPhotoFront;
                        }
                        if (this.m_bUseGPSEXIF) {
                            cJPEGData3.m_cCameraView = this;
                        }
                        this.m_cSaveThread.AddJPEGData(cJPEGData3);
                        DebugLog.WriteDebug("m_cSaveThread.AddJPEGData(cJPEGData);");
                    } catch (Exception ex3) {
                        Log.e("lgCamera", ex3.getMessage());
                        DebugLog.WriteDebug("Jpeg add failed " + ex3.getMessage());
                    }
                    Log.e("CameraView", "JPEGData added");
                    break;
            }
        } else {
            DebugLog.WriteDebug("Jpeg data is null !");
        }
        this.m_bPanoramaTakingPic = false;
        this.m_cMainWnd.onCameraViewAction(13);
        Log.e("CameraView", "m_cMainWnd.onCameraViewAction(PHOTO_CAPTURED);");
        this.m_cMainWnd.runOnUiThread(this.m_cUpdateFilesRunnable);
        DebugLog.WriteDebug("m_cMainWnd.runOnUiThread(m_cUpdateFilesRunnable);");
        Log.e("CameraView", "m_cMainWnd.runOnUiThread(m_cUpdateFilesRunnable);");
    }

    private void SavePhotoIntent(byte[] data) {
        if (this.m_cMainWnd.m_cUriSaveImage != null) {
            try {
                Log.e("lgCamera", "Saving intent photo " + this.m_cMainWnd.m_cUriSaveImage.getEncodedPath());
                OutputStream cStream = this.m_cMainWnd.getContentResolver().openOutputStream(this.m_cMainWnd.m_cUriSaveImage);
                cStream.write(data);
                cStream.close();
                this.m_cMainWnd.setResult(-1);
                this.m_cMainWnd.finish();
                return;
            } catch (Exception ex) {
                Log.e("lgCamera", "Error in saving photo " + ex.getMessage());
                ex.printStackTrace();
                DebugLog.WriteDebug(ex.getMessage());
                return;
            }
        }
        try {
            Log.e("lgCamera", "Saving small intent photo ");
            BitmapFactory.Options cOpt = new BitmapFactory.Options();
            cOpt.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, cOpt);
            cOpt.inSampleSize = Math.max(cOpt.outWidth / 128, cOpt.outHeight / 128);
            cOpt.inJustDecodeBounds = false;
            Bitmap cBmp = BitmapFactory.decodeByteArray(data, 0, data.length, cOpt);
            this.m_cMainWnd.setResult(-1, new Intent("inline-data").putExtra("data", cBmp));
            this.m_cMainWnd.finish();
        } catch (Exception ex2) {
            Log.e("lgCamera", "Error in saving small photo " + ex2.getMessage());
            ex2.printStackTrace();
            DebugLog.WriteDebug(ex2.getMessage());
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper.OnCameraWrapperEventListener
    public void onZoomChange(int zoomValue, boolean stopped) {
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper.OnCameraWrapperEventListener
    public void onFaceDetection(Rect[] rcFace) {
        if (this.m_nCameraNum == 1) {
            for (int n = 0; n < rcFace.length; n++) {
                rcFace[n].left *= -1;
                rcFace[n].right *= -1;
                rcFace[n].sort();
            }
        }
        this.m_cGridView.SetFaces(rcFace);
        try {
            CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(false);
            int nFocusAreasCount = cParams.getMaxNumFocusAreas();
            if (nFocusAreasCount > 0) {
                Rect rcAllFocus = new Rect(-1000, -1000, 1000, 1000);
                for (int n2 = 0; n2 < rcFace.length; n2++) {
                    if (n2 == 0 || rcFace[n2].left < rcAllFocus.left) {
                        rcAllFocus.left = rcFace[n2].left;
                    }
                    if (n2 == 0 || rcFace[n2].top < rcAllFocus.top) {
                        rcAllFocus.top = rcFace[n2].top;
                    }
                    if (n2 == 0 || rcFace[n2].bottom > rcAllFocus.bottom) {
                        rcAllFocus.bottom = rcFace[n2].bottom;
                    }
                    if (n2 == 0 || rcFace[n2].right > rcAllFocus.right) {
                        rcAllFocus.right = rcFace[n2].right;
                    }
                }
                List<Rect> cArList = new Vector<>();
                cArList.add(rcAllFocus);
                cParams.setFocusAreas(cArList);
                this.m_cCameraWrapper.SetParameters(cParams);
            }
        } catch (Exception e) {
        }
    }

    public boolean IsFrontCamera() {
        return this.m_nCameraNum == 1;
    }

    public boolean CanSlowMotion() {
        return this.m_cCameraWrapper.FpsCaptureExist();
    }

    public void ResetManualFocus() {
        this.m_cMainWnd.m_cHandler.removeCallbacks(this.m_cRestoreFM);
        Log.e("lgCamera", "Reset AF, old FM=" + this.m_strFocusMode);
        if (!this.m_strFocusMode.equalsIgnoreCase("")) {
            try {
                this.m_cCameraWrapper.cancelAutoFocus();
                CameraParamWrapper cParams = this.m_cCameraWrapper.GetParameters(true);
                if (this.m_strFocusMode.equalsIgnoreCase("face detection")) {
                    cParams.setFocusMode("continuous-video");
                    this.m_cCameraWrapper.StartFaceDetection();
                } else {
                    cParams.setFocusMode(this.m_strFocusMode);
                }
                cParams.setFocusAreas(null);
                this.m_cCameraWrapper.SetParameters(cParams);
                this.m_cMainWnd.m_cHandler.removeCallbacks(this.m_cRestoreFM);
                Log.e("lgCamera", "Setting focus mode to " + this.m_cCameraWrapper.GetParameters(true).getFocusMode());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        this.m_cMainWnd.onCameraViewAction(18);
    }

    @Override // com.android.camera.PanoramaCollection.PanoramaListener
    public void OnPanoModeChanged(int nNewMode, int nOldMode) {
        Log.e("lgCamera", "Create panorama change mode from " + nOldMode + " to new mode " + nNewMode);
        if (nNewMode != 1) {
            this.m_cMainWnd.m_cTextViewPanoMess.setVisibility(8);
            this.m_cGridView.setDrawPanoramaRect(false, 0);
            this.m_cCameraWrapper.StopPreviewCallback();
            if (nNewMode == 2) {
                this.m_cWaitDlg = new PanoramaWaitDlg(this.m_cMainWnd, this.m_cPanoramaCollection, new PanoramaWaitDlg.WaitDlgListener() { // from class: com.android.camera.CameraView.12
                    @Override // com.android.camera.PanoramaWaitDlg.WaitDlgListener
                    public void OnUserCancel() {
                        CameraView.this.m_cPanoramaCollection.CancelPanorama();
                    }
                });
                this.m_cWaitDlg.show();
            }
        } else {
            this.m_cMainWnd.m_cTextViewPanoMess.setVisibility(0);
            this.m_cMainWnd.m_cTextViewPanoMess.setText(R.string.PanoMess);
            this.m_cGridView.setDrawPanoramaRect(true, this.m_cMainWnd.m_nLastOrientation);
            this.m_cCameraWrapper.StartPreviewCallback();
        }
        this.m_cMainWnd.UpdateButtons();
    }

    @Override // com.android.camera.PanoramaCollection.PanoramaListener
    public void OnPanoramaReady(YuvImage cYUVImage) {
        if (this.m_cWaitDlg != null) {
            this.m_cWaitDlg.CloseDialog();
        }
        this.m_cWaitDlg = null;
        Log.e("lgCamera", "Panorama ready");
        this.m_cCameraWrapper.StopPreviewCallback();
        if (this.m_cMainWnd.m_bImageCaptureIntent) {
            try {
                ByteArrayOutputStream cStream = new ByteArrayOutputStream();
                cYUVImage.compressToJpeg(new Rect(0, 0, cYUVImage.getWidth(), cYUVImage.getHeight()), 100, cStream);
                SavePhotoIntent(cStream.toByteArray());
                cStream.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else {
            String strFileName = getNewFileNameJpeg();
            try {
                FileOutputStream cStream2 = new FileOutputStream(strFileName);
                cYUVImage.compressToJpeg(new Rect(0, 0, cYUVImage.getWidth(), cYUVImage.getHeight()), 100, cStream2);
                cStream2.close();
                IndexingPathInGallery(strFileName);
                Log.e("lgCamera", "Pano Jpeg saved");
            } catch (Exception ex2) {
                ex2.printStackTrace();
            }
        }
        this.m_cMainWnd.UpdateButtons();
    }

    @Override // com.android.camera.PanoramaCollection.PanoramaListener
    public void OnPanoramaCanceled() {
        Log.e("lgCamera", "Create panorama canceled");
        this.m_cCameraWrapper.StopPreviewCallback();
        if (this.m_cWaitDlg != null) {
            this.m_cWaitDlg.CloseDialog();
        }
        this.m_cWaitDlg = null;
        this.m_cMainWnd.UpdateButtons();
    }

    @Override // com.android.camera.PanoramaCollection.PanoramaListener
    public void OnPanoramaError(int nError) {
        Log.e("lgCamera", "Create panorama error " + nError);
        this.m_cCameraWrapper.StopPreviewCallback();
        if (this.m_cWaitDlg != null) {
            this.m_cWaitDlg.CloseDialog();
        }
        this.m_cWaitDlg = null;
        this.m_cMainWnd.UpdateButtons();
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper.OnCameraWrapperEventListener
    public void onPreviewFrame(byte[] data) {
        if (this.m_nPhotoMode == 2 && this.m_cPanoramaCollection.GetMode() == 1) {
            this.m_cPanoramaCollection.onPreviewFrame(data, this.m_fArAngles[0]);
            this.m_cGridView.SetPanoramaAngleProgress(this.m_cPanoramaCollection.getProgressAngle());
        }
    }

    @Override // com.android.camera.PanoramaCollection.PanoramaListener
    public void OnTooFast() {
        this.m_cMainWnd.m_cTextViewPanoMess.setText(R.string.TooFast);
        this.m_cMainWnd.m_cTextViewPanoMess.removeCallbacks(this.m_cRestorePanMess);
        this.m_cMainWnd.m_cTextViewPanoMess.postDelayed(this.m_cRestorePanMess, 1000L);
    }

    public int GetPanoMode() {
        return this.m_cPanoramaCollection.GetMode();
    }

    public void StopPanoramaTaking() {
        this.m_cPanoramaCollection.CreatePanoImmedialety();
    }

    public boolean IsUseSEC() {
        return this.m_bUseSEC;
    }

    public void SetUseSEC(boolean bValue) {
        if (this.m_bUseSEC != bValue) {
            if (bValue && SecCameraWrapper.IsSECSupported()) {
                SecCameraWrapper cSecWrapper = new SecCameraWrapper(this.m_cMainWnd.getApplicationContext(), this);
                if (cSecWrapper.IsSecInitialized()) {
                    StopCamera();
                    this.m_cCameraWrapper = cSecWrapper;
                    InitCamera();
                    if (cSecWrapper.Initialized()) {
                        StartPreview(false);
                        this.m_bUseSEC = true;
                        return;
                    }
                    Toast.makeText(this.m_cMainWnd, (int) R.string.SECError, 1).show();
                    StopCamera();
                    this.m_cCameraWrapper = new CameraWrapper(this.m_cMainWnd.getApplicationContext(), this);
                    InitCamera();
                    StartPreview(false);
                    this.m_bUseSEC = false;
                    return;
                }
                this.m_bUseSEC = false;
                return;
            }
            StopCamera();
            this.m_cCameraWrapper = new CameraWrapper(this.m_cMainWnd.getApplicationContext(), this);
            InitCamera();
            StartPreview(false);
            this.m_bUseSEC = false;
        }
    }

    public boolean IsAGCOff() {
        return this.m_bAGCOff;
    }

    public void SetAGCOff(boolean bValue) {
        this.m_bAGCOff = bValue;
    }
}