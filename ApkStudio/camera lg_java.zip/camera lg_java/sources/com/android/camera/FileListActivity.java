package com.android.camera;

import android.app.AlertDialog;
import android.app.TabActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.SpinnerAdapter;
import android.widget.TabHost;
import android.widget.TextView;
import java.io.File;
import java.io.FilenameFilter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Vector;
import rubberbigpepper.CommonCtrl.DocumentFile;
import rubberbigpepper.CommonCtrl.InvokeHelper;

/* loaded from: classes.dex */
public class FileListActivity extends TabActivity implements Comparator<File>, AdapterView.OnItemClickListener, AdapterView.OnItemSelectedListener, TabHost.OnTabChangeListener {
    private static final int MENU_DELETE = 3;
    private static final int MENU_DELETEALL = 4;
    private static final int MENU_VIEW = 1;
    private ImageAdapter m_cAdapterPhoto = null;
    private VideoAdapter m_cAdapterVideo = null;
    private TextView m_cTextViewNumber = null;
    private TextView m_cTextViewFile = null;
    private TextView m_cTextViewDate = null;
    private Gallery m_cPhotoGallery = null;
    private Gallery m_cVideoGallery = null;
    private UpdateImageViewThread m_cUpdateImageThread = null;

    @Override // android.app.ActivityGroup, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Resources cRes = getResources();
        TabHost tabHost = getTabHost();
        LayoutInflater.from(this).inflate(R.layout.filelist, (ViewGroup) tabHost.getTabContentView(), true);
        tabHost.addTab(tabHost.newTabSpec("Photo").setIndicator(cRes.getString(R.string.Photo), getResources().getDrawable(R.drawable.photo)).setContent(R.id.GalleryPhoto));
        tabHost.addTab(tabHost.newTabSpec("Video").setIndicator(cRes.getString(R.string.Video), getResources().getDrawable(R.drawable.video)).setContent(R.id.GalleryVideo));
        tabHost.setOnTabChangedListener(this);
        this.m_cTextViewNumber = (TextView) findViewById(R.id.TextViewFileNumber);
        this.m_cTextViewFile = (TextView) findViewById(R.id.TextViewFile);
        this.m_cTextViewDate = (TextView) findViewById(R.id.TextViewDate);
        this.m_cVideoGallery = (Gallery) findViewById(R.id.GalleryVideo);
        this.m_cAdapterVideo = new VideoAdapter(this, CameraView.getFolder());
        this.m_cVideoGallery.setAdapter((SpinnerAdapter) this.m_cAdapterVideo);
        this.m_cVideoGallery.setOnItemClickListener(this);
        this.m_cVideoGallery.setOnItemSelectedListener(this);
        registerForContextMenu(this.m_cVideoGallery);
        this.m_cPhotoGallery = (Gallery) findViewById(R.id.GalleryPhoto);
        this.m_cAdapterPhoto = new ImageAdapter(this, CameraView.getFolder());
        this.m_cPhotoGallery.setAdapter((SpinnerAdapter) this.m_cAdapterPhoto);
        this.m_cPhotoGallery.setOnItemClickListener(this);
        this.m_cPhotoGallery.setOnItemSelectedListener(this);
        registerForContextMenu(this.m_cPhotoGallery);
        this.m_cAdapterPhoto.notifyDataSetChanged();
        UpdateViews();
    }

    @Override // java.util.Comparator
    public int compare(File object1, File object2) {
        CListItem cItem1 = new CListItem(object1.getAbsolutePath());
        CListItem cItem2 = new CListItem(object2.getAbsolutePath());
        return cItem1.getTitle().compareToIgnoreCase(cItem2.getTitle());
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
        if (arg0.getAdapter().equals(this.m_cAdapterPhoto)) {
            try {
                File cFile = (File) this.m_cAdapterPhoto.getItem(arg2);
                Intent cIntent = new Intent();
                cIntent.setAction("android.intent.action.VIEW");
                cIntent.setDataAndType(Uri.fromFile(cFile), "image/*");
                startActivity(cIntent);
            } catch (Exception e) {
            }
        }
        if (arg0.getAdapter().equals(this.m_cAdapterVideo)) {
            try {
                File cFile2 = (File) this.m_cAdapterVideo.getItem(arg2);
                Intent cIntent2 = new Intent();
                cIntent2.setAction("android.intent.action.VIEW");
                cIntent2.setDataAndType(Uri.fromFile(cFile2), "video/*");
                startActivity(cIntent2);
            } catch (Exception e2) {
            }
        }
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
        UpdateViews();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void UpdateViews() {
        if (getTabHost().getCurrentTab() == 0) {
            try {
                if (this.m_cPhotoGallery.getCount() == 0) {
                    this.m_cTextViewNumber.setText(String.format("%s 0/0", getResources().getString(R.string.LabelFile)));
                    this.m_cTextViewFile.setText("");
                    this.m_cTextViewDate.setText("");
                } else {
                    int nItem = this.m_cPhotoGallery.getSelectedItemPosition();
                    File cFile = (File) this.m_cAdapterPhoto.getItem(nItem);
                    CListItem cItem = new CListItem(cFile.getAbsolutePath());
                    this.m_cTextViewNumber.setText(String.format("%s %d/%d", getResources().getString(R.string.LabelFile), Integer.valueOf(nItem + 1), Integer.valueOf(this.m_cAdapterPhoto.getCount())));
                    this.m_cTextViewFile.setText(cFile.getAbsolutePath());
                    this.m_cTextViewDate.setText(cItem.getTitle());
                }
            } catch (Exception e) {
            }
        }
        if (getTabHost().getCurrentTab() == 1) {
            try {
                if (this.m_cVideoGallery.getCount() == 0) {
                    this.m_cTextViewNumber.setText(String.format("%s 0/0", getResources().getString(R.string.LabelFile)));
                    this.m_cTextViewFile.setText("");
                    this.m_cTextViewDate.setText("");
                } else {
                    int nItem2 = this.m_cVideoGallery.getSelectedItemPosition();
                    File cFile2 = (File) this.m_cAdapterVideo.getItem(nItem2);
                    CListItem cItem2 = new CListItem(cFile2.getAbsolutePath());
                    this.m_cTextViewNumber.setText(String.format("%s %d/%d", getResources().getString(R.string.LabelFile), Integer.valueOf(nItem2 + 1), Integer.valueOf(this.m_cAdapterVideo.getCount())));
                    this.m_cTextViewFile.setText(cFile2.getAbsolutePath());
                    this.m_cTextViewDate.setText(cItem2.getTitle());
                }
            } catch (Exception e2) {
            }
        }
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onNothingSelected(AdapterView<?> arg0) {
    }

    @Override // android.app.ActivityGroup, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        if (isFinishing() && this.m_cUpdateImageThread != null) {
            this.m_cUpdateImageThread.setRun(false);
            try {
                this.m_cUpdateImageThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    @Override // android.app.Activity, android.view.View.OnCreateContextMenuListener
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        int nGroup = getTabHost().getCurrentTab();
        if (nGroup == 0) {
            menu.add(0, 1, 0, R.string.ContextMenuView).setOnMenuItemClickListener(new PlayMenuClickListener(nGroup, this.m_cPhotoGallery.getSelectedItemPosition()));
            menu.add(0, 3, 0, R.string.ContextMenuDelete).setOnMenuItemClickListener(new DeleteMenuClickListener(nGroup, this.m_cPhotoGallery.getSelectedItemPosition()));
            menu.add(0, 4, 0, R.string.ContextMenuDeleteAll).setOnMenuItemClickListener(new DeleteAllMenuClickListener(nGroup));
            return;
        }
        menu.add(0, 1, 0, R.string.ContextMenuView).setOnMenuItemClickListener(new PlayMenuClickListener(nGroup, this.m_cVideoGallery.getSelectedItemPosition()));
        menu.add(0, 3, 0, R.string.ContextMenuDelete).setOnMenuItemClickListener(new DeleteMenuClickListener(nGroup, this.m_cVideoGallery.getSelectedItemPosition()));
        menu.add(0, 4, 0, R.string.ContextMenuDeleteAll).setOnMenuItemClickListener(new DeleteAllMenuClickListener(nGroup));
    }

    /* loaded from: classes.dex */
    private class PlayMenuClickListener implements MenuItem.OnMenuItemClickListener {
        private int m_nChild;
        private int m_nGroup;

        public PlayMenuClickListener(int nGroup, int nChild) {
            this.m_nGroup = nGroup;
            this.m_nChild = nChild;
        }

        @Override // android.view.MenuItem.OnMenuItemClickListener
        public boolean onMenuItemClick(MenuItem item) {
            try {
                Intent cIntent = new Intent();
                cIntent.setAction("android.intent.action.VIEW");
                if (this.m_nGroup == 0) {
                    File cFile = (File) FileListActivity.this.m_cAdapterPhoto.getItem(this.m_nChild);
                    cIntent.setDataAndType(Uri.fromFile(cFile), "image/*");
                } else {
                    File cFile2 = (File) FileListActivity.this.m_cAdapterVideo.getItem(this.m_nChild);
                    cIntent.setDataAndType(Uri.fromFile(cFile2), "video/*");
                }
                FileListActivity.this.startActivity(cIntent);
            } catch (Exception e) {
            }
            return true;
        }
    }

    /* loaded from: classes.dex */
    private class DeleteMenuClickListener implements MenuItem.OnMenuItemClickListener {
        private int m_nChild;
        private int m_nGroup;

        public DeleteMenuClickListener(int nGroup, int nChild) {
            this.m_nGroup = nGroup;
            this.m_nChild = nChild;
        }

        @Override // android.view.MenuItem.OnMenuItemClickListener
        public boolean onMenuItemClick(MenuItem item) {
            try {
                if (this.m_nGroup == 0) {
                    File cFile = (File) FileListActivity.this.m_cAdapterPhoto.getItem(this.m_nChild);
                    DocumentFile.Delete(cFile, FileListActivity.this.getApplicationContext(), CameraView.m_treeUri);
                    FileListActivity.this.m_cAdapterPhoto.RemoveAt(this.m_nChild);
                    FileListActivity.this.m_cAdapterPhoto.notifyDataSetChanged();
                } else {
                    File cFile2 = (File) FileListActivity.this.m_cAdapterVideo.getItem(this.m_nChild);
                    DocumentFile.Delete(cFile2, FileListActivity.this.getApplicationContext(), CameraView.m_treeUri);
                    FileListActivity.this.m_cAdapterVideo.RemoveAt(this.m_nChild);
                    FileListActivity.this.m_cAdapterVideo.notifyDataSetChanged();
                }
                FileListActivity.this.UpdateViews();
                return true;
            } catch (Exception e) {
                return true;
            }
        }
    }

    /* loaded from: classes.dex */
    private class DeleteAllMenuClickListener implements MenuItem.OnMenuItemClickListener {
        private int m_nGroup;

        public DeleteAllMenuClickListener(int nGroup) {
            this.m_nGroup = nGroup;
        }

        @Override // android.view.MenuItem.OnMenuItemClickListener
        public boolean onMenuItemClick(MenuItem item) {
            AlertDialog.Builder cBuilder = new AlertDialog.Builder(FileListActivity.this);
            cBuilder.setTitle(R.string.ContextMenuDeleteAll);
            cBuilder.setMessage(R.string.RemoveAllDlgMessage);
            cBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() { // from class: com.android.camera.FileListActivity.DeleteAllMenuClickListener.1
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface arg0, int arg1) {
                    try {
                        if (DeleteAllMenuClickListener.this.m_nGroup == 0) {
                            while (FileListActivity.this.m_cAdapterPhoto.getCount() > 0) {
                                File cFile = (File) FileListActivity.this.m_cAdapterPhoto.getItem(0);
                                DocumentFile.Delete(cFile, FileListActivity.this.getApplicationContext(), CameraView.m_treeUri);
                                FileListActivity.this.m_cAdapterPhoto.RemoveAt(0);
                            }
                        } else {
                            while (FileListActivity.this.m_cAdapterVideo.getCount() > 0) {
                                File cFile2 = (File) FileListActivity.this.m_cAdapterVideo.getItem(0);
                                DocumentFile.Delete(cFile2, FileListActivity.this.getApplicationContext(), CameraView.m_treeUri);
                                FileListActivity.this.m_cAdapterVideo.RemoveAt(0);
                            }
                        }
                        if (DeleteAllMenuClickListener.this.m_nGroup == 0) {
                            FileListActivity.this.m_cAdapterPhoto.notifyDataSetChanged();
                        } else {
                            FileListActivity.this.m_cAdapterVideo.notifyDataSetChanged();
                        }
                        FileListActivity.this.UpdateViews();
                    } catch (Exception e) {
                    }
                }
            });
            cBuilder.setNegativeButton(R.string.DlgCancel, new DialogInterface.OnClickListener() { // from class: com.android.camera.FileListActivity.DeleteAllMenuClickListener.2
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface arg0, int arg1) {
                }
            });
            cBuilder.create().show();
            return true;
        }
    }

    /* loaded from: classes.dex */
    public class VideoAdapter extends BaseAdapter implements FilenameFilter {
        private Context mContext;
        private Class<?> m_cMediaRetreiverClass;
        private int mGalleryItemBackground = Color.rgb(0, 0, 0);
        private Vector<File> m_cArImages = new Vector<>();
        private Vector<ImageView> m_cArImageView = new Vector<>();

        public VideoAdapter(Context c, String strFolder) {
            this.m_cMediaRetreiverClass = null;
            this.mContext = c;
            try {
                File cDir = new File(strFolder);
                File[] cArImages = cDir.listFiles(this);
                Arrays.sort(cArImages, FileListActivity.this);
                for (int n = cArImages.length - 1; n >= 0; n--) {
                    this.m_cArImages.add(cArImages[n]);
                    this.m_cArImageView.add(null);
                }
                this.m_cMediaRetreiverClass = Class.forName("android.media.MediaMetadataRetriever");
            } catch (Exception e) {
            }
        }

        @Override // android.widget.Adapter
        public int getCount() {
            if (this.m_cArImages == null) {
                return 0;
            }
            return this.m_cArImages.size();
        }

        @Override // android.widget.Adapter
        public Object getItem(int position) {
            if (this.m_cArImages == null) {
                return null;
            }
            return this.m_cArImages.get(position);
        }

        @Override // android.widget.Adapter
        public long getItemId(int position) {
            return position;
        }

        public void RemoveAt(int nPos) {
            if (nPos >= 0 && nPos < this.m_cArImages.size()) {
                this.m_cArImages.remove(nPos);
            }
        }

        @Override // android.widget.Adapter
        public View getView(int position, View convertView, ViewGroup parent) {
            if (this.m_cArImageView.get(position) != null) {
                return this.m_cArImageView.get(position);
            }
            ImageView i = new ImageView(this.mContext);
            int nWidth = FileListActivity.this.m_cPhotoGallery.getHeight();
            int nHeight = FileListActivity.this.m_cPhotoGallery.getHeight();
            boolean bRetrieve = false;
            if (this.m_cMediaRetreiverClass != null) {
                try {
                    Object oMediaMetadataRetriever = this.m_cMediaRetreiverClass.newInstance();
                    InvokeHelper.InvokeMethod(oMediaMetadataRetriever, "setMode", 2);
                    InvokeHelper.InvokeMethod(oMediaMetadataRetriever, "setDataSource", this.m_cArImages.get(position).getAbsolutePath());
                    Object oBmp = InvokeHelper.InvokeMethod(oMediaMetadataRetriever, "captureFrame");
                    Object oBmp2 = oBmp;
                    if (oBmp == null) {
                        oBmp2 = InvokeHelper.InvokeMethod(oMediaMetadataRetriever, "getFrameAtTime");
                    }
                    Bitmap cBmp = (Bitmap) oBmp2;
                    InvokeHelper.InvokeMethod(oMediaMetadataRetriever, "release");
                    i.setImageBitmap(cBmp);
                    nWidth = (cBmp.getWidth() * nHeight) / cBmp.getHeight();
                    bRetrieve = true;
                } catch (Exception ex) {
                    Log.e("lgCamera", "FileListActivity error in getView video " + ex.getMessage());
                }
            }
            if (!bRetrieve) {
                try {
                    BitmapFactory.Options cOption = new BitmapFactory.Options();
                    cOption.inSampleSize = 16;
                    Bitmap cBitmap = BitmapFactory.decodeResource(FileListActivity.this.getResources(), R.drawable.videofile);
                    i.setImageBitmap(cBitmap);
                    nWidth = (cBitmap.getWidth() * nHeight) / cBitmap.getHeight();
                } catch (Exception e) {
                }
            }
            i.setScaleType(ImageView.ScaleType.FIT_XY);
            i.setLayoutParams(new Gallery.LayoutParams(nWidth, nHeight));
            i.setBackgroundColor(this.mGalleryItemBackground);
            return i;
        }

        @Override // java.io.FilenameFilter
        public boolean accept(File dir, String filename) {
            int nPos = filename.lastIndexOf(46);
            if (nPos != -1) {
                String strExt = filename.substring(nPos + 1).toLowerCase();
                if (strExt.equals("3gp") || strExt.equals("mp4")) {
                    return true;
                }
            }
            return false;
        }
    }

    /* loaded from: classes.dex */
    public class ImageAdapter extends BaseAdapter implements FilenameFilter {
        private Context mContext;
        private Vector<File> m_cArImages = new Vector<>();
        private Vector<ImageView> m_cArImageView = new Vector<>();

        public ImageAdapter(Context c, String strFolder) {
            this.mContext = c;
            try {
                File cDir = new File(strFolder);
                File[] cArImages = cDir.listFiles(this);
                Arrays.sort(cArImages, FileListActivity.this);
                for (int n = cArImages.length - 1; n >= 0; n--) {
                    this.m_cArImages.add(cArImages[n]);
                    this.m_cArImageView.add(null);
                }
            } catch (Exception e) {
            }
        }

        @Override // android.widget.Adapter
        public int getCount() {
            if (this.m_cArImages == null) {
                return 0;
            }
            return this.m_cArImages.size();
        }

        @Override // android.widget.Adapter
        public Object getItem(int position) {
            if (this.m_cArImages == null) {
                return null;
            }
            return this.m_cArImages.get(position);
        }

        @Override // android.widget.Adapter
        public long getItemId(int position) {
            return position;
        }

        public void RemoveAt(int nPos) {
            if (nPos >= 0 && nPos < this.m_cArImages.size()) {
                this.m_cArImages.remove(nPos);
                this.m_cArImageView.remove(nPos);
            }
        }

        @Override // android.widget.Adapter
        public View getView(int position, View convertView, ViewGroup parent) {
            if (this.m_cArImageView.get(position) != null) {
                return this.m_cArImageView.get(position);
            }
            ImageView i = new ImageView(this.mContext);
            int nWidth = FileListActivity.this.m_cPhotoGallery.getHeight();
            int nHeight = FileListActivity.this.m_cPhotoGallery.getHeight();
            if (FileListActivity.this.m_cUpdateImageThread == null) {
                FileListActivity.this.m_cUpdateImageThread = new UpdateImageViewThread(FileListActivity.this, null);
                FileListActivity.this.m_cUpdateImageThread.start();
            }
            FileListActivity.this.m_cUpdateImageThread.AddFile(i, this.m_cArImages.get(position));
            i.setScaleType(ImageView.ScaleType.FIT_XY);
            i.setLayoutParams(new Gallery.LayoutParams(nWidth, nHeight));
            i.setBackgroundResource(R.drawable.photofile);
            this.m_cArImageView.set(position, i);
            return i;
        }

        @Override // java.io.FilenameFilter
        public boolean accept(File dir, String filename) {
            int nPos = filename.lastIndexOf(46);
            if (nPos != -1) {
                String strExt = filename.substring(nPos + 1).toLowerCase();
                if (strExt.equals("jpg") || strExt.equals("png")) {
                    return true;
                }
            }
            return false;
        }
    }

    @Override // android.widget.TabHost.OnTabChangeListener
    public void onTabChanged(String tabId) {
        UpdateViews();
    }

    /* loaded from: classes.dex */
    private class UpdateImageViewThread extends Thread {
        private boolean m_bRun;
        private Vector<File> m_cArFiles;
        private Vector<ImageView> m_cArImageView;
        private Bitmap m_cDecodedBmp;
        private Runnable m_cImageViewUpdate;

        private UpdateImageViewThread() {
            this.m_bRun = true;
            this.m_cArImageView = new Vector<>();
            this.m_cArFiles = new Vector<>();
            this.m_cDecodedBmp = null;
            this.m_cImageViewUpdate = new Runnable() { // from class: com.android.camera.FileListActivity.UpdateImageViewThread.1
                @Override // java.lang.Runnable
                public void run() {
                    if (UpdateImageViewThread.this.m_cArImageView.size() > 0 && UpdateImageViewThread.this.m_cArFiles.size() > 0 && UpdateImageViewThread.this.m_cDecodedBmp != null) {
                        FileListActivity.this.m_cPhotoGallery.getHeight();
                        int nHeight = FileListActivity.this.m_cPhotoGallery.getHeight();
                        ImageView cImageView = (ImageView) UpdateImageViewThread.this.m_cArImageView.get(0);
                        cImageView.setImageBitmap(UpdateImageViewThread.this.m_cDecodedBmp);
                        int nWidth = (UpdateImageViewThread.this.m_cDecodedBmp.getWidth() * nHeight) / UpdateImageViewThread.this.m_cDecodedBmp.getHeight();
                        cImageView.setLayoutParams(new Gallery.LayoutParams(nWidth, nHeight));
                        UpdateImageViewThread.this.m_cArImageView.remove(0);
                        UpdateImageViewThread.this.m_cArFiles.remove(0);
                        UpdateImageViewThread.this.m_cDecodedBmp = null;
                    }
                }
            };
        }

        /* synthetic */ UpdateImageViewThread(FileListActivity fileListActivity, UpdateImageViewThread updateImageViewThread) {
            this();
        }

        public void AddFile(ImageView cImageView, File cFile) {
            this.m_cArImageView.add(cImageView);
            this.m_cArFiles.add(cFile);
        }

        public void setRun(boolean bRun) {
            this.m_bRun = bRun;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            BitmapFactory.Options cOption = new BitmapFactory.Options();
            cOption.inSampleSize = 32;
            while (this.m_bRun) {
                if (this.m_cArImageView.size() > 0 && this.m_cDecodedBmp == null) {
                    try {
                        this.m_cDecodedBmp = BitmapFactory.decodeFile(this.m_cArFiles.get(0).getAbsolutePath(), cOption);
                    } catch (Exception e) {
                    }
                    FileListActivity.this.runOnUiThread(this.m_cImageViewUpdate);
                } else {
                    try {
                        sleep(10L);
                    } catch (Exception e2) {
                    }
                }
            }
        }
    }
}