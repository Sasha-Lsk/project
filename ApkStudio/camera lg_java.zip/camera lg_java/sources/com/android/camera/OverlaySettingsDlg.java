package com.android.camera;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import com.android.camera.RGBColorPickerDialog;
import java.util.Vector;

/* loaded from: classes.dex */
public class OverlaySettingsDlg extends Dialog implements View.OnClickListener {
    private CameraView m_cCameraView;
    private CheckBox m_cCheckBox12HourTimeFormat;
    private CheckBox m_cCheckBoxAddGPSLocation;
    private Spinner m_cComboDateFormat;
    private EditText m_cEditTextAdditional;
    private ImageView m_cFontColor;
    private Spinner m_cFontName;
    private Spinner m_cFontSize;
    private Spinner m_cGravity;
    private OverlaySettingsListener m_cListener;
    private int m_nColorFont;
    private Vector<String> m_strArFonts;

    /* loaded from: classes.dex */
    public interface OverlaySettingsListener {
        void onCancel();

        void onOK();
    }

    public OverlaySettingsDlg(Context context, CameraView cCameraView, OverlaySettingsListener overlaySettingsListener) {
        super(context);
        this.m_cCameraView = null;
        this.m_nColorFont = 0;
        this.m_strArFonts = new Vector<>();
        this.m_cListener = null;
        this.m_cListener = overlaySettingsListener;
        this.m_cCameraView = cCameraView;
    }

    @Override // android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.LabelAddOverlayDateTime);
        setContentView(R.layout.overlaysettings);
        this.m_cGravity = (Spinner) findViewById(R.id.SpinnerGravity);
        this.m_cFontSize = (Spinner) findViewById(R.id.SpinnerFontSize);
        this.m_cFontName = (Spinner) findViewById(R.id.SpinnerFontName);
        this.m_cFontColor = (ImageView) findViewById(R.id.ImageViewFontColor);
        this.m_cEditTextAdditional = (EditText) findViewById(R.id.EditTextAdditional);
        this.m_cCheckBoxAddGPSLocation = (CheckBox) findViewById(R.id.CheckBoxAddLocation);
        this.m_cComboDateFormat = (Spinner) findViewById(R.id.SpinnerDateFormat);
        this.m_cCheckBox12HourTimeFormat = (CheckBox) findViewById(R.id.CheckBox12HourTimeFormat);
        this.m_cComboDateFormat.setSelection(this.m_cCameraView.m_nOverlayDateTimeFormat);
        this.m_cGravity.setSelection(this.m_cCameraView.m_nOverlayGravity);
        this.m_cFontSize.setSelection((this.m_cCameraView.m_nOverlayFontSize / 10) - 1);
        this.m_cEditTextAdditional.setText(this.m_cCameraView.m_strOverlayAddText);
        this.m_cCheckBoxAddGPSLocation.setChecked(this.m_cCameraView.m_bOverlayGPS);
        this.m_cCheckBox12HourTimeFormat.setChecked(this.m_cCameraView.m_bOverlay12HourFormat);
        this.m_cFontColor.setBackgroundColor(this.m_cCameraView.m_nOverlayColor);
        this.m_nColorFont = this.m_cCameraView.m_nOverlayColor;
        this.m_cFontColor.setOnClickListener(this);
        findViewById(R.id.buttonOK).setOnClickListener(this);
        findViewById(R.id.buttonCancel).setOnClickListener(this);
        this.m_strArFonts.add("normal");
        this.m_strArFonts.add("sans");
        this.m_strArFonts.add("serif");
        this.m_strArFonts.add("monospace");
        int nItemSel = 0;
        int n = 0;
        while (true) {
            if (n >= this.m_strArFonts.size()) {
                break;
            }
            String strFont = this.m_strArFonts.get(n);
            if (!strFont.equalsIgnoreCase(this.m_cCameraView.m_strOverlayFont)) {
                n++;
            } else {
                nItemSel = n;
                break;
            }
        }
        this.m_cFontName.setSelection(nItemSel);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View arg0) {
        switch (arg0.getId()) {
            case R.id.buttonOK /* 2131230778 */:
                if (this.m_cListener != null) {
                    this.m_cCameraView.m_strOverlayFont = this.m_cFontName.getSelectedItem().toString();
                    this.m_cCameraView.m_nOverlayColor = this.m_nColorFont;
                    this.m_cCameraView.m_bOverlay12HourFormat = this.m_cCheckBox12HourTimeFormat.isChecked();
                    this.m_cCameraView.m_bOverlayGPS = this.m_cCheckBoxAddGPSLocation.isChecked();
                    this.m_cCameraView.m_strOverlayAddText = this.m_cEditTextAdditional.getText().toString();
                    this.m_cCameraView.m_nOverlayFontSize = (this.m_cFontSize.getSelectedItemPosition() + 1) * 10;
                    this.m_cCameraView.m_nOverlayGravity = this.m_cGravity.getSelectedItemPosition();
                    this.m_cCameraView.m_nOverlayDateTimeFormat = this.m_cComboDateFormat.getSelectedItemPosition();
                    this.m_cListener.onOK();
                }
                dismiss();
                return;
            case R.id.buttonCancel /* 2131230779 */:
                if (this.m_cListener != null) {
                    this.m_cListener.onCancel();
                }
                dismiss();
                return;
            case R.id.ImageViewFontColor /* 2131230846 */:
                RGBColorPickerDialog cDlg = new RGBColorPickerDialog(getContext(), new RGBColorPickerDialog.OnColorChangedListener() { // from class: com.android.camera.OverlaySettingsDlg.1
                    @Override // com.android.camera.RGBColorPickerDialog.OnColorChangedListener
                    public void colorChanged(int color) {
                        OverlaySettingsDlg.this.m_nColorFont = color;
                        OverlaySettingsDlg.this.m_cFontColor.setBackgroundColor(OverlaySettingsDlg.this.m_nColorFont);
                    }
                }, this.m_nColorFont);
                cDlg.show();
                return;
            default:
                return;
        }
    }
}