package com.android.camera;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import com.android.camera.ColorPickerDialog;

/* loaded from: classes.dex */
public class RGBColorPickerDialog extends Dialog implements SeekBar.OnSeekBarChangeListener, View.OnClickListener {
    private int mInitialColor;
    private OnColorChangedListener mListener;
    private View m_cSampleView;
    private SeekBar m_cSeekBarBlue;
    private SeekBar m_cSeekBarGreen;
    private SeekBar m_cSeekBarRed;

    /* loaded from: classes.dex */
    public interface OnColorChangedListener {
        void colorChanged(int i);
    }

    public RGBColorPickerDialog(Context context, OnColorChangedListener cListener, int nInitColor) {
        super(context);
        this.mListener = cListener;
        this.mInitialColor = nInitColor;
    }

    @Override // android.app.Dialog
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.PickColor);
        setContentView(R.layout.color_picker);
        this.m_cSeekBarRed = (SeekBar) findViewById(R.id.SeekBarRed);
        this.m_cSeekBarGreen = (SeekBar) findViewById(R.id.SeekBarGreen);
        this.m_cSeekBarBlue = (SeekBar) findViewById(R.id.SeekBarBlue);
        this.m_cSampleView = findViewById(R.id.LinearLayoutSample);
        this.m_cSampleView.setBackgroundColor(this.mInitialColor);
        this.m_cSeekBarRed.setProgress(Color.red(this.mInitialColor));
        this.m_cSeekBarGreen.setProgress(Color.green(this.mInitialColor));
        this.m_cSeekBarBlue.setProgress(Color.blue(this.mInitialColor));
        this.m_cSeekBarRed.setOnSeekBarChangeListener(this);
        this.m_cSeekBarGreen.setOnSeekBarChangeListener(this);
        this.m_cSeekBarBlue.setOnSeekBarChangeListener(this);
        this.m_cSampleView.setOnClickListener(this);
        findViewById(R.id.ButtonApply).setOnClickListener(this);
        findViewById(R.id.ButtonCancel).setOnClickListener(this);
        findViewById(R.id.ButtonSelectColor).setOnClickListener(this);
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        if (fromUser) {
            this.mInitialColor = Color.rgb(this.m_cSeekBarRed.getProgress(), this.m_cSeekBarGreen.getProgress(), this.m_cSeekBarBlue.getProgress());
            this.m_cSampleView.setBackgroundColor(this.mInitialColor);
        }
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public void onStopTrackingTouch(SeekBar seekBar) {
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View arg0) {
        switch (arg0.getId()) {
            case R.id.LinearLayoutSample /* 2131230772 */:
            case R.id.ButtonApply /* 2131230775 */:
                this.mListener.colorChanged(this.mInitialColor);
                dismiss();
                return;
            case R.id.LinearLayout02 /* 2131230773 */:
            default:
                return;
            case R.id.ButtonSelectColor /* 2131230774 */:
                ColorPickerDialog cDlg = new ColorPickerDialog(getContext(), new ColorPickerDialog.OnColorChangedListener() { // from class: com.android.camera.RGBColorPickerDialog.1
                    @Override // com.android.camera.ColorPickerDialog.OnColorChangedListener
                    public void colorChanged(int color) {
                        RGBColorPickerDialog.this.mInitialColor = color;
                        RGBColorPickerDialog.this.m_cSeekBarRed.setProgress(Color.red(RGBColorPickerDialog.this.mInitialColor));
                        RGBColorPickerDialog.this.m_cSeekBarGreen.setProgress(Color.green(RGBColorPickerDialog.this.mInitialColor));
                        RGBColorPickerDialog.this.m_cSeekBarBlue.setProgress(Color.blue(RGBColorPickerDialog.this.mInitialColor));
                        RGBColorPickerDialog.this.m_cSampleView.setBackgroundColor(RGBColorPickerDialog.this.mInitialColor);
                    }
                }, this.mInitialColor);
                cDlg.show();
                return;
            case R.id.ButtonCancel /* 2131230776 */:
                dismiss();
                return;
        }
    }
}