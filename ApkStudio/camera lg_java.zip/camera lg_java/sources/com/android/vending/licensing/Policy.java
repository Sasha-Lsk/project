package com.android.vending.licensing;

/* loaded from: classes.dex */
public interface Policy {

    /* loaded from: classes.dex */
    public enum LicenseResponse {
        LICENSED,
        NOT_LICENSED,
        RETRY;

        /* renamed from: values  reason: to resolve conflict with enum method */
        public static LicenseResponse[] valuesCustom() {
            LicenseResponse[] valuesCustom = values();
            int length = valuesCustom.length;
            LicenseResponse[] licenseResponseArr = new LicenseResponse[length];
            System.arraycopy(valuesCustom, 0, licenseResponseArr, 0, length);
            return licenseResponseArr;
        }
    }

    boolean allowAccess();

    void processServerResponse(LicenseResponse licenseResponse, ResponseData responseData);
}