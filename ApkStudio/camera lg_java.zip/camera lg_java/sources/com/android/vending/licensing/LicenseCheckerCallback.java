package com.android.vending.licensing;

/* loaded from: classes.dex */
public interface LicenseCheckerCallback {

    /* loaded from: classes.dex */
    public enum ApplicationErrorCode {
        INVALID_PACKAGE_NAME,
        NON_MATCHING_UID,
        NOT_MARKET_MANAGED,
        CHECK_IN_PROGRESS,
        INVALID_PUBLIC_KEY,
        MISSING_PERMISSION;

        /* renamed from: values  reason: to resolve conflict with enum method */
        public static ApplicationErrorCode[] valuesCustom() {
            ApplicationErrorCode[] valuesCustom = values();
            int length = valuesCustom.length;
            ApplicationErrorCode[] applicationErrorCodeArr = new ApplicationErrorCode[length];
            System.arraycopy(valuesCustom, 0, applicationErrorCodeArr, 0, length);
            return applicationErrorCodeArr;
        }
    }

    void allow();

    void applicationError(ApplicationErrorCode applicationErrorCode);

    void dontAllow();
}