package rubberbigpepper.CommonCtrl;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.WindowManager;
import com.android.camera.R;
import java.util.Vector;

/* loaded from: classes.dex */
public class CGridView extends View implements ScaleGestureDetector.OnScaleGestureListener {
    private int mHeight;
    private int mWidth;
    private boolean m_bDrawPanoramaRect;
    private boolean m_bOneTapGesture;
    private boolean m_bShowCross;
    private boolean m_bShowGrid;
    private boolean m_bSparkle;
    private boolean m_bWasSparkle;
    private Paint m_cCrossHorzPaint;
    private Paint m_cCrossVertPaint;
    private Drawable m_cDrawFocus;
    private Drawable m_cDrawFocusError;
    private Drawable m_cDrawFocusSuccess;
    private Handler m_cFocusHandler;
    private Runnable m_cInvalidate;
    private GridViewListener m_cListener;
    private Paint m_cPaintDash;
    private Paint m_cPaintFace;
    private Paint m_cPaintPano;
    private Paint m_cPaintPanoRect;
    private Paint m_cPaintPanoSpend;
    private Path m_cPathPano;
    private Path m_cPathPanoSpend;
    private Runnable m_cRunHideSparkle;
    private ScaleGestureDetector m_cScaleDetector;
    private Paint m_cShadowPaint;
    private Paint m_cWhitePaint;
    private float m_dDelta;
    private float m_dHeight;
    private float m_dL;
    private float m_dR;
    private double m_fAcceleration;
    private float m_fAngle;
    private float[] m_fArAccel;
    private float[] m_fArAngles;
    private float[] m_fArCoords;
    private float[] m_fArCoordsDst;
    private float[] m_fArG;
    private float m_fFocusRectHeight;
    private float m_fFocusRectWidth;
    private float m_fX0;
    private float m_fY0;
    private OnZeroAccelValue m_iOnZeroAccel;
    private int m_nDensity;
    private int m_nOrientation;
    private int m_nShowFocus;
    private PointF m_ptDownPoint;
    private Point m_ptFocus;
    private Vector<Rect> m_rcArFaces;
    private RectF m_rcOval;
    private RectF m_rcOvalPano;

    /* loaded from: classes.dex */
    public interface GridViewListener {
        void OnLongClick();

        void OnScale(float f);

        void OnSwipeBottomToTop();

        void OnSwipeLeftToRight();

        void OnSwipeRightToLeft();

        void OnSwipeTopToBottom();

        void OnTap(float f, float f2);
    }

    /* loaded from: classes.dex */
    public interface OnZeroAccelValue {
        void onZeroAccel();
    }

    public void SetListener(GridViewListener cListener) {
        this.m_cListener = cListener;
    }

    public void setDrawPanoramaRect(boolean bValue, int nOrientation) {
        this.m_bDrawPanoramaRect = bValue;
        this.m_nOrientation = nOrientation;
        Redraw();
    }

    private void Init(Context cContext) {
        this.m_cWhitePaint.setColor(Color.argb(160, 255, 255, 255));
        this.m_cWhitePaint.setStrokeWidth(1.0f);
        this.m_cShadowPaint.setColor(Color.argb(82, 0, 0, 0));
        this.m_cShadowPaint.setStrokeWidth(1.0f);
        this.m_cPaintDash.setStrokeWidth(1.0f);
        this.m_cPaintFace.setColor(Color.argb(160, 255, 255, 0));
        this.m_cPaintFace.setStrokeWidth(3.0f);
        this.m_cPaintFace.setStyle(Paint.Style.STROKE);
        DashPathEffect cEffect = new DashPathEffect(new float[]{10.0f, 10.0f}, 0.0f);
        WindowManager cWM = (WindowManager) cContext.getSystemService("window");
        DisplayMetrics outMetrics = new DisplayMetrics();
        cWM.getDefaultDisplay().getMetrics(outMetrics);
        this.m_nDensity = outMetrics.densityDpi;
        this.m_cPaintDash.setColor(Color.argb(160, 255, 255, 255));
        this.m_cPaintDash.setStyle(Paint.Style.STROKE);
        this.m_cPaintDash.setPathEffect(cEffect);
        this.m_cDrawFocus = cContext.getResources().getDrawable(R.drawable.focusing);
        this.m_cDrawFocusError = cContext.getResources().getDrawable(R.drawable.focus_error);
        this.m_cDrawFocusSuccess = cContext.getResources().getDrawable(R.drawable.focus_success);
        this.m_cCrossHorzPaint.setStrokeWidth(3.0f);
        this.m_cCrossVertPaint.setStrokeWidth(3.0f);
        this.m_fArAngles[0] = -9999.0f;
        this.m_fArAngles[1] = -9999.0f;
        this.m_fArAngles[2] = -9999.0f;
        this.m_cScaleDetector = new ScaleGestureDetector(cContext, this);
        this.m_cPaintPano.setStyle(Paint.Style.FILL);
        this.m_cPaintPano.setColor(Color.argb(70, 255, 255, 255));
        this.m_cPaintPanoSpend.setStyle(Paint.Style.FILL);
        this.m_cPaintPanoSpend.setColor(Color.argb(128, 200, 200, 255));
        this.m_cPaintPanoRect.setStrokeWidth(3.0f);
        this.m_cPaintPanoRect.setStyle(Paint.Style.STROKE);
    }

    public synchronized void setZeroAccelListener(OnZeroAccelValue cListener) {
        this.m_iOnZeroAccel = cListener;
    }

    public synchronized boolean getShowGrid() {
        return this.m_bShowGrid;
    }

    public synchronized void setShowGrid(boolean bShow) {
        if (bShow != this.m_bShowGrid) {
            this.m_bShowGrid = bShow;
            invalidate();
        }
    }

    public synchronized boolean getShowCross() {
        return this.m_bShowCross;
    }

    public synchronized void setShowCross(boolean bShow) {
        if (bShow != this.m_bShowCross) {
            this.m_bShowCross = bShow;
            invalidate();
        }
    }

    public synchronized int getShowFocus() {
        return this.m_nShowFocus;
    }

    public synchronized void setShowFocus(int nShow) {
        if (nShow != this.m_nShowFocus) {
            Log.e("GridView", "set focus show");
            this.m_nShowFocus = nShow;
            invalidate();
        }
    }

    public synchronized void setShowFocusPos(int nX, int nY) {
        if (this.m_ptFocus.x != nX && this.m_ptFocus.y != nY) {
            Log.e("GridView", "set focus pos");
            this.m_ptFocus.x = nX;
            this.m_ptFocus.y = nY;
            invalidate();
        }
    }

    public synchronized void setAngles(float[] fArAngles) {
        this.m_fArAngles[0] = fArAngles[0];
        this.m_fArAngles[1] = fArAngles[1];
        this.m_fArAngles[2] = fArAngles[2];
        Redraw();
    }

    public synchronized void setAcceleration(float fX, float fY, float fZ) {
        this.m_fArG[0] = (0.8f * this.m_fArG[0]) + (0.19999999f * fX);
        this.m_fArG[1] = (0.8f * this.m_fArG[1]) + (0.19999999f * fY);
        this.m_fArG[2] = (0.8f * this.m_fArG[2]) + (0.19999999f * fZ);
        this.m_fArAccel[0] = fX - this.m_fArG[0];
        this.m_fArAccel[1] = fY - this.m_fArG[1];
        this.m_fArAccel[2] = fZ - this.m_fArG[2];
        this.m_fAcceleration = Math.sqrt(Math.pow(this.m_fArAccel[0], 2.0d) + Math.pow(this.m_fArAccel[1], 2.0d) + Math.pow(this.m_fArAccel[2], 2.0d));
        if (this.m_fAcceleration < 0.029999999329447746d && this.m_iOnZeroAccel != null) {
            this.m_iOnZeroAccel.onZeroAccel();
        }
        Redraw();
    }

    public synchronized void setListener(OnZeroAccelValue iListener) {
        this.m_iOnZeroAccel = iListener;
    }

    public CGridView(Context context) {
        super(context);
        this.mHeight = 0;
        this.mWidth = 0;
        this.m_cWhitePaint = new Paint();
        this.m_cShadowPaint = new Paint();
        this.m_cPaintDash = new Paint();
        this.m_cCrossVertPaint = new Paint();
        this.m_cCrossHorzPaint = new Paint();
        this.m_bShowGrid = false;
        this.m_bShowCross = true;
        this.m_nShowFocus = 0;
        this.m_ptFocus = new Point(0, 0);
        this.m_fArAccel = new float[3];
        this.m_fArG = new float[3];
        this.m_fAcceleration = 0.0d;
        this.m_fFocusRectHeight = 100.0f;
        this.m_fFocusRectWidth = 130.0f;
        this.m_cDrawFocus = null;
        this.m_cDrawFocusError = null;
        this.m_cDrawFocusSuccess = null;
        this.m_iOnZeroAccel = null;
        this.m_fArAngles = new float[3];
        this.m_nDensity = 240;
        this.m_bDrawPanoramaRect = false;
        this.m_bSparkle = false;
        this.m_cFocusHandler = new Handler();
        this.m_rcArFaces = new Vector<>();
        this.m_bWasSparkle = false;
        this.m_cPaintFace = new Paint();
        this.m_rcOval = new RectF();
        this.m_cScaleDetector = null;
        this.m_cListener = null;
        this.m_bOneTapGesture = true;
        this.m_ptDownPoint = new PointF();
        this.m_fArCoords = new float[8];
        this.m_fArCoordsDst = new float[8];
        this.m_cPathPano = new Path();
        this.m_cPathPanoSpend = new Path();
        this.m_cPaintPanoRect = new Paint();
        this.m_cPaintPano = new Paint();
        this.m_cPaintPanoSpend = new Paint();
        this.m_fX0 = 0.0f;
        this.m_fY0 = 0.0f;
        this.m_rcOvalPano = new RectF();
        this.m_fAngle = 0.0f;
        this.m_dL = 0.0f;
        this.m_dHeight = 0.0f;
        this.m_dDelta = 0.0f;
        this.m_dR = 0.0f;
        this.m_nOrientation = 0;
        this.m_cRunHideSparkle = new Runnable() { // from class: rubberbigpepper.CommonCtrl.CGridView.1
            @Override // java.lang.Runnable
            public void run() {
                if (CGridView.this.m_bWasSparkle) {
                    CGridView.this.m_bSparkle = false;
                }
                CGridView.this.invalidate();
            }
        };
        this.m_cInvalidate = new Runnable() { // from class: rubberbigpepper.CommonCtrl.CGridView.2
            @Override // java.lang.Runnable
            public void run() {
                CGridView.this.invalidate();
            }
        };
        Init(context);
    }

    public CGridView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mHeight = 0;
        this.mWidth = 0;
        this.m_cWhitePaint = new Paint();
        this.m_cShadowPaint = new Paint();
        this.m_cPaintDash = new Paint();
        this.m_cCrossVertPaint = new Paint();
        this.m_cCrossHorzPaint = new Paint();
        this.m_bShowGrid = false;
        this.m_bShowCross = true;
        this.m_nShowFocus = 0;
        this.m_ptFocus = new Point(0, 0);
        this.m_fArAccel = new float[3];
        this.m_fArG = new float[3];
        this.m_fAcceleration = 0.0d;
        this.m_fFocusRectHeight = 100.0f;
        this.m_fFocusRectWidth = 130.0f;
        this.m_cDrawFocus = null;
        this.m_cDrawFocusError = null;
        this.m_cDrawFocusSuccess = null;
        this.m_iOnZeroAccel = null;
        this.m_fArAngles = new float[3];
        this.m_nDensity = 240;
        this.m_bDrawPanoramaRect = false;
        this.m_bSparkle = false;
        this.m_cFocusHandler = new Handler();
        this.m_rcArFaces = new Vector<>();
        this.m_bWasSparkle = false;
        this.m_cPaintFace = new Paint();
        this.m_rcOval = new RectF();
        this.m_cScaleDetector = null;
        this.m_cListener = null;
        this.m_bOneTapGesture = true;
        this.m_ptDownPoint = new PointF();
        this.m_fArCoords = new float[8];
        this.m_fArCoordsDst = new float[8];
        this.m_cPathPano = new Path();
        this.m_cPathPanoSpend = new Path();
        this.m_cPaintPanoRect = new Paint();
        this.m_cPaintPano = new Paint();
        this.m_cPaintPanoSpend = new Paint();
        this.m_fX0 = 0.0f;
        this.m_fY0 = 0.0f;
        this.m_rcOvalPano = new RectF();
        this.m_fAngle = 0.0f;
        this.m_dL = 0.0f;
        this.m_dHeight = 0.0f;
        this.m_dDelta = 0.0f;
        this.m_dR = 0.0f;
        this.m_nOrientation = 0;
        this.m_cRunHideSparkle = new Runnable() { // from class: rubberbigpepper.CommonCtrl.CGridView.1
            @Override // java.lang.Runnable
            public void run() {
                if (CGridView.this.m_bWasSparkle) {
                    CGridView.this.m_bSparkle = false;
                }
                CGridView.this.invalidate();
            }
        };
        this.m_cInvalidate = new Runnable() { // from class: rubberbigpepper.CommonCtrl.CGridView.2
            @Override // java.lang.Runnable
            public void run() {
                CGridView.this.invalidate();
            }
        };
        Init(context);
    }

    public CGridView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mHeight = 0;
        this.mWidth = 0;
        this.m_cWhitePaint = new Paint();
        this.m_cShadowPaint = new Paint();
        this.m_cPaintDash = new Paint();
        this.m_cCrossVertPaint = new Paint();
        this.m_cCrossHorzPaint = new Paint();
        this.m_bShowGrid = false;
        this.m_bShowCross = true;
        this.m_nShowFocus = 0;
        this.m_ptFocus = new Point(0, 0);
        this.m_fArAccel = new float[3];
        this.m_fArG = new float[3];
        this.m_fAcceleration = 0.0d;
        this.m_fFocusRectHeight = 100.0f;
        this.m_fFocusRectWidth = 130.0f;
        this.m_cDrawFocus = null;
        this.m_cDrawFocusError = null;
        this.m_cDrawFocusSuccess = null;
        this.m_iOnZeroAccel = null;
        this.m_fArAngles = new float[3];
        this.m_nDensity = 240;
        this.m_bDrawPanoramaRect = false;
        this.m_bSparkle = false;
        this.m_cFocusHandler = new Handler();
        this.m_rcArFaces = new Vector<>();
        this.m_bWasSparkle = false;
        this.m_cPaintFace = new Paint();
        this.m_rcOval = new RectF();
        this.m_cScaleDetector = null;
        this.m_cListener = null;
        this.m_bOneTapGesture = true;
        this.m_ptDownPoint = new PointF();
        this.m_fArCoords = new float[8];
        this.m_fArCoordsDst = new float[8];
        this.m_cPathPano = new Path();
        this.m_cPathPanoSpend = new Path();
        this.m_cPaintPanoRect = new Paint();
        this.m_cPaintPano = new Paint();
        this.m_cPaintPanoSpend = new Paint();
        this.m_fX0 = 0.0f;
        this.m_fY0 = 0.0f;
        this.m_rcOvalPano = new RectF();
        this.m_fAngle = 0.0f;
        this.m_dL = 0.0f;
        this.m_dHeight = 0.0f;
        this.m_dDelta = 0.0f;
        this.m_dR = 0.0f;
        this.m_nOrientation = 0;
        this.m_cRunHideSparkle = new Runnable() { // from class: rubberbigpepper.CommonCtrl.CGridView.1
            @Override // java.lang.Runnable
            public void run() {
                if (CGridView.this.m_bWasSparkle) {
                    CGridView.this.m_bSparkle = false;
                }
                CGridView.this.invalidate();
            }
        };
        this.m_cInvalidate = new Runnable() { // from class: rubberbigpepper.CommonCtrl.CGridView.2
            @Override // java.lang.Runnable
            public void run() {
                CGridView.this.invalidate();
            }
        };
        Init(context);
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.m_bShowGrid) {
            int nY = (this.mHeight / 3) + 1;
            canvas.drawLine(0.0f, nY, this.mWidth, nY, this.m_cShadowPaint);
            int nY2 = ((this.mHeight * 2) / 3) + 1;
            canvas.drawLine(0.0f, nY2, this.mWidth, nY2, this.m_cShadowPaint);
            int nX = (this.mWidth / 3) + 1;
            canvas.drawLine(nX, 0.0f, nX, this.mHeight, this.m_cShadowPaint);
            int nX2 = ((this.mWidth * 2) / 3) + 1;
            canvas.drawLine(nX2, 0.0f, nX2, this.mHeight, this.m_cShadowPaint);
            int nY3 = this.mHeight / 3;
            canvas.drawLine(0.0f, nY3, this.mWidth, nY3, this.m_cWhitePaint);
            int nY4 = (this.mHeight * 2) / 3;
            canvas.drawLine(0.0f, nY4, this.mWidth, nY4, this.m_cWhitePaint);
            int nX3 = this.mWidth / 3;
            canvas.drawLine(nX3, 0.0f, nX3, this.mHeight, this.m_cWhitePaint);
            int nX4 = (this.mWidth * 2) / 3;
            canvas.drawLine(nX4, 0.0f, nX4, this.mHeight, this.m_cWhitePaint);
        }
        float fXCenter = this.mWidth * 0.5f;
        float fYCenter = this.mHeight * 0.5f;
        if (this.m_bShowCross) {
            float fLengAcc = (float) Math.min(70.0d, this.m_fAcceleration * 30.0d);
            canvas.drawLine((fXCenter - fLengAcc) - 20.0f, fYCenter, fXCenter - fLengAcc, fYCenter, this.m_cCrossHorzPaint);
            canvas.drawLine(fXCenter + fLengAcc + 20.0f, fYCenter, fXCenter + fLengAcc, fYCenter, this.m_cCrossHorzPaint);
            canvas.drawLine(fXCenter, (fYCenter - fLengAcc) - 20.0f, fXCenter, fYCenter - fLengAcc, this.m_cCrossVertPaint);
            canvas.drawLine(fXCenter, fYCenter + fLengAcc + 20.0f, fXCenter, fYCenter + fLengAcc, this.m_cCrossVertPaint);
        }
        if (this.m_nShowFocus > 0) {
            Log.e("GridView", "show focus>0");
            float fSizeHeight = (this.m_fFocusRectHeight * this.m_nDensity) / 240.0f;
            float fSizeWidth = (this.m_fFocusRectWidth * this.m_nDensity) / 240.0f;
            float fTop = Math.max(0.0f, this.m_ptFocus.y - (0.5f * fSizeHeight));
            float fLeft = Math.max(0.0f, this.m_ptFocus.x - (0.5f * fSizeWidth));
            float fBottom = fTop + fSizeHeight;
            float fRight = fLeft + fSizeWidth;
            if (fBottom >= this.mHeight) {
                fBottom = this.mHeight;
                fTop = fBottom - fSizeHeight;
            }
            if (fRight >= this.mWidth) {
                fRight = this.mWidth;
                fLeft = fRight - fSizeWidth;
            }
            switch (this.m_nShowFocus) {
                case 1:
                    this.m_cDrawFocus.setBounds((int) fLeft, (int) fTop, (int) fRight, (int) fBottom);
                    this.m_cDrawFocus.draw(canvas);
                    break;
                case 2:
                    this.m_cDrawFocusError.setBounds((int) fLeft, (int) fTop, (int) fRight, (int) fBottom);
                    this.m_cDrawFocusError.draw(canvas);
                    break;
                case 3:
                    this.m_cDrawFocusSuccess.setBounds((int) fLeft, (int) fTop, (int) fRight, (int) fBottom);
                    this.m_cDrawFocusSuccess.draw(canvas);
                    break;
            }
        }
        if (this.m_bDrawPanoramaRect) {
            DrawPanorama(canvas);
        }
        if (this.m_bSparkle) {
            canvas.drawColor(-1);
            if (!this.m_bWasSparkle) {
                this.m_cFocusHandler.postDelayed(this.m_cRunHideSparkle, 20L);
            }
            this.m_bWasSparkle = true;
        }
        for (int n = 0; n < this.m_rcArFaces.size(); n++) {
            Rect rcFace = this.m_rcArFaces.get(n);
            if (rcFace.left != -1000 || rcFace.right != 1000 || rcFace.top != -1000 || rcFace.bottom != 1000) {
                this.m_rcOval.set(rcFace);
                canvas.drawArc(this.m_rcOval, 0.0f, 360.0f, false, this.m_cPaintFace);
            }
        }
    }

    public void SetPanoramaAngleProgress(float fAngle) {
        this.m_cPathPanoSpend.reset();
        this.m_rcOvalPano.top = this.m_fY0 - (this.m_dR * 2.0f);
        this.m_rcOvalPano.bottom = (this.m_fY0 - (this.m_dHeight * 0.5f)) + this.m_dDelta;
        float fAngleProgress = Math.min((this.m_fAngle * fAngle) / 160.0f, this.m_fAngle * 2.0f);
        this.m_cPathPanoSpend.addArc(this.m_rcOvalPano, (90.0f + this.m_fAngle) - fAngleProgress, fAngleProgress);
        this.m_rcOvalPano.top = (this.m_fY0 + (this.m_dHeight * 0.5f)) - this.m_dDelta;
        this.m_rcOvalPano.bottom = this.m_fY0 + (this.m_dR * 2.0f);
        this.m_cPathPanoSpend.lineTo(this.m_fX0 - this.m_dL, this.m_fY0 + (this.m_dHeight * 0.5f));
        this.m_cPathPanoSpend.arcTo(this.m_rcOvalPano, 270.0f - this.m_fAngle, fAngleProgress);
        this.m_cPathPanoSpend.close();
        postInvalidate();
    }

    private void PreparePanoramaDrawing() {
        float fMarginH = this.mWidth * 0.1f;
        float fMarginV = this.mHeight * 0.25f;
        this.m_fArCoords[0] = fMarginH;
        this.m_fArCoords[1] = fMarginV;
        this.m_fArCoords[2] = this.mWidth - fMarginH;
        this.m_fArCoords[3] = fMarginV;
        this.m_fArCoords[4] = this.mWidth - fMarginH;
        this.m_fArCoords[5] = this.mHeight - fMarginV;
        this.m_fArCoords[6] = fMarginH;
        this.m_fArCoords[7] = this.mHeight - fMarginV;
        float dWidth = this.mWidth * 0.75f;
        this.m_dL = dWidth * 0.5f;
        this.m_dHeight = this.mHeight * 0.2f;
        this.m_dDelta = this.m_dHeight * 0.25f;
        this.m_dR = (float) ((Math.pow(this.m_dL, 2.0d) + Math.pow(this.m_dDelta, 2.0d)) / (this.m_dDelta * 2.0f));
        this.m_fX0 = this.mWidth * 0.5f;
        this.m_fY0 = this.mHeight * 0.5f;
        this.m_rcOvalPano.top = this.m_fY0 - (this.m_dR * 2.0f);
        this.m_rcOvalPano.left = this.m_fX0 - this.m_dR;
        this.m_rcOvalPano.right = this.m_fX0 + this.m_dR;
        this.m_rcOvalPano.bottom = (this.m_fY0 - (this.m_dHeight * 0.5f)) + this.m_dDelta;
        this.m_fAngle = (float) ((180.0d * Math.asin(this.m_dL / this.m_dR)) / 3.141592653589793d);
        this.m_cPathPano.rewind();
        this.m_cPathPano.reset();
        this.m_cPathPano.moveTo(this.m_fX0 + this.m_dL, this.m_fY0 - (this.m_dHeight * 0.5f));
        this.m_cPathPano.arcTo(this.m_rcOvalPano, 90.0f - this.m_fAngle, this.m_fAngle * 2.0f);
        this.m_rcOvalPano.top = (this.m_fY0 + (this.m_dHeight * 0.5f)) - this.m_dDelta;
        this.m_rcOvalPano.bottom = this.m_fY0 + (this.m_dR * 2.0f);
        this.m_cPathPano.lineTo(this.m_fX0 - this.m_dL, this.m_fY0 + (this.m_dHeight * 0.5f));
        this.m_cPathPano.arcTo(this.m_rcOvalPano, 270.0f - this.m_fAngle, this.m_fAngle * 2.0f);
        this.m_cPathPano.close();
    }

    private void DrawPanorama(Canvas cCanvas) {
        cCanvas.drawPath(this.m_cPathPano, this.m_cPaintPano);
        cCanvas.drawPath(this.m_cPathPanoSpend, this.m_cPaintPanoSpend);
    }

    @Override // android.view.View
    protected void onMeasure(int widthSpecId, int heightSpecId) {
        this.mHeight = View.MeasureSpec.getSize(heightSpecId);
        this.mWidth = View.MeasureSpec.getSize(widthSpecId);
        int[] nArColors = {Color.argb(192, 255, 0, 0), Color.argb(192, 255, 255, 0), Color.argb(192, 0, 255, 0), Color.argb(192, 255, 255, 0), Color.argb(192, 255, 0, 0)};
        Shader cShader = new LinearGradient((this.mWidth * 0.5f) - 70.0f, 0.0f, (this.mWidth * 0.5f) + 70.0f, 0.0f, nArColors, (float[]) null, Shader.TileMode.CLAMP);
        this.m_cCrossHorzPaint.setShader(cShader);
        Shader cShader2 = new LinearGradient(0.0f, (this.mHeight * 0.5f) - 70.0f, 0.0f, (this.mHeight * 0.5f) + 70.0f, nArColors, (float[]) null, Shader.TileMode.CLAMP);
        this.m_cCrossVertPaint.setShader(cShader2);
        setMeasuredDimension(this.mWidth, this.mHeight);
        PreparePanoramaDrawing();
    }

    public synchronized void Redraw() {
        post(this.m_cInvalidate);
    }

    public synchronized void ShowSparkle() {
        this.m_cFocusHandler.removeCallbacks(this.m_cRunHideSparkle);
        this.m_bSparkle = true;
        this.m_bWasSparkle = false;
        postInvalidate();
    }

    public synchronized void HideSparkle() {
        this.m_bSparkle = false;
        this.m_cFocusHandler.removeCallbacks(this.m_cRunHideSparkle);
        postInvalidate();
    }

    public synchronized void SetFaces(Rect[] rcArFaces) {
        this.m_rcArFaces.clear();
        if (rcArFaces != null) {
            for (Rect rcFace : rcArFaces) {
                int nLeft = (this.mWidth * (rcFace.left + 1000)) / 2000;
                int nRight = (this.mWidth * (rcFace.right + 1000)) / 2000;
                int nBottom = (this.mHeight * (rcFace.bottom + 1000)) / 2000;
                int nTop = (this.mHeight * (rcFace.top + 1000)) / 2000;
                this.m_rcArFaces.add(new Rect(nLeft, nTop, nRight, nBottom));
            }
        }
        postInvalidate();
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent event) {
        this.m_cScaleDetector.onTouchEvent(event);
        if (event.getPointerCount() == 1) {
            switch (event.getAction()) {
                case 0:
                    this.m_bOneTapGesture = true;
                    this.m_ptDownPoint.x = event.getX();
                    this.m_ptDownPoint.y = event.getY();
                    break;
                case 1:
                    if (this.m_bOneTapGesture) {
                        if (event.getEventTime() - event.getDownTime() > 2000) {
                            if (this.m_cListener != null) {
                                this.m_cListener.OnLongClick();
                                break;
                            }
                        } else {
                            if (event.getEventTime() - event.getDownTime() < 500) {
                                int nWidth = getWidth();
                                int nHeight = getHeight();
                                float fXLeng = Math.abs(event.getX() - this.m_ptDownPoint.x);
                                float fYLeng = Math.abs(event.getY() - this.m_ptDownPoint.y);
                                if (fXLeng > fYLeng) {
                                    if (fXLeng > nWidth * 0.3f && this.m_cListener != null) {
                                        if (event.getX() > this.m_ptDownPoint.x) {
                                            this.m_cListener.OnSwipeLeftToRight();
                                            break;
                                        } else {
                                            this.m_cListener.OnSwipeRightToLeft();
                                            break;
                                        }
                                    }
                                } else if (fYLeng > nHeight * 0.3f && this.m_cListener != null) {
                                    if (event.getY() > this.m_ptDownPoint.y) {
                                        this.m_cListener.OnSwipeTopToBottom();
                                        break;
                                    } else {
                                        this.m_cListener.OnSwipeBottomToTop();
                                        break;
                                    }
                                }
                            }
                            if (this.m_cListener != null) {
                                this.m_cListener.OnTap(event.getX(), event.getY());
                                break;
                            }
                        }
                    }
                    break;
            }
        } else {
            this.m_bOneTapGesture = false;
        }
        return true;
    }

    @Override // android.view.ScaleGestureDetector.OnScaleGestureListener
    public boolean onScale(ScaleGestureDetector detector) {
        if (this.m_cListener != null) {
            this.m_cListener.OnScale(detector.getScaleFactor());
        }
        this.m_bOneTapGesture = false;
        return true;
    }

    @Override // android.view.ScaleGestureDetector.OnScaleGestureListener
    public boolean onScaleBegin(ScaleGestureDetector detector) {
        return true;
    }

    @Override // android.view.ScaleGestureDetector.OnScaleGestureListener
    public void onScaleEnd(ScaleGestureDetector detector) {
        this.m_bOneTapGesture = true;
    }
}