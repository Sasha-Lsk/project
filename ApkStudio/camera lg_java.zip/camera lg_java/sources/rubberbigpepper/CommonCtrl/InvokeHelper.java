package rubberbigpepper.CommonCtrl;

import android.graphics.Rect;
import android.util.Log;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.List;

/* loaded from: classes.dex */
public class InvokeHelper {
    public static Object InvokeMethodFast(Object cClass, String strMethodName) {
        try {
            return InvokeMethodFastTE(cClass, strMethodName);
        } catch (Exception ex) {
            Log.e("InvokeHelper", "Method " + strMethodName + " error " + ex.getMessage());
            return null;
        }
    }

    public static Object InvokeMethodFastTE(Object cClass, String strMethodName) throws Exception {
        Method cMethod = cClass.getClass().getDeclaredMethod(strMethodName, null);
        cMethod.setAccessible(true);
        return cMethod.getReturnType() == Integer.TYPE ? (Integer) cMethod.invoke(cClass, new Object[0]) : cMethod.invoke(cClass, new Object[0]);
    }

    public static Object InvokeMethod(Object cClass, String strMethodName) {
        try {
            strMethodName = getDeclaredMethodExistName(cClass, strMethodName);
            if (strMethodName.length() > 0) {
                return InvokeMethodFast(cClass, strMethodName);
            }
        } catch (Exception ex) {
            Log.e("InvokeHelper", "Method " + strMethodName + " error " + ex.getMessage());
        }
        return null;
    }

    public static String getDeclaredMethodExistName(Object cClass, String strMethod) {
        return getDeclaredMethodExistName(cClass.getClass(), strMethod);
    }

    public static String getDeclaredMethodExistName(Class<?> cClass, String strMethod) {
        Method[] cArMethods = cClass.getDeclaredMethods();
        for (int n = 0; n < cArMethods.length; n++) {
            if (cArMethods[n].getName().equalsIgnoreCase(strMethod)) {
                return cArMethods[n].getName();
            }
        }
        return "";
    }

    public static Object CreateCameraArea(String strClassName, Rect rcArea, int nWeight) {
        try {
            Class<?> cClass = Class.forName(strClassName);
            return CreateCameraArea(cClass, rcArea, nWeight);
        } catch (Exception ex) {
            Log.e("InvokeHelper", "Class " + strClassName + " error " + ex.getMessage());
            return null;
        }
    }

    public static Object CreateCameraArea(Class<?> cClassArea, Rect rcArea, int nWeight) {
        try {
            Constructor<?> cConstructor = cClassArea.getDeclaredConstructor(Rect.class, Integer.TYPE);
            cConstructor.setAccessible(true);
            return cConstructor.newInstance(rcArea, Integer.valueOf(nWeight));
        } catch (Exception ex) {
            Log.e("InvokeHelper", "Class " + cClassArea.getName() + " error " + ex.getMessage());
            return null;
        }
    }

    public static Object InvokeMethodFast(Object cClass, String strMethodName, List<?> cAreas) {
        try {
            Method cMethod = cClass.getClass().getDeclaredMethod(strMethodName, List.class);
            cMethod.setAccessible(true);
            return cMethod.getReturnType() == Integer.TYPE ? (Integer) cMethod.invoke(cClass, cAreas) : cMethod.invoke(cClass, cAreas);
        } catch (Exception ex) {
            Log.e("InvokeHelper", "Method " + strMethodName + " error " + ex.getMessage());
            return null;
        }
    }

    public static Object InvokeMethodFast(Object cClass, String strMethodName, String strParam) {
        try {
            Method cMethod = cClass.getClass().getDeclaredMethod(strMethodName, String.class);
            cMethod.setAccessible(true);
            return cMethod.getReturnType() == Integer.TYPE ? (Integer) cMethod.invoke(cClass, strParam) : cMethod.invoke(cClass, strParam);
        } catch (Exception ex) {
            Log.e("InvokeHelper", "Method " + strMethodName + " error " + ex.getMessage());
            return null;
        }
    }

    public static Object InvokeMethodFast(Object cClass, String strMethodName, String strParam1, String strParam2) {
        try {
            Method cMethod = cClass.getClass().getDeclaredMethod(strMethodName, String.class, String.class);
            cMethod.setAccessible(true);
            return cMethod.getReturnType() == Integer.TYPE ? (Integer) cMethod.invoke(cClass, strParam1, strParam2) : cMethod.invoke(cClass, strParam1, strParam2);
        } catch (Exception ex) {
            Log.e("InvokeHelper", "Method " + strMethodName + " error " + ex.getMessage());
            return null;
        }
    }

    public static Object InvokeMethodFast(Object cClass, String strMethodName, String strParam1, int nParam2) {
        try {
            Method cMethod = cClass.getClass().getDeclaredMethod(strMethodName, String.class, Integer.TYPE);
            cMethod.setAccessible(true);
            return cMethod.getReturnType() == Integer.TYPE ? (Integer) cMethod.invoke(cClass, strParam1, Integer.valueOf(nParam2)) : cMethod.invoke(cClass, strParam1, Integer.valueOf(nParam2));
        } catch (Exception ex) {
            Log.e("InvokeHelper", "Method " + strMethodName + " error " + ex.getMessage());
            return null;
        }
    }

    public static Object InvokeMethodFast(Object cClass, String strMethodName, Class<?> cClassParam, Object oParam) {
        try {
            Method cMethod = cClass.getClass().getDeclaredMethod(strMethodName, cClassParam);
            cMethod.setAccessible(true);
            return cMethod.getReturnType() == Integer.TYPE ? (Integer) cMethod.invoke(cClass, oParam) : cMethod.invoke(cClass, oParam);
        } catch (Exception ex) {
            Log.e("InvokeHelper", "Method " + strMethodName + " error " + ex.getMessage());
            return null;
        }
    }

    public static Object InvokeMethodFast(Object cClass, String strMethodName, Object oParam) {
        try {
            Method cMethod = cClass.getClass().getDeclaredMethod(strMethodName, oParam.getClass());
            Log.d("InvokeHelper", "Method get");
            cMethod.setAccessible(true);
            Log.d("InvokeHelper", "Method accessible");
            Class<?> cClassRet = cMethod.getReturnType();
            Log.d("InvokeHelper", cClassRet.toString());
            return cClassRet == Integer.TYPE ? (Integer) cMethod.invoke(cClass, oParam) : cMethod.invoke(cClass, oParam);
        } catch (Exception ex) {
            Log.e("InvokeHelper", "Method " + strMethodName + " error " + ex.getMessage() + " " + ex.toString());
            return null;
        }
    }

    public static Object InvokeMethodFast(Object cClass, String strMethodName, Object oParam1, Object oParam2, Object oParam3) {
        try {
            Method cMethod = cClass.getClass().getDeclaredMethod(strMethodName, oParam1.getClass(), oParam2.getClass(), oParam3.getClass());
            cMethod.setAccessible(true);
            return cMethod.getReturnType() == Integer.TYPE ? (Integer) cMethod.invoke(cClass, oParam1, oParam2, oParam3) : cMethod.invoke(cClass, oParam1, oParam2, oParam3);
        } catch (Exception ex) {
            Log.e("InvokeHelper", "Method " + strMethodName + " error " + ex.getMessage());
            return null;
        }
    }

    public static Object InvokeMethod(Object cClass, String strMethodName, String strParam) {
        try {
            String strMethodName2 = getDeclaredMethodExistName(cClass, strMethodName);
            if (strMethodName2.length() > 0) {
                return InvokeMethodFast(cClass, strMethodName2, strParam);
            }
        } catch (Exception e) {
        }
        return null;
    }

    public static Object InvokeMethodFast(Object cClass, String strMethodName, int nParam) {
        try {
            Method cMethod = cClass.getClass().getDeclaredMethod(strMethodName, Integer.TYPE);
            cMethod.setAccessible(true);
            return cMethod.getReturnType() == Integer.TYPE ? (Integer) cMethod.invoke(cClass, Integer.valueOf(nParam)) : cMethod.invoke(cClass, Integer.valueOf(nParam));
        } catch (Exception ex) {
            Log.e("InvokeHelper", "Method " + strMethodName + " error " + ex.getMessage());
            return null;
        }
    }

    public static Object InvokeMethodFast(Object cClass, String strMethodName, boolean bParam) {
        try {
            Method cMethod = cClass.getClass().getDeclaredMethod(strMethodName, Boolean.TYPE);
            cMethod.setAccessible(true);
            return cMethod.getReturnType() == Integer.TYPE ? (Integer) cMethod.invoke(cClass, Boolean.valueOf(bParam)) : cMethod.invoke(cClass, Boolean.valueOf(bParam));
        } catch (Exception ex) {
            Log.e("InvokeHelper", "Method " + strMethodName + " error " + ex.getMessage());
            return null;
        }
    }

    public static Object InvokeMethodFast(Object cClass, String strMethodName, int nParam1, int nParam2) {
        try {
            Method cMethod = cClass.getClass().getDeclaredMethod(strMethodName, Integer.TYPE, Integer.TYPE);
            cMethod.setAccessible(true);
            return cMethod.getReturnType() == Integer.TYPE ? (Integer) cMethod.invoke(cClass, Integer.valueOf(nParam1), Integer.valueOf(nParam2)) : cMethod.invoke(cClass, Integer.valueOf(nParam1), Integer.valueOf(nParam2));
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public static Object InvokeMethodFast(Object cClass, String strMethodName, int nParam1, int nParam2, int nParam3) {
        try {
            Method cMethod = cClass.getClass().getDeclaredMethod(strMethodName, Integer.TYPE, Integer.TYPE, Integer.TYPE);
            cMethod.setAccessible(true);
            return cMethod.getReturnType() == Integer.TYPE ? (Integer) cMethod.invoke(cClass, Integer.valueOf(nParam1), Integer.valueOf(nParam2), Integer.valueOf(nParam3)) : cMethod.invoke(cClass, Integer.valueOf(nParam1), Integer.valueOf(nParam2), Integer.valueOf(nParam3));
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public static Object InvokeMethod(Object cClass, String strMethodName, int nParam) {
        try {
            String strMethodName2 = getDeclaredMethodExistName(cClass, strMethodName);
            if (strMethodName2.length() > 0) {
                return InvokeMethodFast(cClass, strMethodName2, nParam);
            }
        } catch (Exception e) {
        }
        return null;
    }

    public static Object InvokeMethodFast(Object cClass, String strMethodName, Class<?>[] clsArr, Object[] cArObjects) {
        Object invoke;
        try {
            Method cMethod = cClass.getClass().getDeclaredMethod(strMethodName, clsArr);
            cMethod.setAccessible(true);
            if (cMethod.getReturnType() == Integer.TYPE) {
                invoke = (Integer) cMethod.invoke(cClass, cArObjects);
            } else {
                invoke = cMethod.invoke(cClass, cArObjects);
            }
            return invoke;
        } catch (Exception ex) {
            Log.e("InvokeHelper", "Method " + strMethodName + " error " + ex.getMessage());
            return null;
        }
    }

    public static Object InvokeMethodFast(Object cClass, String strMethodName, double dParam) {
        try {
            Method cMethod = cClass.getClass().getDeclaredMethod(strMethodName, Double.TYPE);
            cMethod.setAccessible(true);
            return cMethod.getReturnType() == Integer.TYPE ? (Integer) cMethod.invoke(cClass, Double.valueOf(dParam)) : cMethod.invoke(cClass, Double.valueOf(dParam));
        } catch (Exception ex) {
            Log.e("InvokeHelper", "Method " + strMethodName + " error " + ex.getMessage());
            return null;
        }
    }

    public static Object InvokeMethodFast(Object cClass, String strMethodName, long nParam) {
        try {
            Method cMethod = cClass.getClass().getDeclaredMethod(strMethodName, Long.TYPE);
            cMethod.setAccessible(true);
            return cMethod.getReturnType() == Integer.TYPE ? (Integer) cMethod.invoke(cClass, Long.valueOf(nParam)) : cMethod.invoke(cClass, Long.valueOf(nParam));
        } catch (Exception ex) {
            Log.e("InvokeHelper", "Method " + strMethodName + " error " + ex.getMessage());
            return null;
        }
    }

    public static Object InvokeMethod(Object cClass, String strMethodName, long nParam) {
        try {
            String strMethodName2 = getDeclaredMethodExistName(cClass, strMethodName);
            if (strMethodName2.length() > 0) {
                return InvokeMethodFast(cClass, strMethodName2, nParam);
            }
        } catch (Exception e) {
        }
        return null;
    }

    public static boolean IsMethodExist(Object cClass, String strMethod) {
        return getDeclaredMethodExistName(cClass, strMethod).length() > 0;
    }

    public static boolean IsMethodExist(Class<?> cClass, String strMethod) {
        return getDeclaredMethodExistName(cClass, strMethod).length() > 0;
    }

    public static Object GetFieldValue(Object oObject, String strFieldName) {
        try {
            return oObject.getClass().getField(strFieldName).get(oObject);
        } catch (Exception e) {
            return null;
        }
    }

    public static int GetFieldIntValue(Object oObject, String strFieldName) {
        try {
            return oObject.getClass().getField(strFieldName).getInt(oObject);
        } catch (Exception e) {
            return -9999;
        }
    }

    public static Object GetStaticFieldValue(Class<?> cClass, String strFieldName) {
        try {
            return cClass.getField(strFieldName).get(null);
        } catch (Exception e) {
            return null;
        }
    }

    public static Object InvokeStaticMethod(Class<?> cClass, String strMethodName, String strParam) {
        try {
            Method cMethod = cClass.getDeclaredMethod(strMethodName, String.class);
            cMethod.setAccessible(true);
            return cMethod.invoke(null, strParam);
        } catch (Exception e) {
            return null;
        }
    }

    public static Object InvokeStaticMethod(Class<?> cClass, String strMethodName, int nParam) {
        try {
            Method cMethod = cClass.getDeclaredMethod(strMethodName, Integer.TYPE);
            cMethod.setAccessible(true);
            return cMethod.invoke(null, Integer.valueOf(nParam));
        } catch (Exception e) {
            return null;
        }
    }

    public static Object InvokeStaticMethod(Class<?> cClass, String strMethodName, int nParam1, int nParam2) {
        try {
            Method cMethod = cClass.getDeclaredMethod(strMethodName, Integer.TYPE, Integer.TYPE);
            cMethod.setAccessible(true);
            return cMethod.invoke(null, Integer.valueOf(nParam1), Integer.valueOf(nParam2));
        } catch (Exception e) {
            return null;
        }
    }

    public static Object InvokeStaticMethod(Class<?> cClass, String strMethodName, boolean bParam) {
        try {
            Method cMethod = cClass.getDeclaredMethod(strMethodName, Boolean.TYPE);
            cMethod.setAccessible(true);
            return cMethod.invoke(null, Boolean.valueOf(bParam));
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public static Object InvokeStaticMethod(Class<?> cClass, String strMethodName) {
        try {
            Method cMethod = cClass.getDeclaredMethod(strMethodName, null);
            cMethod.setAccessible(true);
            return cMethod.invoke(null, new Object[0]);
        } catch (Exception e) {
            return null;
        }
    }

    public static void SaveAllMethods(Object cClass) {
        SaveAllMethods(cClass.getClass());
    }

    public static void SaveAllMethods(Class<?> cClass) {
        boolean bDebug = DebugLog.m_bDebug;
        DebugLog.m_bDebug = true;
        Method[] cArMethods = cClass.getDeclaredMethods();
        String strClassName = cClass.getName();
        Constructor[] cArCnts = cClass.getDeclaredConstructors();
        for (int n = 0; n < cArCnts.length; n++) {
            StringBuilder cBuilder = new StringBuilder();
            cBuilder.append(String.valueOf(strClassName) + " constructor: ");
            cBuilder.append(cArCnts[n].getName());
            cBuilder.append("(");
            Class[] cArParams = cArCnts[n].getParameterTypes();
            if (cArParams != null && cArParams.length > 0) {
                for (int m = 0; m < cArParams.length; m++) {
                    if (m > 0) {
                        cBuilder.append(", ");
                    }
                    cBuilder.append(cArParams[m].getName());
                }
            }
            cBuilder.append(")");
            DebugLog.WriteDebug(cBuilder.toString());
        }
        for (int n2 = 0; n2 < cArMethods.length; n2++) {
            StringBuilder cBuilder2 = new StringBuilder();
            cBuilder2.append(String.valueOf(strClassName) + " function: ");
            cBuilder2.append(cArMethods[n2].getReturnType().getName());
            cBuilder2.append(" ");
            cBuilder2.append(cArMethods[n2].getName());
            cBuilder2.append("(");
            Class[] cArParams2 = cArMethods[n2].getParameterTypes();
            if (cArParams2 != null && cArParams2.length > 0) {
                for (int m2 = 0; m2 < cArParams2.length; m2++) {
                    if (m2 > 0) {
                        cBuilder2.append(", ");
                    }
                    cBuilder2.append(cArParams2[m2].getName());
                }
            }
            cBuilder2.append(")");
            DebugLog.WriteDebug(cBuilder2.toString());
        }
        DebugLog.m_bDebug = bDebug;
    }
}