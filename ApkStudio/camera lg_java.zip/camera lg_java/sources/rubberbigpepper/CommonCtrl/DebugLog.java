package rubberbigpepper.CommonCtrl;

import android.os.Environment;
import android.text.format.Time;
import java.io.FileWriter;

/* loaded from: classes.dex */
public class DebugLog {
    public static boolean m_bDebug = false;
    public static String m_strFileName = String.valueOf(Environment.getExternalStorageDirectory().getAbsolutePath()) + "/lgCamera.log";

    public static void WriteDebug(String strDebug) {
        if (m_bDebug) {
            try {
                Time cTime = new Time();
                cTime.setToNow();
                FileWriter cFile = new FileWriter(m_strFileName, true);
                cFile.append((CharSequence) (String.valueOf(String.format("%d/%d/%d %02d:%02d:%02d ", Integer.valueOf(cTime.monthDay), Integer.valueOf(cTime.month + 1), Integer.valueOf(cTime.year), Integer.valueOf(cTime.hour), Integer.valueOf(cTime.minute), Integer.valueOf(cTime.second))) + strDebug + "\r\n"));
                cFile.close();
            } catch (Exception e) {
            }
        }
    }
}