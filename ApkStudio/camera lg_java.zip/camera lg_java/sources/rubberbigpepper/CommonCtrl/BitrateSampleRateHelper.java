package rubberbigpepper.CommonCtrl;

/* loaded from: classes.dex */
public class BitrateSampleRateHelper {
    public static int[] m_nArVideoBitrates = {100000, 250000, 500000, 1000000, 2000000, 3000000, 5000000, 6000000, 8000000, 10000000, 12000000, 15000000, 17000000, 20000000, 25000000, 30000000, 40000000, 50000000, 60000000, 75000000, 100000000};
    public static int[] m_nArAudioBitrates = {12800, 25600, 48000, 51200, 62900, 64000, 96000, 128000, 160000, 204800, 256000, 320000};
    public static int[] m_nArAudioSampleRates = {11025, 12000, 16000, 22050, 24000, 32000, 44100, 48000};

    public static int getNearestVideoBitrate(int nBitRate) {
        if (nBitRate < m_nArVideoBitrates[0]) {
            return m_nArVideoBitrates[0];
        }
        if (nBitRate > m_nArVideoBitrates[m_nArVideoBitrates.length - 1]) {
            return m_nArVideoBitrates[m_nArVideoBitrates.length - 1];
        }
        for (int n = 0; n < m_nArVideoBitrates.length - 1; n++) {
            if (nBitRate >= m_nArVideoBitrates[n] && nBitRate < m_nArVideoBitrates[n + 1]) {
                return m_nArVideoBitrates[n];
            }
        }
        return nBitRate;
    }

    public static int getNearestAudioBitrate(int nBitRate) {
        if (nBitRate < m_nArAudioBitrates[0]) {
            return m_nArAudioBitrates[0];
        }
        if (nBitRate > m_nArAudioBitrates[m_nArAudioBitrates.length - 1]) {
            return m_nArAudioBitrates[m_nArAudioBitrates.length - 1];
        }
        for (int n = 0; n < m_nArAudioBitrates.length - 1; n++) {
            if (nBitRate >= m_nArAudioBitrates[n] && nBitRate < m_nArAudioBitrates[n + 1]) {
                return m_nArAudioBitrates[n];
            }
        }
        return nBitRate;
    }

    public static int getNearestAudioSamplerate(int nSamplerate) {
        if (nSamplerate < m_nArAudioSampleRates[0]) {
            return m_nArAudioSampleRates[0];
        }
        if (nSamplerate > m_nArAudioSampleRates[m_nArAudioSampleRates.length - 1]) {
            return m_nArAudioSampleRates[m_nArAudioSampleRates.length - 1];
        }
        for (int n = 0; n < m_nArAudioSampleRates.length - 1; n++) {
            if (nSamplerate >= m_nArAudioSampleRates[n] && nSamplerate < m_nArAudioSampleRates[n + 1]) {
                return m_nArAudioSampleRates[n];
            }
        }
        return nSamplerate;
    }
}