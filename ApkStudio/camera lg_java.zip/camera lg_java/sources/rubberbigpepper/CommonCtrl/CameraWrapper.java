package rubberbigpepper.CommonCtrl;

import android.content.Context;
import android.graphics.Rect;
import android.hardware.Camera;
import android.media.MediaRecorder;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import java.io.FileDescriptor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

/* loaded from: classes.dex */
public class CameraWrapper {
    private Object m_cInvokeHandler;
    protected OnCameraWrapperEventListener m_cListener;
    private Class<?> m_clsFaceListener;
    private Camera m_cCamera = null;
    private MediaRecorder m_cRecorder = null;
    private InnerListener m_cInnerListener = new InnerListener(this, null);
    public Object m_oAGC = null;

    /* loaded from: classes.dex */
    public interface OnCameraWrapperEventListener {
        void onAutoFocus(boolean z);

        void onFaceDetection(Rect[] rectArr);

        void onPictureTaken(byte[] bArr);

        void onPreviewFrame(byte[] bArr);

        void onRecordError(int i, int i2);

        void onRecordInfo(int i, int i2);

        void onShutter();

        void onZoomChange(int i, boolean z);
    }

    public CameraWrapper(Context cContext, OnCameraWrapperEventListener cListener) {
        this.m_cListener = null;
        this.m_clsFaceListener = null;
        this.m_cInvokeHandler = null;
        try {
            this.m_clsFaceListener = Class.forName("android.hardware.Camera$FaceDetectionListener");
            this.m_cInvokeHandler = Proxy.newProxyInstance(this.m_clsFaceListener.getClassLoader(), new Class[]{this.m_clsFaceListener}, this.m_cInnerListener);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        this.m_cListener = cListener;
    }

    public void ReleaseCamera() {
        StopPreviewCallback();
        this.m_cCamera.release();
        this.m_cCamera = null;
    }

    public void OpenCamera(int nCameraIndex) {
        try {
            this.m_cCamera = Camera.open(nCameraIndex);
        } catch (Exception e) {
        }
        if (this.m_cCamera == null) {
            this.m_cCamera = Camera.open();
        }
        this.m_cCamera.setZoomChangeListener(this.m_cInnerListener);
    }

    public boolean Initialized() {
        return this.m_cCamera != null;
    }

    public void ReconnectCamera() throws Exception {
        this.m_cCamera.reconnect();
    }

    public static int GetNumberOfCameras() {
        try {
            return Camera.getNumberOfCameras();
        } catch (Exception e) {
            return 1;
        }
    }

    public CameraParamWrapper GetParameters(boolean bUpdate) {
        if (this.m_cCamera != null) {
            return new CameraParamWrapper(this.m_cCamera);
        }
        Log.e("lgCamera", "GetParameters, m_cCamera==null!");
        return null;
    }

    public void SetParameters(CameraParamWrapper cParams) {
        if (this.m_cCamera != null && cParams != null) {
            Object oParams = cParams.GetInternalObject();
            this.m_cCamera.setParameters((Camera.Parameters) oParams);
        }
    }

    public boolean CanDetectFaces() {
        try {
            int nMaxFaces = GetParameters(false).getMaxNumDetectedFaces();
            Log.e("lgCamera", "Max face detection " + nMaxFaces);
            return nMaxFaces > 0;
        } catch (Exception ex) {
            Log.e("lgCamera", "Max face detection error\n\r" + ex.getMessage());
            return false;
        }
    }

    public void StartFaceDetection() {
        try {
            InvokeHelper.InvokeMethodFast(this.m_cCamera, "setFaceDetectionListener", this.m_clsFaceListener, this.m_cInvokeHandler);
            InvokeHelper.InvokeMethodFast(this.m_cCamera, "startFaceDetection");
        } catch (Exception e) {
        }
    }

    public void StopFaceDetection() {
        if (this.m_cCamera != null) {
            InvokeHelper.InvokeMethodFast(this.m_cCamera, "stopFaceDetection");
        }
    }

    public void StartPreview() {
        this.m_cCamera.startPreview();
    }

    public void StopPreview() {
        StopPreviewCallback();
        this.m_cCamera.stopPreview();
    }

    public void Lock() {
        this.m_cCamera.lock();
    }

    public void Unlock() {
        this.m_cCamera.unlock();
    }

    public void TakePicture() {
        try {
            this.m_cCamera.takePicture(null, null, null, this.m_cInnerListener);
        } catch (Exception e) {
        }
    }

    public void SetPreviewDisplay(SurfaceHolder holder) throws Exception {
        this.m_cCamera.setPreviewDisplay(holder);
    }

    public void SetDisplayOrientation(int degrees) {
        this.m_cCamera.setDisplayOrientation(degrees);
    }

    public void cancelAutoFocus() {
        this.m_cCamera.cancelAutoFocus();
    }

    public void AutoFocus() {
        try {
            this.m_cCamera.autoFocus(this.m_cInnerListener);
        } catch (Exception e) {
        }
    }

    public void InitRecorder() throws Exception {
        this.m_cRecorder = new MediaRecorder();
    }

    public void PrepareRecorder() throws Exception {
        this.m_cRecorder.prepare();
    }

    public void ReleaseRecorder() {
        this.m_cRecorder.release();
        this.m_cRecorder = null;
    }

    public void ResetRecorder() {
        this.m_cRecorder.reset();
    }

    public void SetAudioChannels(int numChannels) {
        this.m_cRecorder.setAudioChannels(numChannels);
    }

    public void SetAudioEncoder(int audio_encoder) {
        this.m_cRecorder.setAudioEncoder(audio_encoder);
    }

    public void SetAudioEncodingBitRate(int bitRate) {
        this.m_cRecorder.setAudioEncodingBitRate(bitRate);
    }

    public void SetAudioSamplingRate(int samplingRate) {
        this.m_cRecorder.setAudioSamplingRate(samplingRate);
    }

    public void SetAudioSource(int audio_source) {
        this.m_cRecorder.setAudioSource(audio_source);
    }

    public void LinkCamera() {
        if (this.m_cCamera != null) {
            this.m_cRecorder.setCamera(this.m_cCamera);
        }
        this.m_cRecorder.setOnInfoListener(this.m_cInnerListener);
        this.m_cRecorder.setOnErrorListener(this.m_cInnerListener);
    }

    public void SetMaxDuration(int max_duration_ms) {
        this.m_cRecorder.setMaxDuration(max_duration_ms);
    }

    public void SetMaxFileSize(long max_filesize_bytes) {
        this.m_cRecorder.setMaxFileSize(max_filesize_bytes);
    }

    public void SetOrientationHint(int degrees) {
        InvokeHelper.InvokeMethodFast((Object) this.m_cRecorder, "setOrientationHint", degrees);
    }

    public void SetOutputFile(FileDescriptor fd) {
        this.m_cRecorder.setOutputFile(fd);
    }

    public void SetOutputFormat(int output_format) {
        this.m_cRecorder.setOutputFormat(output_format);
    }

    public void SetPreviewDisplay(Surface sv) {
        this.m_cRecorder.setPreviewDisplay(sv);
    }

    public void SetVideoEncoder(int video_encoder) {
        this.m_cRecorder.setVideoEncoder(video_encoder);
    }

    public void SetVideoEncodingBitRate(int bitRate) {
        this.m_cRecorder.setVideoEncodingBitRate(bitRate);
    }

    public void SetVideoFrameRate(int rate) {
        this.m_cRecorder.setVideoFrameRate(rate);
    }

    public void SetVideoSize(int width, int height) {
        this.m_cRecorder.setVideoSize(width, height);
    }

    public void SetVideoSource(int video_source) {
        this.m_cRecorder.setVideoSource(video_source);
    }

    public void StartRecording() throws Exception {
        this.m_cRecorder.start();
    }

    public void StopRecording() throws Exception {
        this.m_cRecorder.stop();
    }

    public boolean FpsCaptureExist() {
        try {
            return InvokeHelper.IsMethodExist(Class.forName("android.media.MediaRecorder"), "setCaptureRate");
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public void SetCaptureRate(double dFps) {
        if (this.m_cRecorder != null) {
            InvokeHelper.InvokeMethodFast(this.m_cRecorder, "setCaptureRate", dFps);
        }
    }

    public boolean IsPauseExists() {
        return InvokeHelper.IsMethodExist(this.m_cRecorder, "pause") & InvokeHelper.IsMethodExist(this.m_cRecorder, "resume");
    }

    public void PauseRecording() throws Exception {
        InvokeHelper.InvokeMethod(this.m_cRecorder, "pause");
    }

    public void ResumeRecording() throws Exception {
        InvokeHelper.InvokeMethod(this.m_cRecorder, "resume");
    }

    public void StartPreviewCallback() {
        this.m_cCamera.setPreviewCallback(this.m_cInnerListener);
    }

    public void StopPreviewCallback() {
        this.m_cCamera.setPreviewCallback(null);
    }

    /* loaded from: classes.dex */
    private class InnerListener implements Camera.AutoFocusCallback, MediaRecorder.OnErrorListener, MediaRecorder.OnInfoListener, Camera.ShutterCallback, Camera.PictureCallback, Camera.OnZoomChangeListener, InvocationHandler, Camera.PreviewCallback {
        private InnerListener() {
        }

        /* synthetic */ InnerListener(CameraWrapper cameraWrapper, InnerListener innerListener) {
            this();
        }

        @Override // android.media.MediaRecorder.OnInfoListener
        public void onInfo(MediaRecorder mr, int what, int extra) {
            if (CameraWrapper.this.m_cListener != null) {
                CameraWrapper.this.m_cListener.onRecordInfo(what, extra);
            }
        }

        @Override // android.media.MediaRecorder.OnErrorListener
        public void onError(MediaRecorder mr, int what, int extra) {
            if (CameraWrapper.this.m_cListener != null) {
                CameraWrapper.this.m_cListener.onRecordError(what, extra);
            }
        }

        @Override // android.hardware.Camera.AutoFocusCallback
        public void onAutoFocus(boolean success, Camera camera) {
            if (CameraWrapper.this.m_cListener != null) {
                CameraWrapper.this.m_cListener.onAutoFocus(success);
            }
        }

        @Override // android.hardware.Camera.PictureCallback
        public void onPictureTaken(byte[] data, Camera camera) {
            try {
                if (CameraWrapper.this.m_cListener != null && data != null) {
                    CameraWrapper.this.m_cListener.onPictureTaken(data);
                }
            } catch (Exception e) {
            }
        }

        @Override // android.hardware.Camera.ShutterCallback
        public void onShutter() {
            if (CameraWrapper.this.m_cListener != null) {
                CameraWrapper.this.m_cListener.onShutter();
            }
        }

        @Override // android.hardware.Camera.OnZoomChangeListener
        public void onZoomChange(int zoomValue, boolean stopped, Camera camera) {
            if (CameraWrapper.this.m_cListener != null) {
                CameraWrapper.this.m_cListener.onZoomChange(zoomValue, stopped);
            }
        }

        @Override // java.lang.reflect.InvocationHandler
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            if (method.getName().equalsIgnoreCase("onFaceDetection")) {
                Object[] faces = (Object[]) args[0];
                if (CameraWrapper.this.m_cListener != null && faces != null) {
                    Rect[] rcFaces = new Rect[faces.length];
                    for (int n = 0; n < faces.length; n++) {
                        Rect rcFace = (Rect) InvokeHelper.GetFieldValue(faces[n], "rect");
                        rcFaces[n] = rcFace;
                    }
                    CameraWrapper.this.m_cListener.onFaceDetection(rcFaces);
                    return null;
                }
                return null;
            }
            return null;
        }

        @Override // android.hardware.Camera.PreviewCallback
        public void onPreviewFrame(byte[] data, Camera camera) {
            if (CameraWrapper.this.m_cListener != null) {
                CameraWrapper.this.m_cListener.onPreviewFrame(data);
            }
        }
    }
}