package rubberbigpepper.CommonCtrl;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.location.Location;
import android.util.Log;
import com.android.camera.CameraView;

/* loaded from: classes.dex */
public class JpegUtil {
    private boolean m_bAttached;

    private native boolean AttachJPG(byte[] bArr);

    private native void OverlayData(int[] iArr, int i, int i2, int i3, int i4);

    private native boolean SaveJPG(String str);

    public native void Clear();

    public native byte[] JPG2BGR24(byte[] bArr);

    public native boolean isOpen();

    public JpegUtil(byte[] frame) {
        this.m_bAttached = false;
        try {
            System.loadLibrary("jpegutil");
            if (AttachJPG(frame)) {
                this.m_bAttached = true;
            }
        } catch (UnsatisfiedLinkError e) {
        }
    }

    public JpegUtil() {
        this.m_bAttached = false;
        try {
            System.loadLibrary("jpegutil");
        } catch (UnsatisfiedLinkError e) {
        }
    }

    public boolean IsAttached() {
        return this.m_bAttached;
    }

    public boolean Save(String strFileName) {
        return SaveJPG(strFileName);
    }

    public void OverlayJPEGText(String strText, CameraView cCameraView) {
        int nYTextOut;
        Paint cPaint = new Paint();
        switch (cCameraView.m_nOverlayGravity) {
            case 0:
            case 2:
                cPaint.setTextAlign(Paint.Align.LEFT);
                break;
            case 1:
            default:
                cPaint.setTextAlign(Paint.Align.RIGHT);
                break;
        }
        cPaint.setTextSize(cCameraView.m_nOverlayFontSize);
        Log.e("lgCamera", "Overlay font size " + cCameraView.m_nOverlayFontSize);
        cPaint.setColor(cCameraView.m_nOverlayColor);
        Rect rcBounds = new Rect();
        cPaint.getTextBounds(strText, 0, strText.length(), rcBounds);
        int nMaxWidth = (int) (rcBounds.width() * 1.05f);
        int nMaxHeight = (int) (rcBounds.height() * 1.25f);
        if (cCameraView.m_strOverlayAddText.length() > 0) {
            cPaint.getTextBounds(cCameraView.m_strOverlayAddText, 0, cCameraView.m_strOverlayAddText.length(), rcBounds);
            nMaxWidth = Math.max(nMaxWidth, rcBounds.width());
            nMaxHeight += (int) (rcBounds.height() * 1.25f);
        }
        String strGPSText = "";
        if (cCameraView.m_bOverlayGPS) {
            Location cLoc = cCameraView.getMainWindow().getLastKnownLocation();
            strGPSText = String.valueOf(getLatitudeString(cLoc.getLatitude())) + ", " + getLongitudeString(cLoc.getLongitude());
            cPaint.getTextBounds(strGPSText, 0, cCameraView.m_strOverlayAddText.length(), rcBounds);
            nMaxWidth = Math.max(nMaxWidth, rcBounds.width());
            nMaxHeight += (int) (rcBounds.height() * 1.25f);
        }
        if (nMaxWidth > 0 && nMaxHeight > 0) {
            int nMaxHeight2 = nMaxHeight + rcBounds.height();
            int nMaxWidth2 = Math.min(cCameraView.getPhotoSize().x, nMaxWidth);
            int nMaxHeight3 = Math.min(cCameraView.getPhotoSize().y, nMaxHeight2);
            Log.e("lgCamera", String.format("Overlay size %d,%d", Integer.valueOf(nMaxWidth2), Integer.valueOf(nMaxHeight3)));
            Bitmap cBmp = Bitmap.createBitmap(nMaxWidth2, nMaxHeight3, Bitmap.Config.ARGB_8888);
            Canvas cCanvas = new Canvas(cBmp);
            cCanvas.drawColor(Color.argb(0, 0, 0, 0), PorterDuff.Mode.SRC_OVER);
            int nYTextOut2 = 0;
            int nXTextOut = 0;
            switch (cCameraView.m_nOverlayGravity) {
                case 1:
                case 3:
                    nXTextOut = nMaxWidth2 - 1;
                    break;
            }
            Log.e("lgCamera", String.format("Overlay textout %d,%d", Integer.valueOf(nXTextOut), 0));
            if (cCameraView.m_strOverlayAddText.length() > 0) {
                cPaint.getTextBounds(cCameraView.m_strOverlayAddText, 0, cCameraView.m_strOverlayAddText.length(), rcBounds);
                nYTextOut2 = 0 + ((int) (rcBounds.height() * 1.25f));
                cCanvas.drawText(cCameraView.m_strOverlayAddText, nXTextOut, nYTextOut2, cPaint);
            }
            cPaint.getTextBounds(strText, 0, strText.length(), rcBounds);
            cCanvas.drawText(strText, nXTextOut, nYTextOut2 + ((int) (rcBounds.height() * 1.25f)), cPaint);
            if (cCameraView.m_bOverlayGPS) {
                cPaint.getTextBounds(strGPSText, 0, strGPSText.length(), rcBounds);
                cCanvas.drawText(strGPSText, nXTextOut, nYTextOut + ((int) (rcBounds.height() * 1.25f)), cPaint);
            }
            int nXOverlay = Math.min(cBmp.getHeight(), cCameraView.getPhotoSize().x - cBmp.getHeight());
            int nYOverlay = Math.min((cBmp.getHeight() * 2) / 3, cCameraView.getPhotoSize().y - ((cBmp.getHeight() * 2) / 3));
            Log.e("lgCamera", String.format("Overlay out %d,%d", Integer.valueOf(nXOverlay), Integer.valueOf(nYOverlay)));
            int[] nArPixels = new int[cBmp.getWidth() * cBmp.getHeight()];
            cBmp.getPixels(nArPixels, 0, cBmp.getWidth(), 0, 0, cBmp.getWidth(), cBmp.getHeight());
            switch (cCameraView.m_nOverlayGravity) {
                case 0:
                    OverlayData(nArPixels, cBmp.getWidth(), cBmp.getHeight(), nXOverlay, nYOverlay);
                    return;
                case 1:
                    OverlayData(nArPixels, cBmp.getWidth(), cBmp.getHeight(), -nXOverlay, nYOverlay);
                    return;
                case 2:
                    OverlayData(nArPixels, cBmp.getWidth(), cBmp.getHeight(), nXOverlay, -nYOverlay);
                    return;
                case 3:
                    OverlayData(nArPixels, cBmp.getWidth(), cBmp.getHeight(), -nXOverlay, -nYOverlay);
                    return;
                default:
                    return;
            }
        }
    }

    public Bitmap toBitmap(byte[] byArJPG) {
        try {
            return BitmapFactory.decodeByteArray(byArJPG, 0, byArJPG.length);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    private String getLatitudeString(double dLatitude) {
        if (dLatitude != -9999.0d) {
            double fLatitude = dLatitude;
            if (fLatitude < 0.0d) {
                fLatitude = -fLatitude;
            }
            int nDegrees = (int) fLatitude;
            int nMinutes = (int) (60.0d * (fLatitude - nDegrees));
            double fSeconds = 60.0d * ((60.0d * (fLatitude - nDegrees)) - nMinutes);
            if (dLatitude < 0.0d) {
                return String.format("S%d°%02d'%.2f''", Integer.valueOf(nDegrees), Integer.valueOf(nMinutes), Double.valueOf(fSeconds));
            }
            return String.format("N%d°%02d'%.2f''", Integer.valueOf(nDegrees), Integer.valueOf(nMinutes), Double.valueOf(fSeconds));
        }
        return "N/A";
    }

    private String getLongitudeString(double dLongitude) {
        if (dLongitude != -9999.0d) {
            double fLongitude = dLongitude;
            if (fLongitude < 0.0d) {
                fLongitude = -fLongitude;
            }
            int nDegrees = (int) fLongitude;
            int nMinutes = (int) (60.0d * (fLongitude - nDegrees));
            double fSeconds = 60.0d * ((60.0d * (fLongitude - nDegrees)) - nMinutes);
            if (dLongitude < 0.0d) {
                return String.format("W%d°%02d'%.2f''", Integer.valueOf(nDegrees), Integer.valueOf(nMinutes), Double.valueOf(fSeconds));
            }
            return String.format("E%d°%02d'%.2f''", Integer.valueOf(nDegrees), Integer.valueOf(nMinutes), Double.valueOf(fSeconds));
        }
        return "N/A";
    }
}