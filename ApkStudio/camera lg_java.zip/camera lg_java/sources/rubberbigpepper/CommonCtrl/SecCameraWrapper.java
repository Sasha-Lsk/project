package rubberbigpepper.CommonCtrl;

import android.content.Context;
import android.graphics.Rect;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import dalvik.system.PathClassLoader;
import java.io.File;
import java.io.FileDescriptor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import rubberbigpepper.CommonCtrl.CameraWrapper;

/* loaded from: classes.dex */
public class SecCameraWrapper extends CameraWrapper implements InvocationHandler {
    private boolean m_bInit;
    private Object m_cCamera;
    private Class<?> m_cCameraClass;
    private Class<?> m_cClassAutoFocus;
    private Class<?> m_cClassFaceDetect;
    private Class<?> m_cClassParameters;
    private Class<?> m_cClassPreviewCbk;
    private Class<?> m_cClassShutter;
    private Class<?> m_cClassTakePicture;
    private Object m_cInvokeHandler;
    private Class<?> m_cOnErrorListenerClass;
    private Class<?> m_cOnInfoListenerClass;
    private Object m_cRecorder;
    private Class<?> m_cRecorderClass;
    private Method m_mtdAutoFocus;
    private Method m_mtdCancelAutoFocus;
    private Method m_mtdLock;
    private Method m_mtdOpenCamera;
    private Method m_mtdPause;
    private Method m_mtdPrepareRecorder;
    private Method m_mtdReconnect;
    private Method m_mtdReleaseCamera;
    private Method m_mtdReleaseRecorder;
    private Method m_mtdResetRecorder;
    private Method m_mtdResume;
    private Method m_mtdSetAudioBitrate;
    private Method m_mtdSetAudioChannels;
    private Method m_mtdSetAudioEncoder;
    private Method m_mtdSetAudioSampleRate;
    private Method m_mtdSetAudioSource;
    private Method m_mtdSetCamera;
    private Method m_mtdSetCaptureRate;
    private Method m_mtdSetDisplay;
    private Method m_mtdSetDisplayOrientation;
    private Method m_mtdSetFaceDetectionListener;
    private Method m_mtdSetMaxDuration;
    private Method m_mtdSetMaxSize;
    private Method m_mtdSetOnErrorListener;
    private Method m_mtdSetOnInfoListener;
    private Method m_mtdSetOrientation;
    private Method m_mtdSetOutputFD;
    private Method m_mtdSetOutputFormat;
    private Method m_mtdSetOutputPath;
    private Method m_mtdSetParameters;
    private Method m_mtdSetPreviewCbk;
    private Method m_mtdSetPreviewDisplay;
    private Method m_mtdSetVideoBitrate;
    private Method m_mtdSetVideoEncoder;
    private Method m_mtdSetVideoFrameRate;
    private Method m_mtdSetVideoSize;
    private Method m_mtdSetVideoSource;
    private Method m_mtdStart;
    private Method m_mtdStartFaceDetection;
    private Method m_mtdStartPreview;
    private Method m_mtdStop;
    private Method m_mtdStopFaceDetection;
    private Method m_mtdStopPreview;
    private Method m_mtdTakePicture;
    private Method m_mtdUnLock;

    public SecCameraWrapper(Context cContext, CameraWrapper.OnCameraWrapperEventListener cListener) {
        super(cContext, cListener);
        this.m_cRecorder = null;
        this.m_cInvokeHandler = null;
        this.m_cCameraClass = null;
        this.m_cRecorderClass = null;
        this.m_cOnInfoListenerClass = null;
        this.m_cOnErrorListenerClass = null;
        this.m_cClassTakePicture = null;
        this.m_cClassAutoFocus = null;
        this.m_cClassShutter = null;
        this.m_cClassFaceDetect = null;
        this.m_cClassParameters = null;
        this.m_cClassPreviewCbk = null;
        this.m_cCamera = null;
        this.m_mtdSetPreviewCbk = null;
        this.m_mtdReleaseCamera = null;
        this.m_mtdLock = null;
        this.m_mtdUnLock = null;
        this.m_mtdOpenCamera = null;
        this.m_mtdReconnect = null;
        this.m_mtdStopPreview = null;
        this.m_mtdStartPreview = null;
        this.m_mtdSetDisplay = null;
        this.m_mtdSetDisplayOrientation = null;
        this.m_mtdAutoFocus = null;
        this.m_mtdCancelAutoFocus = null;
        this.m_mtdTakePicture = null;
        this.m_mtdStopFaceDetection = null;
        this.m_mtdStartFaceDetection = null;
        this.m_mtdSetFaceDetectionListener = null;
        this.m_mtdSetParameters = null;
        this.m_mtdSetCaptureRate = null;
        this.m_mtdPause = null;
        this.m_mtdResume = null;
        this.m_mtdSetCamera = null;
        this.m_mtdSetOnInfoListener = null;
        this.m_mtdSetOnErrorListener = null;
        this.m_mtdReleaseRecorder = null;
        this.m_mtdPrepareRecorder = null;
        this.m_mtdSetAudioChannels = null;
        this.m_mtdSetAudioBitrate = null;
        this.m_mtdSetAudioSampleRate = null;
        this.m_mtdSetAudioEncoder = null;
        this.m_mtdSetAudioSource = null;
        this.m_mtdSetVideoBitrate = null;
        this.m_mtdSetVideoFrameRate = null;
        this.m_mtdSetVideoEncoder = null;
        this.m_mtdSetVideoSize = null;
        this.m_mtdSetVideoSource = null;
        this.m_mtdResetRecorder = null;
        this.m_mtdStart = null;
        this.m_mtdStop = null;
        this.m_mtdSetMaxDuration = null;
        this.m_mtdSetMaxSize = null;
        this.m_mtdSetOrientation = null;
        this.m_mtdSetOutputFD = null;
        this.m_mtdSetOutputPath = null;
        this.m_mtdSetOutputFormat = null;
        this.m_mtdSetPreviewDisplay = null;
        this.m_bInit = false;
        InitializeClasses();
    }

    public static boolean IsSECSupported() {
        try {
            File cFileCam = new File("/system/framework/seccamera.jar");
            File cFileRec = new File("/system/framework/secmediarecorder.jar");
            if (cFileCam.exists()) {
                return cFileRec.exists();
            }
            return false;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    private void InitializeClasses() {
        this.m_cCameraClass = null;
        this.m_cClassTakePicture = null;
        this.m_cClassAutoFocus = null;
        this.m_cClassShutter = null;
        this.m_cOnInfoListenerClass = null;
        this.m_cRecorderClass = null;
        this.m_cInvokeHandler = null;
        try {
            PathClassLoader cClassLoader = new PathClassLoader("/system/framework/seccamera.jar", ClassLoader.getSystemClassLoader());
            this.m_cCameraClass = cClassLoader.loadClass("com.sec.android.seccamera.SecCamera");
            this.m_cClassTakePicture = cClassLoader.loadClass("com.sec.android.seccamera.SecCamera$PictureCallback");
            this.m_cClassAutoFocus = cClassLoader.loadClass("com.sec.android.seccamera.SecCamera$AutoFocusCallback");
            this.m_cClassShutter = cClassLoader.loadClass("com.sec.android.seccamera.SecCamera$ShutterCallback");
            this.m_cClassFaceDetect = cClassLoader.loadClass("com.sec.android.seccamera.SecCamera$FaceDetectionListener");
            this.m_cClassParameters = cClassLoader.loadClass("com.sec.android.seccamera.SecCamera$Parameters");
            this.m_cClassPreviewCbk = cClassLoader.loadClass("com.sec.android.seccamera.SecCamera$PreviewCallback");
        } catch (Exception ex) {
            Log.e("Classes", ex.toString());
            ex.printStackTrace();
            DebugLog.WriteDebug("SecCameraClass not found!" + ex.getMessage() + " " + ex.toString());
        }
        try {
            PathClassLoader cClassLoader2 = new PathClassLoader("/system/framework/secmediarecorder.jar", this.m_cCameraClass.getClassLoader());
            this.m_cRecorderClass = cClassLoader2.loadClass("com.sec.android.secmediarecorder.SecMediaRecorder");
            this.m_cOnInfoListenerClass = cClassLoader2.loadClass("com.sec.android.secmediarecorder.SecMediaRecorder$OnInfoListener");
            this.m_cOnErrorListenerClass = cClassLoader2.loadClass("com.sec.android.secmediarecorder.SecMediaRecorder$OnErrorListener");
        } catch (Exception ex2) {
            Log.e("Classes", ex2.toString());
            ex2.printStackTrace();
            DebugLog.WriteDebug("SecRecorderClass not found " + ex2.getMessage() + " " + ex2.toString());
        }
        if (this.m_cRecorderClass == null || this.m_cOnInfoListenerClass == null || this.m_cCameraClass == null || this.m_cClassTakePicture == null || this.m_cClassAutoFocus == null || this.m_cClassShutter == null || this.m_cOnErrorListenerClass == null || this.m_cClassParameters == null) {
            this.m_bInit = false;
        } else {
            this.m_bInit = true;
            if (this.m_cClassFaceDetect == null) {
                this.m_cInvokeHandler = Proxy.newProxyInstance(this.m_cOnInfoListenerClass.getClassLoader(), new Class[]{this.m_cOnInfoListenerClass, this.m_cClassTakePicture, this.m_cClassAutoFocus, this.m_cClassShutter, this.m_cOnErrorListenerClass, this.m_cClassPreviewCbk}, this);
            } else {
                this.m_cInvokeHandler = Proxy.newProxyInstance(this.m_cOnInfoListenerClass.getClassLoader(), new Class[]{this.m_cOnInfoListenerClass, this.m_cClassTakePicture, this.m_cClassAutoFocus, this.m_cClassShutter, this.m_cOnErrorListenerClass, this.m_cClassFaceDetect, this.m_cClassPreviewCbk}, this);
            }
        }
        LoadMethods();
    }

    private void LoadMethods() {
        this.m_mtdSetPreviewCbk = GetDeclaredMethod(this.m_cCameraClass, "setPreviewCallback", new Class[]{this.m_cClassPreviewCbk});
        this.m_mtdReleaseCamera = GetDeclaredMethod(this.m_cCameraClass, "release", null);
        this.m_mtdLock = GetDeclaredMethod(this.m_cCameraClass, "lock", null);
        this.m_mtdUnLock = GetDeclaredMethod(this.m_cCameraClass, "unlock", null);
        this.m_mtdOpenCamera = GetDeclaredMethod(this.m_cCameraClass, "open", new Class[]{Integer.TYPE});
        this.m_mtdReconnect = GetDeclaredMethod(this.m_cCameraClass, "reconnect", null);
        this.m_mtdStopPreview = GetDeclaredMethod(this.m_cCameraClass, "stopPreview", null);
        this.m_mtdStartPreview = GetDeclaredMethod(this.m_cCameraClass, "startPreview", null);
        this.m_mtdSetDisplay = GetDeclaredMethod(this.m_cCameraClass, "setPreviewDisplay", new Class[]{SurfaceHolder.class});
        this.m_mtdSetDisplayOrientation = GetDeclaredMethod(this.m_cCameraClass, "setDisplayOrientation", new Class[]{Integer.TYPE});
        this.m_mtdAutoFocus = GetDeclaredMethod(this.m_cCameraClass, "autoFocus", new Class[]{this.m_cClassAutoFocus});
        this.m_mtdCancelAutoFocus = GetDeclaredMethod(this.m_cCameraClass, "cancelAutoFocus", null);
        this.m_mtdTakePicture = GetDeclaredMethod(this.m_cCameraClass, "takePicture", new Class[]{this.m_cClassShutter, this.m_cClassTakePicture, this.m_cClassTakePicture, this.m_cClassTakePicture});
        this.m_mtdStopFaceDetection = GetDeclaredMethod(this.m_cCameraClass, "stopFaceDetection", null);
        this.m_mtdStartFaceDetection = GetDeclaredMethod(this.m_cCameraClass, "startFaceDetection", null);
        this.m_mtdSetFaceDetectionListener = GetDeclaredMethod(this.m_cCameraClass, "setFaceDetectionListener", new Class[]{this.m_cClassFaceDetect});
        this.m_mtdSetParameters = GetDeclaredMethod(this.m_cCameraClass, "setParameters", new Class[]{this.m_cClassParameters});
        this.m_mtdSetCaptureRate = GetDeclaredMethod(this.m_cRecorderClass, "setCaptureRate", new Class[]{Double.TYPE});
        this.m_mtdPause = GetDeclaredMethod(this.m_cRecorderClass, "pause", null);
        this.m_mtdResume = GetDeclaredMethod(this.m_cRecorderClass, "resume", null);
        this.m_mtdSetCamera = GetDeclaredMethod(this.m_cRecorderClass, "setCamera", new Class[]{this.m_cCameraClass});
        this.m_mtdSetOnInfoListener = GetDeclaredMethod(this.m_cRecorderClass, "setOnInfoListener", new Class[]{this.m_cOnInfoListenerClass});
        this.m_mtdSetOnErrorListener = GetDeclaredMethod(this.m_cRecorderClass, "setOnErrorListener", new Class[]{this.m_cOnErrorListenerClass});
        this.m_mtdReleaseRecorder = GetDeclaredMethod(this.m_cRecorderClass, "release", null);
        this.m_mtdPrepareRecorder = GetDeclaredMethod(this.m_cRecorderClass, "prepare", null);
        this.m_mtdSetAudioChannels = GetDeclaredMethod(this.m_cRecorderClass, "setAudioChannels", new Class[]{Integer.TYPE});
        this.m_mtdSetAudioBitrate = GetDeclaredMethod(this.m_cRecorderClass, "setAudioEncodingBitRate", new Class[]{Integer.TYPE});
        this.m_mtdSetAudioSampleRate = GetDeclaredMethod(this.m_cRecorderClass, "setAudioSamplingRate", new Class[]{Integer.TYPE});
        this.m_mtdSetAudioEncoder = GetDeclaredMethod(this.m_cRecorderClass, "setAudioEncoder", new Class[]{Integer.TYPE});
        this.m_mtdSetAudioSource = GetDeclaredMethod(this.m_cRecorderClass, "setAudioSource", new Class[]{Integer.TYPE});
        this.m_mtdSetVideoBitrate = GetDeclaredMethod(this.m_cRecorderClass, "setVideoEncodingBitRate", new Class[]{Integer.TYPE});
        this.m_mtdSetVideoFrameRate = GetDeclaredMethod(this.m_cRecorderClass, "setVideoFrameRate", new Class[]{Integer.TYPE});
        this.m_mtdSetVideoEncoder = GetDeclaredMethod(this.m_cRecorderClass, "setVideoEncoder", new Class[]{Integer.TYPE});
        this.m_mtdSetVideoSource = GetDeclaredMethod(this.m_cRecorderClass, "setVideoSource", new Class[]{Integer.TYPE});
        this.m_mtdSetVideoSize = GetDeclaredMethod(this.m_cRecorderClass, "setVideoSize", new Class[]{Integer.TYPE, Integer.TYPE});
        this.m_mtdResetRecorder = GetDeclaredMethod(this.m_cRecorderClass, "reset", null);
        this.m_mtdStart = GetDeclaredMethod(this.m_cRecorderClass, "start", null);
        this.m_mtdStop = GetDeclaredMethod(this.m_cRecorderClass, "stop", null);
        this.m_mtdSetMaxDuration = GetDeclaredMethod(this.m_cRecorderClass, "setMaxDuration", new Class[]{Integer.TYPE});
        this.m_mtdSetMaxSize = GetDeclaredMethod(this.m_cRecorderClass, "setMaxFileSize", new Class[]{Long.TYPE});
        this.m_mtdSetOrientation = GetDeclaredMethod(this.m_cRecorderClass, "setOrientationHint", new Class[]{Integer.TYPE});
        this.m_mtdSetOutputFD = GetDeclaredMethod(this.m_cRecorderClass, "setOutputFile", new Class[]{FileDescriptor.class});
        this.m_mtdSetOutputPath = GetDeclaredMethod(this.m_cRecorderClass, "setOutputFile", new Class[]{String.class});
        this.m_mtdSetOutputFormat = GetDeclaredMethod(this.m_cRecorderClass, "setOutputFormat", new Class[]{Integer.TYPE});
        this.m_mtdSetPreviewDisplay = GetDeclaredMethod(this.m_cRecorderClass, "setPreviewDisplay", new Class[]{Surface.class});
    }

    private Method GetDeclaredMethod(Class<?> cClass, String strMethodName, Class<?>[] clsArr) {
        try {
            Method cMethod = cClass.getDeclaredMethod(strMethodName, clsArr);
            cMethod.setAccessible(true);
            return cMethod;
        } catch (Exception ex) {
            ex.printStackTrace();
            DebugLog.WriteDebug(ex.getLocalizedMessage());
            return null;
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public boolean FpsCaptureExist() {
        return this.m_mtdSetCaptureRate != null;
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetCaptureRate(double dFps) {
        try {
            this.m_mtdSetCaptureRate.invoke(this.m_cRecorder, Double.valueOf(dFps));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public boolean IsSecInitialized() {
        return this.m_bInit;
    }

    @Override // java.lang.reflect.InvocationHandler
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        String strMetName = method.getName();
        if (strMetName.equalsIgnoreCase("onInfo") && this.m_cListener != null) {
            this.m_cListener.onRecordInfo(((Integer) args[1]).intValue(), ((Integer) args[2]).intValue());
        }
        if (strMetName.equalsIgnoreCase("onError") && this.m_cListener != null) {
            this.m_cListener.onRecordError(((Integer) args[1]).intValue(), ((Integer) args[2]).intValue());
        }
        if (strMetName.equalsIgnoreCase("onPictureTaken") && this.m_cListener != null) {
            this.m_cListener.onPictureTaken((byte[]) args[0]);
        }
        if (strMetName.equalsIgnoreCase("onShutter") && this.m_cListener != null) {
            this.m_cListener.onShutter();
        }
        if (strMetName.equalsIgnoreCase("onAutoFocus") && this.m_cListener != null) {
            boolean bSuccess = false;
            int nValue = -9999;
            String strValue = String.valueOf(args[0]);
            Log.e("lgCamera", "arg[0]=" + strValue + ", " + args[0].getClass().toString());
            try {
                nValue = Integer.valueOf(strValue).intValue();
            } catch (Exception e) {
            }
            if (nValue == -9999) {
                bSuccess = Boolean.valueOf(strValue).booleanValue();
            } else if (nValue == 1) {
                bSuccess = true;
            }
            this.m_cListener.onAutoFocus(bSuccess);
        }
        if (strMetName.equalsIgnoreCase("onFaceDetection")) {
            Object[] faces = (Object[]) args[0];
            if (this.m_cListener != null && faces != null) {
                Rect[] rcFaces = new Rect[faces.length];
                for (int n = 0; n < faces.length; n++) {
                    Rect rcFace = (Rect) InvokeHelper.GetFieldValue(faces[n], "rect");
                    rcFaces[n] = rcFace;
                }
                this.m_cListener.onFaceDetection(rcFaces);
            }
        }
        if (strMetName.equalsIgnoreCase("onPreviewFrame") && this.m_cListener != null) {
            this.m_cListener.onPreviewFrame((byte[]) args[0]);
            return null;
        }
        return null;
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void ReleaseCamera() {
        if (this.m_cCamera != null) {
            try {
                this.m_mtdReleaseCamera.invoke(this.m_cCamera, null);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        this.m_cCamera = null;
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void OpenCamera(int nCameraIndex) {
        try {
            this.m_cCamera = this.m_mtdOpenCamera.invoke(this.m_cCameraClass, Integer.valueOf(nCameraIndex));
        } catch (Exception ex) {
            ex.printStackTrace();
        } catch (UnsatisfiedLinkError er) {
            er.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public boolean Initialized() {
        return this.m_cCamera != null;
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void ReconnectCamera() throws Exception {
        try {
            this.m_mtdReconnect.invoke(this.m_cCamera, null);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public CameraParamWrapper GetParameters(boolean bUpdate) {
        if (this.m_cCamera != null) {
            return new CameraParamWrapper(this.m_cCamera);
        }
        Log.e("lgCamera", "GetParameters, m_cCamera==null!");
        return null;
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetParameters(CameraParamWrapper cParams) {
        Log.e("lgCamera", "SecCameraWrapper SetParameters");
        if (this.m_cCamera != null && cParams != null) {
            try {
                this.m_mtdSetParameters.invoke(this.m_cCamera, cParams.GetInternalObject());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void StartFaceDetection() {
        if (this.m_cClassFaceDetect != null) {
            try {
                this.m_mtdSetFaceDetectionListener.invoke(this.m_cCamera, this.m_cInvokeHandler);
                this.m_mtdStartFaceDetection.invoke(this.m_cCamera, null);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void StopFaceDetection() {
        try {
            if (this.m_cCamera != null) {
                this.m_mtdStopFaceDetection.invoke(this.m_cCamera, null);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void StartPreview() {
        try {
            this.m_mtdStartPreview.invoke(this.m_cCamera, null);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void StopPreview() {
        try {
            this.m_mtdStopPreview.invoke(this.m_cCamera, null);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void Lock() {
        try {
            this.m_mtdLock.invoke(this.m_cCamera, null);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void Unlock() {
        try {
            this.m_mtdUnLock.invoke(this.m_cCamera, null);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void TakePicture() {
        try {
            Method method = this.m_mtdTakePicture;
            Object obj = this.m_cCamera;
            Object[] objArr = new Object[4];
            objArr[3] = this.m_cInvokeHandler;
            method.invoke(obj, objArr);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetPreviewDisplay(SurfaceHolder holder) throws Exception {
        try {
            this.m_mtdSetDisplay.invoke(this.m_cCamera, holder);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetDisplayOrientation(int degrees) {
        try {
            this.m_mtdSetDisplayOrientation.invoke(this.m_cCamera, Integer.valueOf(degrees));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void cancelAutoFocus() {
        try {
            this.m_mtdCancelAutoFocus.invoke(this.m_cCamera, null);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void AutoFocus() {
        try {
            this.m_mtdAutoFocus.invoke(this.m_cCamera, this.m_cInvokeHandler);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void InitRecorder() throws Exception {
        this.m_cRecorder = this.m_cRecorderClass.newInstance();
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void PrepareRecorder() throws Exception {
        this.m_mtdPrepareRecorder.invoke(this.m_cRecorder, null);
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void ReleaseRecorder() {
        try {
            this.m_mtdReleaseRecorder.invoke(this.m_cRecorder, null);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        this.m_cRecorder = null;
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void ResetRecorder() {
        try {
            this.m_mtdResetRecorder.invoke(this.m_cRecorder, null);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetAudioChannels(int numChannels) {
        try {
            this.m_mtdSetAudioChannels.invoke(this.m_cRecorder, Integer.valueOf(numChannels));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetAudioEncoder(int audio_encoder) {
        try {
            this.m_mtdSetAudioEncoder.invoke(this.m_cRecorder, Integer.valueOf(audio_encoder));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetAudioEncodingBitRate(int bitRate) {
        try {
            this.m_mtdSetAudioBitrate.invoke(this.m_cRecorder, Integer.valueOf(bitRate));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetAudioSamplingRate(int samplingRate) {
        try {
            this.m_mtdSetAudioSampleRate.invoke(this.m_cRecorder, Integer.valueOf(samplingRate));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetAudioSource(int audio_source) {
        try {
            this.m_mtdSetAudioSource.invoke(this.m_cRecorder, Integer.valueOf(audio_source));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void LinkCamera() {
        if (this.m_cCamera != null) {
            try {
                this.m_mtdSetCamera.invoke(this.m_cRecorder, this.m_cCamera);
                this.m_mtdSetOnInfoListener.invoke(this.m_cRecorder, this.m_cInvokeHandler);
                this.m_mtdSetOnErrorListener.invoke(this.m_cRecorder, this.m_cInvokeHandler);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetMaxDuration(int max_duration_ms) {
        try {
            this.m_mtdSetMaxDuration.invoke(this.m_cRecorder, Integer.valueOf(max_duration_ms));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetMaxFileSize(long max_filesize_bytes) {
        try {
            this.m_mtdSetMaxSize.invoke(this.m_cRecorder, Long.valueOf(max_filesize_bytes));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetOrientationHint(int degrees) {
        try {
            this.m_mtdSetOrientation.invoke(this.m_cRecorder, Integer.valueOf(degrees));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetOutputFile(FileDescriptor fd) {
        try {
            this.m_mtdSetOutputFD.invoke(this.m_cRecorder, fd);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void SetOutputFile(String path) {
        try {
            this.m_mtdSetOutputPath.invoke(this.m_cRecorder, path);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetOutputFormat(int output_format) {
        try {
            this.m_mtdSetOutputFormat.invoke(this.m_cRecorder, Integer.valueOf(output_format));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetPreviewDisplay(Surface sv) {
        try {
            this.m_mtdSetPreviewDisplay.invoke(this.m_cRecorder, sv);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetVideoEncoder(int video_encoder) {
        try {
            this.m_mtdSetVideoEncoder.invoke(this.m_cRecorder, Integer.valueOf(video_encoder));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetVideoEncodingBitRate(int bitRate) {
        try {
            this.m_mtdSetVideoBitrate.invoke(this.m_cRecorder, Integer.valueOf(bitRate));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetVideoFrameRate(int rate) {
        try {
            this.m_mtdSetVideoFrameRate.invoke(this.m_cRecorder, Integer.valueOf(rate));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetVideoSize(int width, int height) {
        try {
            this.m_mtdSetVideoSize.invoke(this.m_cRecorder, Integer.valueOf(width), Integer.valueOf(height));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void SetVideoSource(int video_source) {
        try {
            this.m_mtdSetVideoSource.invoke(this.m_cRecorder, Integer.valueOf(video_source));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void StartRecording() throws Exception {
        this.m_mtdStart.invoke(this.m_cRecorder, null);
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void StopRecording() throws Exception {
        this.m_mtdStop.invoke(this.m_cRecorder, null);
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void PauseRecording() throws Exception {
        this.m_mtdPause.invoke(this.m_cRecorder, null);
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void ResumeRecording() throws Exception {
        this.m_mtdResume.invoke(this.m_cRecorder, null);
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public boolean IsPauseExists() {
        return (this.m_mtdPause == null || this.m_mtdResume == null) ? false : true;
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void StartPreviewCallback() {
        try {
            Log.e("lgCamera", "Starting preview callback");
            this.m_mtdSetPreviewCbk.invoke(this.m_cCamera, this.m_cInvokeHandler);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override // rubberbigpepper.CommonCtrl.CameraWrapper
    public void StopPreviewCallback() {
        try {
            this.m_mtdSetPreviewCbk.invoke(this.m_cCamera, new Object[1]);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}