package rubberbigpepper.CommonCtrl;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import com.android.camera.R;

/* loaded from: classes.dex */
public class ZoomView extends View {
    private static final int WIDTH = 10;
    private int mHeight;
    private int mMax;
    private int mProgress;
    private int mWidth;
    private BitmapShader m_cShaderZoomLine;
    private Paint m_cZoomLinePaint;
    private BitmapDrawable m_cZoomMinus;
    private Paint m_cZoomPaint;
    private BitmapDrawable m_cZoomPlus;
    private BitmapDrawable m_cZoomSlider;
    private float[] m_fBmpOffset;
    float m_fCircleSize;
    float m_fDPI;
    float m_fEndAngle;
    float m_fR;
    private float m_fSizeZoomLine;
    float m_fStartAngle;
    float m_fX0;
    float m_fX1;
    float m_fX2;
    float m_fX3;
    float m_fY0;
    float m_fY1;
    float m_fY2;
    float m_fY3;
    private OnZoomViewValueChanged m_iValueChanged;
    private int[] m_nBmpColors;
    private RectF m_rcLine;
    private RectF m_rcOval;

    /* loaded from: classes.dex */
    public interface OnZoomViewValueChanged {
        void onValueChanged(boolean z);
    }

    public ZoomView(Context context) {
        super(context);
        this.mWidth = 10;
        this.m_cZoomSlider = null;
        this.m_cZoomPlus = null;
        this.m_cZoomMinus = null;
        this.m_cShaderZoomLine = null;
        this.m_cZoomPaint = new Paint();
        this.m_cZoomLinePaint = new Paint();
        this.m_nBmpColors = null;
        this.m_fBmpOffset = null;
        this.m_rcOval = new RectF();
        this.m_rcLine = new RectF();
        this.mProgress = 0;
        this.mMax = 100;
        this.m_fX0 = 0.0f;
        this.m_fY0 = 0.0f;
        this.m_fX1 = 0.0f;
        this.m_fY1 = 0.0f;
        this.m_fX2 = 0.0f;
        this.m_fY2 = 0.0f;
        this.m_fX3 = 0.0f;
        this.m_fY3 = 0.0f;
        this.m_fR = 0.0f;
        this.m_fCircleSize = 10.0f;
        this.m_fDPI = 1.0f;
        this.m_fStartAngle = 0.0f;
        this.m_fEndAngle = 0.0f;
        this.m_fSizeZoomLine = 25.0f;
        this.m_iValueChanged = null;
    }

    private void InitPaint(Context context) {
        this.m_cZoomSlider = (BitmapDrawable) context.getResources().getDrawable(R.drawable.zoom_slider);
        this.m_cZoomPlus = (BitmapDrawable) context.getResources().getDrawable(R.drawable.plus);
        this.m_cZoomMinus = (BitmapDrawable) context.getResources().getDrawable(R.drawable.minus);
        this.m_fCircleSize = this.m_cZoomSlider.getBitmap().getWidth() * 0.5f;
        BitmapDrawable cDrawZoomLine = (BitmapDrawable) context.getResources().getDrawable(R.drawable.zoom_line);
        Bitmap cBmpZoomLine = cDrawZoomLine.getBitmap();
        this.m_nBmpColors = new int[cBmpZoomLine.getWidth()];
        this.m_fBmpOffset = new float[cBmpZoomLine.getWidth()];
        for (int n = 0; n < cBmpZoomLine.getWidth(); n++) {
            this.m_nBmpColors[n] = cBmpZoomLine.getPixel(n, 0);
        }
        DisplayMetrics outMetrics = new DisplayMetrics();
        WindowManager cWM = (WindowManager) getContext().getSystemService("window");
        cWM.getDefaultDisplay().getMetrics(outMetrics);
        this.m_fDPI = outMetrics.density / 4.0f;
        this.m_cZoomPaint.setStrokeWidth(this.m_fSizeZoomLine * this.m_fDPI);
        this.m_cZoomPaint.setStyle(Paint.Style.STROKE);
        this.m_cZoomPaint.setAntiAlias(true);
        this.m_cZoomLinePaint.setStrokeWidth(this.m_fSizeZoomLine * this.m_fDPI * 0.25f);
        this.m_cZoomLinePaint.setStyle(Paint.Style.STROKE);
        this.m_cZoomLinePaint.setAntiAlias(true);
        this.m_cZoomLinePaint.setColor(-1);
    }

    public ZoomView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mWidth = 10;
        this.m_cZoomSlider = null;
        this.m_cZoomPlus = null;
        this.m_cZoomMinus = null;
        this.m_cShaderZoomLine = null;
        this.m_cZoomPaint = new Paint();
        this.m_cZoomLinePaint = new Paint();
        this.m_nBmpColors = null;
        this.m_fBmpOffset = null;
        this.m_rcOval = new RectF();
        this.m_rcLine = new RectF();
        this.mProgress = 0;
        this.mMax = 100;
        this.m_fX0 = 0.0f;
        this.m_fY0 = 0.0f;
        this.m_fX1 = 0.0f;
        this.m_fY1 = 0.0f;
        this.m_fX2 = 0.0f;
        this.m_fY2 = 0.0f;
        this.m_fX3 = 0.0f;
        this.m_fY3 = 0.0f;
        this.m_fR = 0.0f;
        this.m_fCircleSize = 10.0f;
        this.m_fDPI = 1.0f;
        this.m_fStartAngle = 0.0f;
        this.m_fEndAngle = 0.0f;
        this.m_fSizeZoomLine = 25.0f;
        this.m_iValueChanged = null;
        InitPaint(context);
    }

    public ZoomView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mWidth = 10;
        this.m_cZoomSlider = null;
        this.m_cZoomPlus = null;
        this.m_cZoomMinus = null;
        this.m_cShaderZoomLine = null;
        this.m_cZoomPaint = new Paint();
        this.m_cZoomLinePaint = new Paint();
        this.m_nBmpColors = null;
        this.m_fBmpOffset = null;
        this.m_rcOval = new RectF();
        this.m_rcLine = new RectF();
        this.mProgress = 0;
        this.mMax = 100;
        this.m_fX0 = 0.0f;
        this.m_fY0 = 0.0f;
        this.m_fX1 = 0.0f;
        this.m_fY1 = 0.0f;
        this.m_fX2 = 0.0f;
        this.m_fY2 = 0.0f;
        this.m_fX3 = 0.0f;
        this.m_fY3 = 0.0f;
        this.m_fR = 0.0f;
        this.m_fCircleSize = 10.0f;
        this.m_fDPI = 1.0f;
        this.m_fStartAngle = 0.0f;
        this.m_fEndAngle = 0.0f;
        this.m_fSizeZoomLine = 25.0f;
        this.m_iValueChanged = null;
        InitPaint(context);
    }

    public void setOnZoomViewValueChanged(OnZoomViewValueChanged iListener) {
        this.m_iValueChanged = iListener;
    }

    public synchronized int getProgress() {
        return this.mProgress;
    }

    public synchronized void setProgress(int progress) {
        setProgress(progress, false);
    }

    private synchronized void setProgress(int progress, boolean bFromUser) {
        if (progress < 0) {
            progress = 0;
        }
        if (progress > this.mMax) {
            progress = this.mMax;
        }
        if (progress != this.mProgress) {
            this.mProgress = progress;
            refreshProgress();
        }
        if (this.m_iValueChanged != null) {
            this.m_iValueChanged.onValueChanged(bFromUser);
        }
    }

    public synchronized void setMax(int max) {
        this.mMax = max;
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (getVisibility() == 0) {
            DrawLineZoom(canvas);
        }
    }

    protected void DrawLineZoom(Canvas canvas) {
        float fX = 0.5f * this.mWidth;
        float fY = this.m_rcLine.bottom - ((this.m_rcLine.height() * this.mProgress) / this.mMax);
        canvas.drawLine(fX, this.m_rcLine.top, fX, this.m_rcLine.bottom, this.m_cZoomLinePaint);
        this.m_cZoomSlider.setBounds(new Rect((int) (fX - (this.m_fCircleSize * 0.5f)), (int) (fY - (this.m_fCircleSize * 0.5f)), (int) ((this.m_fCircleSize * 0.5f) + fX), (int) ((this.m_fCircleSize * 0.5f) + fY)));
        this.m_cZoomSlider.draw(canvas);
        this.m_cZoomMinus.draw(canvas);
        this.m_cZoomPlus.draw(canvas);
    }

    protected void DrawEllipseZoom(Canvas canvas) {
        this.m_cZoomMinus.draw(canvas);
        this.m_cZoomPlus.draw(canvas);
        canvas.drawArc(this.m_rcOval, (float) ((this.m_fStartAngle * 180.0f) / 3.141592653589793d), (float) (((this.m_fEndAngle - this.m_fStartAngle) * 180.0f) / 3.141592653589793d), false, this.m_cZoomPaint);
        float fAngle = this.m_fStartAngle + (((this.m_fEndAngle - this.m_fStartAngle) * this.mProgress) / this.mMax);
        float fCX = (float) ((this.m_fR * Math.cos(fAngle)) + this.m_fX0);
        float fCY = (float) ((this.m_fR * Math.sin(fAngle)) + this.m_fY0);
        this.m_cZoomSlider.setBounds(new Rect((int) (fCX - this.m_fCircleSize), (int) (fCY - this.m_fCircleSize), (int) (this.m_fCircleSize + fCX), (int) (this.m_fCircleSize + fCY)));
        this.m_cZoomSlider.draw(canvas);
    }

    @Override // android.view.View
    protected void onMeasure(int widthSpecId, int heightSpecId) {
        this.mHeight = View.MeasureSpec.getSize(heightSpecId);
        this.mWidth = View.MeasureSpec.getSize(widthSpecId);
        setMeasuredDimension(this.mWidth, this.mHeight);
        int nWidth = this.m_cZoomPlus.getBitmap().getWidth();
        int nHeight = this.m_cZoomPlus.getBitmap().getHeight();
        this.m_fX2 = 0.0f + this.m_fCircleSize;
        this.m_fY2 = this.mHeight * 0.5f;
        this.m_fX1 = this.mWidth - this.m_fCircleSize;
        this.m_fY1 = this.mHeight - this.m_fCircleSize;
        this.m_fX3 = this.mWidth - this.m_fCircleSize;
        this.m_fY3 = 0.0f + this.m_fCircleSize;
        float fA = Math.abs(this.m_fY2 - this.m_fY1);
        float fB = Math.abs(this.m_fX3 - this.m_fX2);
        this.m_fR = (0.5f * ((fA * fA) + (fB * fB))) / fB;
        this.m_fX0 = this.m_fX2 + this.m_fR;
        this.m_fY0 = this.m_fY2;
        this.m_rcOval.left = this.m_fX0 - this.m_fR;
        this.m_rcOval.top = this.m_fY0 - this.m_fR;
        this.m_rcOval.right = this.m_fX0 + this.m_fR;
        this.m_rcOval.bottom = this.m_fY0 + this.m_fR;
        int nOffset = (int) (this.m_fR - (this.m_fSizeZoomLine * ((int) (this.m_fR / this.m_fSizeZoomLine))));
        for (int n = 0; n < this.m_fBmpOffset.length; n++) {
            this.m_fBmpOffset[n] = (nOffset + (this.m_fDPI * n)) / this.m_fBmpOffset.length;
        }
        RadialGradient cRadGrad = new RadialGradient(this.m_fX0, this.m_fY0, this.m_fSizeZoomLine, this.m_nBmpColors, this.m_fBmpOffset, Shader.TileMode.REPEAT);
        this.m_cZoomPaint.setShader(cRadGrad);
        float fAngle = (float) Math.asin(fA / this.m_fR);
        this.m_fStartAngle = (float) (3.141592653589793d - fAngle);
        this.m_fEndAngle = (float) (3.141592653589793d + fAngle);
        Rect rcPlus = new Rect(0, 0, nWidth, nHeight);
        this.m_cZoomPlus.setBounds(rcPlus);
        int nWidth2 = this.m_cZoomMinus.getBitmap().getWidth();
        int nHeight2 = this.m_cZoomMinus.getBitmap().getHeight();
        Rect rcPlus2 = new Rect(0, this.mHeight - nHeight2, nWidth2, this.mHeight);
        this.m_cZoomMinus.setBounds(rcPlus2);
        this.m_rcLine = new RectF(0.0f, nHeight2, this.mWidth, this.mHeight - nHeight2);
    }

    private synchronized void refreshProgress() {
        invalidate();
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent event) {
        float fAngle = (float) (((this.m_fEndAngle - this.m_fStartAngle) * 0.5f) - Math.asin((event.getY() - this.m_fY0) / this.m_fR));
        int nValue = (int) ((this.mMax * fAngle) / (this.m_fEndAngle - this.m_fStartAngle));
        setProgress(nValue, true);
        return true;
    }
}