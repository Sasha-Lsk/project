package rubberbigpepper.CommonCtrl;

import android.annotation.TargetApi;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import com.android.camera.CameraView;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class DocumentFile {
    static final String TAG = "DocumentFile";
    private static String[] m_strExtSdCardPath = null;
    private Context mContext;
    private final DocumentFile mParent;
    private Uri mUri;

    DocumentFile(DocumentFile parent) {
        this.mParent = parent;
    }

    DocumentFile(DocumentFile parent, Context context, Uri uri) {
        this.mParent = parent;
        this.mContext = context;
        this.mUri = uri;
    }

    public static boolean MkDirs(String strFolder, Context context, Uri treeUri) {
        return MkDirs(new File(strFolder), context, treeUri);
    }

    public static boolean MkDirs(File cDir, Context context, Uri treeUri) {
        try {
            if (cDir.mkdirs()) {
                return true;
            }
        } catch (Exception e) {
        }
        DocumentFile cDocFile = getDocumentFile(context, cDir, true, treeUri);
        if (cDocFile != null && cDocFile.isDirectory()) {
            return cDocFile.exists();
        }
        return false;
    }

    public static boolean Delete(String strFile, Context context, Uri treeUri) {
        return Delete(new File(strFile), context, treeUri);
    }

    public static boolean Delete(File cFile, Context context, Uri treeUri) {
        try {
            if (cFile.delete()) {
                return true;
            }
        } catch (Exception e) {
        }
        DocumentFile cDocFile = getDocumentFile(context, cFile, false, treeUri);
        if (cDocFile != null) {
            return cDocFile.delete();
        }
        return false;
    }

    public static FileDescriptor WriteFile(String strFile, Context context, Uri treeUri) {
        File cFile = new File(strFile);
        try {
            cFile.createNewFile();
            FileOutputStream cStream = new FileOutputStream(cFile);
            return cStream.getFD();
        } catch (Exception e) {
            try {
                DocumentFile file = getDocumentFile(context, cFile, false, treeUri);
                return context.getContentResolver().openFileDescriptor(file.getUri(), "w").getFileDescriptor();
            } catch (Exception e2) {
                return null;
            }
        }
    }

    private static DocumentFile getDocumentFile(Context cContext, File file, boolean isDirectory, Uri treeUri) {
        DocumentFile document = null;
        String baseFolder = getExtSdCardFolder(cContext, file);
        if (baseFolder != null) {
            try {
                String fullPath = file.getCanonicalPath();
                String relativePath = fullPath.substring(baseFolder.length() + 1);
                if (treeUri != null) {
                    document = fromTreeUri(cContext, treeUri);
                    String[] parts = relativePath.split("\\/");
                    for (int i = 0; i < parts.length; i++) {
                        Log.e("lgCamera", parts[i]);
                        DocumentFile nextDocument = document.findFile(parts[i]);
                        if (nextDocument == null) {
                            if (i < parts.length - 1 || isDirectory) {
                                nextDocument = document.createDirectory(parts[i]);
                            } else {
                                nextDocument = document.createFile("image", parts[i]);
                            }
                        }
                        document = nextDocument;
                    }
                }
            } catch (IOException e) {
            }
        }
        return document;
    }

    private static String getExtSdCardFolder(Context cContext, File file) {
        String[] extSdPaths = getExtSdCardPaths(cContext);
        for (int i = 0; i < extSdPaths.length; i++) {
            try {
                if (file.getCanonicalPath().startsWith(extSdPaths[i])) {
                    return extSdPaths[i];
                }
            } catch (IOException e) {
                return null;
            }
        }
        return null;
    }

    @TargetApi(CameraView.PANORAMA_STARTED)
    private static String[] getExtSdCardPaths(Context cContext) {
        File[] externalFilesDirs;
        int index;
        if (m_strExtSdCardPath != null) {
            return m_strExtSdCardPath;
        }
        List<String> paths = new ArrayList<>();
        for (File file : cContext.getExternalFilesDirs("external")) {
            if (file != null && !file.equals(cContext.getExternalFilesDir("external")) && (index = file.getAbsolutePath().lastIndexOf("/Android/data")) >= 0) {
                String path = file.getAbsolutePath().substring(0, index);
                try {
                    path = new File(path).getCanonicalPath();
                } catch (IOException e) {
                }
                paths.add(path);
            }
        }
        m_strExtSdCardPath = (String[]) paths.toArray(new String[paths.size()]);
        return m_strExtSdCardPath;
    }

    public static DocumentFile fromTreeUri(Context context, Uri treeUri) {
        int version = Build.VERSION.SDK_INT;
        if (version >= 21) {
            return new DocumentFile(null, context, DocumentsContractApi21.prepareTreeUri(treeUri));
        }
        return null;
    }

    public static boolean isDocumentUri(Context context, Uri uri) {
        int version = Build.VERSION.SDK_INT;
        if (version >= 19) {
            return DocumentsContractApi19.isDocumentUri(context, uri);
        }
        return false;
    }

    public DocumentFile createFile(String mimeType, String displayName) {
        Uri result = DocumentsContractApi21.createFile(this.mContext, this.mUri, mimeType, displayName);
        if (result != null) {
            return new DocumentFile(this, this.mContext, result);
        }
        return null;
    }

    public DocumentFile createDirectory(String displayName) {
        Uri result = DocumentsContractApi21.createDirectory(this.mContext, this.mUri, displayName);
        if (result != null) {
            return new DocumentFile(this, this.mContext, result);
        }
        return null;
    }

    public Uri getUri() {
        return this.mUri;
    }

    public String getName() {
        return DocumentsContractApi19.getName(this.mContext, this.mUri);
    }

    public String getType() {
        return DocumentsContractApi19.getType(this.mContext, this.mUri);
    }

    public DocumentFile getParentFile() {
        return this.mParent;
    }

    public boolean isDirectory() {
        return DocumentsContractApi19.isDirectory(this.mContext, this.mUri);
    }

    public boolean isFile() {
        return DocumentsContractApi19.isFile(this.mContext, this.mUri);
    }

    public long lastModified() {
        return DocumentsContractApi19.lastModified(this.mContext, this.mUri);
    }

    public long length() {
        return DocumentsContractApi19.length(this.mContext, this.mUri);
    }

    public boolean canRead() {
        return DocumentsContractApi19.canRead(this.mContext, this.mUri);
    }

    public boolean canWrite() {
        return DocumentsContractApi19.canWrite(this.mContext, this.mUri);
    }

    public boolean delete() {
        return DocumentsContractApi19.delete(this.mContext, this.mUri);
    }

    public boolean exists() {
        return DocumentsContractApi19.exists(this.mContext, this.mUri);
    }

    public DocumentFile[] listFiles() {
        Uri[] result = DocumentsContractApi21.listFiles(this.mContext, this.mUri);
        DocumentFile[] resultFiles = new DocumentFile[result.length];
        for (int i = 0; i < result.length; i++) {
            resultFiles[i] = new DocumentFile(this, this.mContext, result[i]);
        }
        return resultFiles;
    }

    public DocumentFile findFile(String displayName) {
        Uri uriFile = DocumentsContractApi21.findFile(this.mContext, this.mUri, displayName);
        if (uriFile != null) {
            return new DocumentFile(this, this.mContext, uriFile);
        }
        return null;
    }

    public boolean renameTo(String displayName) {
        Uri result = DocumentsContractApi21.renameTo(this.mContext, this.mUri, displayName);
        if (result != null) {
            this.mUri = result;
            return true;
        }
        return false;
    }
}