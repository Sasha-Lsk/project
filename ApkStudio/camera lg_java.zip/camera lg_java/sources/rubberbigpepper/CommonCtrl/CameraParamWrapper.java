package rubberbigpepper.CommonCtrl;

import android.graphics.Point;
import android.graphics.Rect;
import android.util.Log;
import dalvik.system.PathClassLoader;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Vector;

/* loaded from: classes.dex */
public class CameraParamWrapper {
    private Class<?> m_cClassSecCamArea;
    private Method m_mtdFlatten;
    private Method m_mtdGetAB;
    private Method m_mtdGetAELock;
    private Method m_mtdGetCE;
    private Method m_mtdGetEC;
    private Method m_mtdGetECStep;
    private Method m_mtdGetFM;
    private Method m_mtdGetFlash;
    private Method m_mtdGetInt;
    private Method m_mtdGetMaxAreas;
    private Method m_mtdGetMaxEC;
    private Method m_mtdGetMaxFaces;
    private Method m_mtdGetMaxFocuses;
    private Method m_mtdGetMaxZoom;
    private Method m_mtdGetMinEC;
    private Method m_mtdGetPicSize;
    private Method m_mtdGetPrefSize;
    private Method m_mtdGetPrevFPS;
    private Method m_mtdGetPrevSize;
    private Method m_mtdGetSM;
    private Method m_mtdGetStr;
    private Method m_mtdGetSuppAB;
    private Method m_mtdGetSuppCE;
    private Method m_mtdGetSuppFM;
    private Method m_mtdGetSuppFlashes;
    private Method m_mtdGetSuppPicSizes;
    private Method m_mtdGetSuppPrevSizes;
    private Method m_mtdGetSuppSM;
    private Method m_mtdGetSuppVidSizes;
    private Method m_mtdGetSuppWB;
    private Method m_mtdGetWB;
    private Method m_mtdGetWBLock;
    private Method m_mtdGetZoom;
    private Method m_mtdIsAELockSupp;
    private Method m_mtdIsVidSnapSupp;
    private Method m_mtdIsVidStabSupp;
    private Method m_mtdIsWBLockSupp;
    private Method m_mtdIsZoomSupp;
    private Method m_mtdRemove;
    private Method m_mtdRemoveGPS;
    private Method m_mtdSetAB;
    private Method m_mtdSetAELock;
    private Method m_mtdSetCE;
    private Method m_mtdSetEC;
    private Method m_mtdSetFM;
    private Method m_mtdSetFlash;
    private Method m_mtdSetFocusAreas;
    private Method m_mtdSetGpsAlt;
    private Method m_mtdSetGpsLat;
    private Method m_mtdSetGpsLong;
    private Method m_mtdSetGpsMethod;
    private Method m_mtdSetGpsTime;
    private Method m_mtdSetInt;
    private Method m_mtdSetJpgQual;
    private Method m_mtdSetPicFmt;
    private Method m_mtdSetPicSize;
    private Method m_mtdSetPrevFPS;
    private Method m_mtdSetPrevSize;
    private Method m_mtdSetPrvFmt;
    private Method m_mtdSetRecHint;
    private Method m_mtdSetRot;
    private Method m_mtdSetSM;
    private Method m_mtdSetStr;
    private Method m_mtdSetVidStab;
    private Method m_mtdSetWB;
    private Method m_mtdSetWBLock;
    private Method m_mtdSetZoom;
    private Method m_mtdUnFlatten;
    private Object m_oParams;

    public CameraParamWrapper(Object cCamera) {
        this.m_oParams = null;
        this.m_cClassSecCamArea = null;
        this.m_mtdFlatten = null;
        this.m_mtdUnFlatten = null;
        this.m_mtdGetStr = null;
        this.m_mtdSetStr = null;
        this.m_mtdGetInt = null;
        this.m_mtdSetInt = null;
        this.m_mtdGetAB = null;
        this.m_mtdSetAB = null;
        this.m_mtdGetAELock = null;
        this.m_mtdSetAELock = null;
        this.m_mtdGetWBLock = null;
        this.m_mtdSetWBLock = null;
        this.m_mtdGetCE = null;
        this.m_mtdSetCE = null;
        this.m_mtdGetEC = null;
        this.m_mtdGetMaxEC = null;
        this.m_mtdGetMinEC = null;
        this.m_mtdGetECStep = null;
        this.m_mtdSetEC = null;
        this.m_mtdGetFlash = null;
        this.m_mtdSetFlash = null;
        this.m_mtdGetFM = null;
        this.m_mtdSetFM = null;
        this.m_mtdGetSM = null;
        this.m_mtdSetSM = null;
        this.m_mtdGetWB = null;
        this.m_mtdSetWB = null;
        this.m_mtdGetMaxFaces = null;
        this.m_mtdGetMaxFocuses = null;
        this.m_mtdGetMaxAreas = null;
        this.m_mtdGetMaxZoom = null;
        this.m_mtdGetZoom = null;
        this.m_mtdSetZoom = null;
        this.m_mtdGetPicSize = null;
        this.m_mtdSetPicSize = null;
        this.m_mtdGetPrefSize = null;
        this.m_mtdGetPrevSize = null;
        this.m_mtdSetPrevSize = null;
        this.m_mtdGetSuppAB = null;
        this.m_mtdGetSuppCE = null;
        this.m_mtdGetSuppFlashes = null;
        this.m_mtdGetSuppFM = null;
        this.m_mtdGetSuppSM = null;
        this.m_mtdGetSuppWB = null;
        this.m_mtdGetSuppPicSizes = null;
        this.m_mtdGetSuppPrevSizes = null;
        this.m_mtdGetSuppVidSizes = null;
        this.m_mtdIsAELockSupp = null;
        this.m_mtdIsWBLockSupp = null;
        this.m_mtdIsVidSnapSupp = null;
        this.m_mtdIsVidStabSupp = null;
        this.m_mtdIsZoomSupp = null;
        this.m_mtdRemove = null;
        this.m_mtdRemoveGPS = null;
        this.m_mtdSetRecHint = null;
        this.m_mtdGetPrevFPS = null;
        this.m_mtdSetPrevFPS = null;
        this.m_mtdSetPicFmt = null;
        this.m_mtdSetRot = null;
        this.m_mtdSetVidStab = null;
        this.m_mtdSetJpgQual = null;
        this.m_mtdSetGpsAlt = null;
        this.m_mtdSetGpsLat = null;
        this.m_mtdSetGpsLong = null;
        this.m_mtdSetGpsTime = null;
        this.m_mtdSetGpsMethod = null;
        this.m_mtdSetFocusAreas = null;
        this.m_mtdSetPrvFmt = null;
        try {
            PathClassLoader cClassLoader = new PathClassLoader("/system/framework/seccamera.jar", ClassLoader.getSystemClassLoader());
            this.m_cClassSecCamArea = cClassLoader.loadClass("com.sec.android.seccamera.SecCamera$Area");
        } catch (Exception e) {
        }
        this.m_oParams = InvokeHelper.InvokeMethodFast(cCamera, "getParameters");
        try {
            Class<?> clsParam = this.m_oParams.getClass();
            this.m_mtdFlatten = GetDeclaredMethod(clsParam, "flatten", null);
            this.m_mtdUnFlatten = GetDeclaredMethod(clsParam, "unflatten", new Class[]{String.class});
            this.m_mtdGetStr = GetDeclaredMethod(clsParam, "get", new Class[]{String.class});
            this.m_mtdSetStr = GetDeclaredMethod(clsParam, "set", new Class[]{String.class, String.class});
            this.m_mtdGetInt = GetDeclaredMethod(clsParam, "getInt", new Class[]{String.class});
            this.m_mtdSetInt = GetDeclaredMethod(clsParam, "set", new Class[]{String.class, Integer.TYPE});
            this.m_mtdGetAB = GetDeclaredMethod(clsParam, "getAntibanding", null);
            this.m_mtdSetAB = GetDeclaredMethod(clsParam, "setAntibanding", new Class[]{String.class});
            this.m_mtdGetAELock = GetDeclaredMethod(clsParam, "getAutoExposureLock", null);
            this.m_mtdSetAELock = GetDeclaredMethod(clsParam, "setAutoExposureLock", new Class[]{Boolean.TYPE});
            this.m_mtdGetWBLock = GetDeclaredMethod(clsParam, "getAutoWhiteBalanceLock", null);
            this.m_mtdSetWBLock = GetDeclaredMethod(clsParam, "setAutoWhiteBalanceLock", new Class[]{Boolean.TYPE});
            this.m_mtdGetCE = GetDeclaredMethod(clsParam, "getColorEffect", null);
            this.m_mtdSetCE = GetDeclaredMethod(clsParam, "setColorEffect", new Class[]{String.class});
            this.m_mtdGetFlash = GetDeclaredMethod(clsParam, "getFlashMode", null);
            this.m_mtdSetFlash = GetDeclaredMethod(clsParam, "setFlashMode", new Class[]{String.class});
            this.m_mtdGetFM = GetDeclaredMethod(clsParam, "getFocusMode", null);
            this.m_mtdSetFM = GetDeclaredMethod(clsParam, "setFocusMode", new Class[]{String.class});
            this.m_mtdGetSM = GetDeclaredMethod(clsParam, "getSceneMode", null);
            this.m_mtdSetSM = GetDeclaredMethod(clsParam, "setSceneMode", new Class[]{String.class});
            this.m_mtdGetWB = GetDeclaredMethod(clsParam, "getWhiteBalance", null);
            this.m_mtdSetWB = GetDeclaredMethod(clsParam, "setWhiteBalance", new Class[]{String.class});
            this.m_mtdGetEC = GetDeclaredMethod(clsParam, "getExposureCompensation", null);
            this.m_mtdGetMaxEC = GetDeclaredMethod(clsParam, "getMaxExposureCompensation", null);
            this.m_mtdGetMinEC = GetDeclaredMethod(clsParam, "getMinExposureCompensation", null);
            this.m_mtdGetECStep = GetDeclaredMethod(clsParam, "getExposureCompensationStep", null);
            this.m_mtdSetEC = GetDeclaredMethod(clsParam, "setExposureCompensation", new Class[]{Integer.TYPE});
            this.m_mtdGetMaxFaces = GetDeclaredMethod(clsParam, "getMaxNumDetectedFaces", null);
            this.m_mtdGetMaxFocuses = GetDeclaredMethod(clsParam, "getMaxNumFocusAreas", null);
            this.m_mtdGetMaxAreas = GetDeclaredMethod(clsParam, "getMaxNumMeteringAreas", null);
            this.m_mtdGetMaxZoom = GetDeclaredMethod(clsParam, "getMaxZoom", null);
            this.m_mtdGetZoom = GetDeclaredMethod(clsParam, "getZoom", null);
            this.m_mtdSetZoom = GetDeclaredMethod(clsParam, "setZoom", new Class[]{Integer.TYPE});
            this.m_mtdGetPicSize = GetDeclaredMethod(clsParam, "getPictureSize", null);
            this.m_mtdSetPicSize = GetDeclaredMethod(clsParam, "setPictureSize", new Class[]{Integer.TYPE, Integer.TYPE});
            this.m_mtdGetPrefSize = GetDeclaredMethod(clsParam, "getPreferredPreviewSizeForVideo", null);
            this.m_mtdGetPrevSize = GetDeclaredMethod(clsParam, "getPreviewSize", null);
            this.m_mtdSetPrevSize = GetDeclaredMethod(clsParam, "setPreviewSize", new Class[]{Integer.TYPE, Integer.TYPE});
            this.m_mtdGetSuppAB = GetDeclaredMethod(clsParam, "getSupportedAntibanding", null);
            this.m_mtdGetSuppCE = GetDeclaredMethod(clsParam, "getSupportedColorEffects", null);
            this.m_mtdGetSuppFlashes = GetDeclaredMethod(clsParam, "getSupportedFlashModes", null);
            this.m_mtdGetSuppFM = GetDeclaredMethod(clsParam, "getSupportedFocusModes", null);
            this.m_mtdGetSuppSM = GetDeclaredMethod(clsParam, "getSupportedSceneModes", null);
            this.m_mtdGetSuppWB = GetDeclaredMethod(clsParam, "getSupportedWhiteBalance", null);
            this.m_mtdGetSuppPicSizes = GetDeclaredMethod(clsParam, "getSupportedPictureSizes", null);
            this.m_mtdGetSuppPrevSizes = GetDeclaredMethod(clsParam, "getSupportedPreviewSizes", null);
            this.m_mtdGetSuppVidSizes = GetDeclaredMethod(clsParam, "getSupportedVideoSizes", null);
            this.m_mtdIsAELockSupp = GetDeclaredMethod(clsParam, "isAutoExposureLockSupported", null);
            this.m_mtdIsWBLockSupp = GetDeclaredMethod(clsParam, "isAutoWhiteBalanceLockSupported", null);
            this.m_mtdIsVidSnapSupp = GetDeclaredMethod(clsParam, "isVideoSnapshotSupported", null);
            this.m_mtdIsVidStabSupp = GetDeclaredMethod(clsParam, "isVideoStabilizationSupported", null);
            this.m_mtdIsZoomSupp = GetDeclaredMethod(clsParam, "isZoomSupported", null);
            this.m_mtdRemove = GetDeclaredMethod(clsParam, "remove", new Class[]{String.class});
            this.m_mtdRemoveGPS = GetDeclaredMethod(clsParam, "removeGpsData", null);
            this.m_mtdSetRecHint = GetDeclaredMethod(clsParam, "setAutoExposureLock", new Class[]{Boolean.TYPE});
            this.m_mtdGetPrevFPS = GetDeclaredMethod(clsParam, "getPreviewFrameRate", null);
            this.m_mtdSetPrevFPS = GetDeclaredMethod(clsParam, "setPreviewFrameRate", new Class[]{Integer.TYPE});
            this.m_mtdSetPicFmt = GetDeclaredMethod(clsParam, "setPictureFormat", new Class[]{Integer.TYPE});
            this.m_mtdSetRot = GetDeclaredMethod(clsParam, "setRotation", new Class[]{Integer.TYPE});
            this.m_mtdSetVidStab = GetDeclaredMethod(clsParam, "setVideoStabilization", new Class[]{Boolean.TYPE});
            this.m_mtdSetJpgQual = GetDeclaredMethod(clsParam, "setJpegQuality", new Class[]{Integer.TYPE});
            this.m_mtdSetGpsAlt = GetDeclaredMethod(clsParam, "setGpsAltitude", new Class[]{Double.TYPE});
            this.m_mtdSetGpsLat = GetDeclaredMethod(clsParam, "setGpsLatitude", new Class[]{Double.TYPE});
            this.m_mtdSetGpsLong = GetDeclaredMethod(clsParam, "setGpsLongitude", new Class[]{Double.TYPE});
            this.m_mtdSetGpsTime = GetDeclaredMethod(clsParam, "setGpsTimestamp", new Class[]{Long.TYPE});
            this.m_mtdSetGpsMethod = GetDeclaredMethod(clsParam, "setGpsProcessingMethod", new Class[]{String.class});
            this.m_mtdSetFocusAreas = GetDeclaredMethod(clsParam, "setFocusAreas", new Class[]{List.class});
            this.m_mtdSetPrvFmt = GetDeclaredMethod(clsParam, "setPreviewFormat", new Class[]{Integer.TYPE});
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void ReReadParams(Object cCamera) {
        this.m_oParams = InvokeHelper.InvokeMethodFast(cCamera, "getParameters");
    }

    private Method GetDeclaredMethod(Class<?> cClass, String strMethodName, Class<?>[] clsArr) {
        try {
            Method cMethod = cClass.getDeclaredMethod(strMethodName, clsArr);
            cMethod.setAccessible(true);
            return cMethod;
        } catch (Exception e) {
            return null;
        }
    }

    public Object GetInternalObject() {
        return this.m_oParams;
    }

    public void setJpegQuality(int quality) {
        try {
            if (this.m_mtdSetJpgQual != null) {
                this.m_mtdSetJpgQual.invoke(this.m_oParams, Integer.valueOf(quality));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public int getInt(String key) {
        try {
            if (this.m_mtdGetInt != null) {
                return ((Integer) this.m_mtdGetInt.invoke(this.m_oParams, key)).intValue();
            }
        } catch (Exception e) {
        }
        return 0;
    }

    public String get(String key) {
        try {
            if (this.m_mtdGetStr != null) {
                return (String) this.m_mtdGetStr.invoke(this.m_oParams, key);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public void set(String key, int value) {
        try {
            if (this.m_mtdSetInt != null) {
                this.m_mtdSetInt.invoke(this.m_oParams, key, Integer.valueOf(value));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void set(String key, String value) {
        try {
            if (this.m_mtdSetStr != null) {
                this.m_mtdSetStr.invoke(this.m_oParams, key, value);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void setPreviewFrameRate(int fps) {
        try {
            if (this.m_mtdSetPrevFPS != null) {
                this.m_mtdSetPrevFPS.invoke(this.m_oParams, Integer.valueOf(fps));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void setColorEffect(String value) {
        try {
            if (this.m_mtdSetCE != null) {
                this.m_mtdSetCE.invoke(this.m_oParams, value);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void setFocusMode(String value) {
        try {
            if (this.m_mtdSetFM != null) {
                this.m_mtdSetFM.invoke(this.m_oParams, value);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void setAntibanding(String value) {
        try {
            if (this.m_mtdSetAB != null) {
                this.m_mtdSetAB.invoke(this.m_oParams, value);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void setFlashMode(String value) {
        try {
            if (this.m_mtdSetFlash != null) {
                this.m_mtdSetFlash.invoke(this.m_oParams, value);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void setSceneMode(String value) {
        try {
            if (this.m_mtdSetSM != null) {
                this.m_mtdSetSM.invoke(this.m_oParams, value);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void setWhiteBalance(String value) {
        try {
            if (this.m_mtdSetWB != null) {
                this.m_mtdSetWB.invoke(this.m_oParams, value);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void setExposureCompensation(int value) {
        try {
            if (this.m_mtdSetEC != null) {
                this.m_mtdSetEC.invoke(this.m_oParams, Integer.valueOf(value));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public String flatten() {
        try {
            if (this.m_mtdFlatten != null) {
                return (String) this.m_mtdFlatten.invoke(this.m_oParams, null);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "";
    }

    public void setRotation(int rotation) {
        try {
            if (this.m_mtdSetRot != null) {
                this.m_mtdSetRot.invoke(this.m_oParams, Integer.valueOf(rotation));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void setPictureFormat(int pixel_format) {
        try {
            if (this.m_mtdSetPicFmt != null) {
                this.m_mtdSetPicFmt.invoke(this.m_oParams, Integer.valueOf(pixel_format));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void setPreviewFormat(int pixel_format) {
        try {
            if (this.m_mtdSetPrvFmt != null) {
                this.m_mtdSetPrvFmt.invoke(this.m_oParams, Integer.valueOf(pixel_format));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public String getFocusMode() {
        try {
            if (this.m_mtdGetFM != null) {
                return (String) this.m_mtdGetFM.invoke(this.m_oParams, null);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "";
    }

    public String getFlashMode() {
        try {
            if (this.m_mtdGetFlash != null) {
                return (String) this.m_mtdGetFlash.invoke(this.m_oParams, null);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "";
    }

    public String getSceneMode() {
        try {
            if (this.m_mtdGetSM != null) {
                return (String) this.m_mtdGetSM.invoke(this.m_oParams, null);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "";
    }

    public String getWhiteBalance() {
        try {
            if (this.m_mtdGetWB != null) {
                return (String) this.m_mtdGetWB.invoke(this.m_oParams, null);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "";
    }

    public String getColorEffect() {
        try {
            if (this.m_mtdGetCE != null) {
                return (String) this.m_mtdGetCE.invoke(this.m_oParams, null);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "";
    }

    public String getAntibanding() {
        try {
            if (this.m_mtdGetAB != null) {
                return (String) this.m_mtdGetAB.invoke(this.m_oParams, null);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "";
    }

    public int getMaxZoom() {
        try {
            if (this.m_mtdGetMaxZoom != null) {
                return ((Integer) this.m_mtdGetMaxZoom.invoke(this.m_oParams, null)).intValue();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return 0;
    }

    public void setZoom(int value) {
        try {
            if (this.m_mtdSetZoom != null) {
                this.m_mtdSetZoom.invoke(this.m_oParams, Integer.valueOf(value));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public int getZoom() {
        try {
            if (this.m_mtdGetZoom != null) {
                return ((Integer) this.m_mtdGetZoom.invoke(this.m_oParams, null)).intValue();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return 0;
    }

    public int getPreviewFrameRate() {
        try {
            if (this.m_mtdGetPrevFPS != null) {
                return ((Integer) this.m_mtdGetPrevFPS.invoke(this.m_oParams, null)).intValue();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return 0;
    }

    public void setPictureSize(int width, int height) {
        try {
            if (this.m_mtdSetPicSize != null) {
                this.m_mtdSetPicSize.invoke(this.m_oParams, Integer.valueOf(width), Integer.valueOf(height));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void setPreviewSize(int width, int height) {
        try {
            if (this.m_mtdSetPrevSize != null) {
                this.m_mtdSetPrevSize.invoke(this.m_oParams, Integer.valueOf(width), Integer.valueOf(height));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public Point getPictureSize() {
        try {
            if (this.m_mtdGetPicSize != null) {
                Object szSize = this.m_mtdGetPicSize.invoke(this.m_oParams, null);
                return new Point(InvokeHelper.GetFieldIntValue(szSize, "width"), InvokeHelper.GetFieldIntValue(szSize, "height"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public void setGpsAltitude(double altitude) {
        try {
            if (this.m_mtdSetGpsAlt != null) {
                this.m_mtdSetGpsAlt.invoke(this.m_oParams, Double.valueOf(altitude));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void setGpsLatitude(double latitude) {
        try {
            if (this.m_mtdSetGpsLat != null) {
                this.m_mtdSetGpsLat.invoke(this.m_oParams, Double.valueOf(latitude));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void setGpsLongitude(double longitude) {
        try {
            if (this.m_mtdSetGpsLong != null) {
                this.m_mtdSetGpsLong.invoke(this.m_oParams, Double.valueOf(longitude));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void setGpsTimestamp(long timestamp) {
        try {
            if (this.m_mtdSetGpsTime != null) {
                this.m_mtdSetGpsTime.invoke(this.m_oParams, Long.valueOf(timestamp));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void setGpsProcessingMethod(String strProvider) {
        try {
            if (this.m_mtdSetGpsMethod != null) {
                this.m_mtdSetGpsMethod.invoke(this.m_oParams, strProvider);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public List<String> getSupportedFlashModes() {
        try {
            if (this.m_mtdGetSuppFlashes != null) {
                return (List) this.m_mtdGetSuppFlashes.invoke(this.m_oParams, null);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public List<String> getSupportedAntibanding() {
        try {
            if (this.m_mtdGetSuppAB != null) {
                return (List) this.m_mtdGetSuppAB.invoke(this.m_oParams, null);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public List<String> getSupportedColorEffects() {
        try {
            if (this.m_mtdGetSuppCE != null) {
                return (List) this.m_mtdGetSuppCE.invoke(this.m_oParams, null);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public List<String> getSupportedFocusModes() {
        try {
            if (this.m_mtdGetSuppFM != null) {
                return (List) this.m_mtdGetSuppFM.invoke(this.m_oParams, null);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public List<String> getSupportedSceneModes() {
        try {
            if (this.m_mtdGetSuppSM != null) {
                return (List) this.m_mtdGetSuppSM.invoke(this.m_oParams, null);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public List<String> getSupportedWhiteBalance() {
        try {
            if (this.m_mtdGetSuppWB != null) {
                return (List) this.m_mtdGetSuppWB.invoke(this.m_oParams, null);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public int getMinExposureCompensation() {
        try {
            if (this.m_mtdGetMinEC != null) {
                return ((Integer) this.m_mtdGetMinEC.invoke(this.m_oParams, null)).intValue();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return 0;
    }

    public int getMaxExposureCompensation() {
        try {
            if (this.m_mtdGetMaxEC != null) {
                return ((Integer) this.m_mtdGetMaxEC.invoke(this.m_oParams, null)).intValue();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return 0;
    }

    public List<Point> getSupportedPreviewSizes() {
        List<Object> cArSizes;
        Vector<Point> cArRes = new Vector<>();
        try {
            if (this.m_mtdGetSuppPrevSizes != null && (cArSizes = (List) this.m_mtdGetSuppPrevSizes.invoke(this.m_oParams, null)) != null) {
                for (int n = 0; n < cArSizes.size(); n++) {
                    Object szMode = cArSizes.get(n);
                    cArRes.add(new Point(InvokeHelper.GetFieldIntValue(szMode, "width"), InvokeHelper.GetFieldIntValue(szMode, "height")));
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return cArRes;
    }

    public List<Point> getSupportedPictureSizes() {
        List<Object> cArSizes;
        Vector<Point> cArRes = new Vector<>();
        try {
            if (this.m_mtdGetSuppPicSizes != null && (cArSizes = (List) this.m_mtdGetSuppPicSizes.invoke(this.m_oParams, null)) != null) {
                for (int n = 0; n < cArSizes.size(); n++) {
                    Object szMode = cArSizes.get(n);
                    cArRes.add(new Point(InvokeHelper.GetFieldIntValue(szMode, "width"), InvokeHelper.GetFieldIntValue(szMode, "height")));
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return cArRes;
    }

    public int getMaxNumDetectedFaces() {
        try {
            if (this.m_mtdGetMaxFaces != null) {
                return ((Integer) this.m_mtdGetMaxFaces.invoke(this.m_oParams, null)).intValue();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return 0;
    }

    public int getMaxNumFocusAreas() {
        try {
            if (this.m_mtdGetMaxFocuses != null) {
                return ((Integer) this.m_mtdGetMaxFocuses.invoke(this.m_oParams, null)).intValue();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return 0;
    }

    public int getMaxNumMeteringAreas() {
        try {
            if (this.m_mtdGetMaxAreas != null) {
                return ((Integer) this.m_mtdGetMaxAreas.invoke(this.m_oParams, null)).intValue();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return 0;
    }

    public void unflatten(String flattened) {
        try {
            if (this.m_mtdUnFlatten != null) {
                this.m_mtdUnFlatten.invoke(this.m_oParams, flattened);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public boolean getAutoExposureLock() {
        try {
            if (this.m_mtdGetAELock != null) {
                return ((Boolean) this.m_mtdGetAELock.invoke(this.m_oParams, null)).booleanValue();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public boolean isAutoExposureLockSupported() {
        try {
            if (this.m_mtdIsAELockSupp != null) {
                return ((Boolean) this.m_mtdIsAELockSupp.invoke(this.m_oParams, null)).booleanValue();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public void setAutoExposureLock(boolean toggle) {
        try {
            if (this.m_mtdSetAELock != null) {
                this.m_mtdSetAELock.invoke(this.m_oParams, Boolean.valueOf(toggle));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public boolean getAutoWhiteBalanceLock() {
        try {
            if (this.m_mtdGetWBLock != null) {
                return ((Boolean) this.m_mtdGetWBLock.invoke(this.m_oParams, null)).booleanValue();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public boolean isAutoWhiteBalanceLockSupported() {
        try {
            if (this.m_mtdIsWBLockSupp != null) {
                return ((Boolean) this.m_mtdIsWBLockSupp.invoke(this.m_oParams, null)).booleanValue();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public void setAutoWhiteBalanceLock(boolean toggle) {
        try {
            if (this.m_mtdSetWBLock != null) {
                this.m_mtdSetWBLock.invoke(this.m_oParams, Boolean.valueOf(toggle));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void setVideoStabilization(boolean toggle) {
        try {
            if (this.m_mtdSetVidStab != null) {
                this.m_mtdSetVidStab.invoke(this.m_oParams, Boolean.valueOf(toggle));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void setRecordingHint(boolean hint) {
        try {
            if (this.m_mtdSetRecHint != null) {
                this.m_mtdSetRecHint.invoke(this.m_oParams, Boolean.valueOf(hint));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void removeGpsData() {
        try {
            if (this.m_mtdRemoveGPS != null) {
                this.m_mtdRemoveGPS.invoke(this.m_oParams, null);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void remove(String key) {
        try {
            if (this.m_mtdRemove != null) {
                this.m_mtdRemove.invoke(this.m_oParams, key);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public boolean isZoomSupported() {
        try {
            if (this.m_mtdIsZoomSupp != null) {
                return ((Boolean) this.m_mtdIsZoomSupp.invoke(this.m_oParams, null)).booleanValue();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public boolean isVideoStabilizationSupported() {
        try {
            if (this.m_mtdIsVidStabSupp != null) {
                return ((Boolean) this.m_mtdIsVidStabSupp.invoke(this.m_oParams, null)).booleanValue();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public boolean isVideoSnapshotSupported() {
        try {
            if (this.m_mtdIsVidSnapSupp != null) {
                return ((Boolean) this.m_mtdIsVidSnapSupp.invoke(this.m_oParams, null)).booleanValue();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public Point getPreviewSize() {
        try {
            if (this.m_mtdGetPrevSize != null) {
                Object szSize = this.m_mtdGetPrevSize.invoke(this.m_oParams, null);
                return new Point(InvokeHelper.GetFieldIntValue(szSize, "width"), InvokeHelper.GetFieldIntValue(szSize, "height"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public List<Point> getSupportedVideoSizes() {
        List<Object> cArSizes;
        Vector<Point> cArRes = new Vector<>();
        try {
            if (this.m_mtdGetSuppVidSizes != null && (cArSizes = (List) this.m_mtdGetSuppVidSizes.invoke(this.m_oParams, null)) != null) {
                for (int n = 0; n < cArSizes.size(); n++) {
                    Object szMode = cArSizes.get(n);
                    cArRes.add(new Point(InvokeHelper.GetFieldIntValue(szMode, "width"), InvokeHelper.GetFieldIntValue(szMode, "height")));
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return cArRes;
    }

    public Point getPreferredPreviewSizeForVideo() {
        Object szSize;
        try {
            if (this.m_mtdGetPrefSize != null && (szSize = this.m_mtdGetPrefSize.invoke(this.m_oParams, null)) != null) {
                return new Point(InvokeHelper.GetFieldIntValue(szSize, "width"), InvokeHelper.GetFieldIntValue(szSize, "height"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public float getExposureCompensationStep() {
        try {
            if (this.m_mtdGetECStep != null) {
                return ((Float) this.m_mtdGetECStep.invoke(this.m_oParams, null)).floatValue();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return 0.0f;
    }

    public int getExposureCompensation() {
        try {
            if (this.m_mtdGetEC != null) {
                return ((Integer) this.m_mtdGetEC.invoke(this.m_oParams, null)).intValue();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return 0;
    }

    public void setFocusAreas(List<Rect> focusAreas) throws Exception {
        List<Object> cArList = null;
        if (focusAreas != null && focusAreas.size() > 0) {
            cArList = new Vector<>();
            for (Rect rcArea : focusAreas) {
                Object cCamArea = null;
                if (this.m_cClassSecCamArea != null) {
                    Log.e("lgCamera", "Using " + this.m_cClassSecCamArea.getName());
                    cCamArea = InvokeHelper.CreateCameraArea(this.m_cClassSecCamArea, rcArea, 1000);
                }
                if (cCamArea == null) {
                    Log.e("lgCamera", "Using android.hardware.Camera$Area");
                    cCamArea = InvokeHelper.CreateCameraArea("android.hardware.Camera$Area", rcArea, 1000);
                }
                if (cCamArea != null) {
                    cArList.add(cCamArea);
                }
            }
        }
        this.m_mtdSetFocusAreas.invoke(this.m_oParams, cArList);
    }
}