package rubberbigpepper.CommonCtrl;

import android.annotation.TargetApi;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.util.Log;
import com.android.camera.CameraView;
import java.util.ArrayList;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: DocumentFile.java */
@TargetApi(CameraView.PANORAMA_STARTED)
/* loaded from: classes.dex */
public class DocumentsContractApi21 {
    private static final String TAG = "DocumentFile";

    DocumentsContractApi21() {
    }

    public static Uri createFile(Context context, Uri self, String mimeType, String displayName) {
        return DocumentsContract.createDocument(context.getContentResolver(), self, mimeType, displayName);
    }

    public static Uri createDirectory(Context context, Uri self, String displayName) {
        return createFile(context, self, "vnd.android.document/directory", displayName);
    }

    public static Uri prepareTreeUri(Uri treeUri) {
        return DocumentsContract.buildDocumentUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri));
    }

    public static Uri[] listFiles(Context context, Uri self) {
        ContentResolver resolver = context.getContentResolver();
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(self, DocumentsContract.getDocumentId(self));
        ArrayList<Uri> results = new ArrayList<>();
        Cursor c = null;
        try {
            c = resolver.query(childrenUri, new String[]{"document_id"}, null, null, null);
            while (c.moveToNext()) {
                String documentId = c.getString(0);
                Uri documentUri = DocumentsContract.buildDocumentUriUsingTree(self, documentId);
                results.add(documentUri);
            }
        } catch (Exception e) {
            Log.w(TAG, "Failed query: " + e);
        } finally {
            closeQuietly(c);
        }
        return (Uri[]) results.toArray(new Uri[results.size()]);
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x004a, code lost:
        r10 = android.provider.DocumentsContract.buildDocumentUriUsingTree(r12, r7);
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static Uri findFile(Context context, Uri self, String strName) {
        ContentResolver resolver = context.getContentResolver();
        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(self, DocumentsContract.getDocumentId(self));
        Uri result = null;
        Cursor c = null;
        try {
            c = resolver.query(childrenUri, new String[]{"document_id", "_display_name"}, "_display_name=" + strName, null, null);
            while (true) {
                if (!c.moveToNext()) {
                    break;
                }
                String documentId = c.getString(0);
                String documentName = c.getString(1);
                if (documentName.equalsIgnoreCase(strName)) {
                    break;
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed query: " + e);
        } finally {
            closeQuietly(c);
        }
        return result;
    }

    public static Uri renameTo(Context context, Uri self, String displayName) {
        return DocumentsContract.renameDocument(context.getContentResolver(), self, displayName);
    }

    private static void closeQuietly(AutoCloseable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (RuntimeException rethrown) {
                throw rethrown;
            } catch (Exception e) {
            }
        }
    }
}