package rubberbigpepper.CommonCtrl;

import android.content.Context;
import android.util.Log;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Vector;

/* loaded from: classes.dex */
public class ScriptCompile {
    private Vector<String> m_strManufacturers = new Vector<>();
    private Vector<ManufacturerList> m_cArManufact = new Vector<>();

    /* loaded from: classes.dex */
    private class ManufacturerList {
        public Vector<ModelList> m_cArModels = new Vector<>();
        public String m_strName;

        public ManufacturerList(String strName) {
            this.m_strName = "";
            this.m_strName = strName;
        }

        public void AddModelList(ModelList cList) {
            if (GetModelListIndex(cList) == -1) {
                this.m_cArModels.add(cList);
            }
        }

        public int GetModelListIndex(ModelList cList) {
            for (int n = 0; n < this.m_cArModels.size(); n++) {
                ModelList cListExist = this.m_cArModels.get(n);
                if (cListExist.m_strModel.equalsIgnoreCase(cList.m_strModel)) {
                    return n;
                }
            }
            return -1;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public class ModelList {
        public String m_strLEDPath;
        public String m_strModel;
        public String m_strScript;

        public ModelList(String strModel, String strScript, String strLEDPath) {
            this.m_strModel = "";
            this.m_strScript = "";
            this.m_strLEDPath = "";
            this.m_strModel = strModel;
            this.m_strScript = strScript;
            this.m_strLEDPath = strLEDPath;
        }
    }

    /* JADX WARN: Incorrect condition in loop: B:4:0x001c */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private String[] ReadScript(Context cContext) {
        try {
            new ArrayList();
            InputStream cStream = cContext.getAssets().open("videorecordscript.txt");
            byte[] byArBuffer = new byte[65536];
            StringBuffer cStrBuf = new StringBuffer();
            while (nRead > 0) {
                cStrBuf.append((CharSequence) Charset.forName("Windows-1251").decode(ByteBuffer.wrap(byArBuffer)));
            }
            cStream.close();
            return cStrBuf.toString().split("\n");
        } catch (Exception e) {
            return null;
        }
    }

    public String[] MakeScript(Context cContext, String strManufacturer, String strModel) {
        String[] strArRows = ReadScript(cContext);
        int nIndex = 0;
        ManufacturerList cManList = null;
        ModelList cModelList = null;
        for (String strRow : strArRows) {
            String strOneRow = strRow.trim().toLowerCase();
            int nPos = strOneRow.indexOf(58);
            String strValue = "";
            if (nPos != -1) {
                strOneRow.substring(0, nPos).trim();
                strValue = strOneRow.substring(nPos + 1).trim();
            }
            switch (nIndex) {
                case 0:
                    int nManufIndex = this.m_strManufacturers.indexOf(strValue);
                    if (nManufIndex == -1) {
                        cManList = new ManufacturerList(strValue);
                        this.m_cArManufact.add(cManList);
                        this.m_strManufacturers.add(strOneRow);
                        break;
                    } else {
                        ManufacturerList cManList2 = this.m_cArManufact.get(nManufIndex);
                        cManList = cManList2;
                        break;
                    }
                case 1:
                    if (cManList != null) {
                        cModelList = new ModelList(strValue, "", "");
                        break;
                    } else {
                        break;
                    }
                case 2:
                    if (cManList != null && cModelList != null) {
                        cModelList.m_strScript = strOneRow;
                        cManList.AddModelList(cModelList);
                        break;
                    }
                    break;
                case 3:
                    if (cManList != null && cModelList != null) {
                        cModelList.m_strLEDPath = strOneRow;
                        cManList.AddModelList(cModelList);
                    }
                    if (strOneRow.length() == 0) {
                        nIndex = -1;
                        cManList = null;
                    }
                    cModelList = null;
                    break;
                default:
                    nIndex = -1;
                    cManList = null;
                    cModelList = null;
                    break;
            }
            nIndex++;
        }
        Log.e("VideoReg", "Script manufacturer " + strManufacturer + ", model " + strModel);
        ModelList cResModList = new ModelList(strModel, "", "");
        for (int n = 0; n < this.m_cArManufact.size(); n++) {
            ManufacturerList cManList3 = this.m_cArManufact.get(n);
            ManufacturerList cManList4 = cManList3;
            if (cManList4.m_strName.length() == 0) {
                for (int m = 0; m < cManList4.m_cArModels.size(); m++) {
                    ModelList cModelList2 = cManList4.m_cArModels.get(m);
                    ModelList cModelList3 = cModelList2;
                    if (cModelList3.m_strModel.length() == 0) {
                        Log.e("VideoReg", "Script apply null manufacturer, null model");
                        if (cResModList.m_strScript.length() == 0) {
                            cResModList.m_strScript = cModelList3.m_strScript;
                        } else {
                            cResModList.m_strScript = String.valueOf(cResModList.m_strScript) + ";" + cModelList3.m_strScript;
                        }
                        cResModList.m_strLEDPath = cModelList3.m_strLEDPath;
                    }
                }
                for (int m2 = 0; m2 < cManList4.m_cArModels.size(); m2++) {
                    ModelList cModelList4 = cManList4.m_cArModels.get(m2);
                    ModelList cModelList5 = cModelList4;
                    if (cModelList5.m_strModel.equalsIgnoreCase(strModel)) {
                        Log.e("VideoReg", "Script apply null manufacturer, model " + cModelList5.m_strModel);
                        if (cResModList.m_strScript.length() == 0) {
                            cResModList.m_strScript = cModelList5.m_strScript;
                        } else {
                            cResModList.m_strScript = String.valueOf(cResModList.m_strScript) + ";" + cModelList5.m_strScript;
                        }
                        cResModList.m_strLEDPath = cModelList5.m_strLEDPath;
                    }
                }
            }
        }
        for (int n2 = 0; n2 < this.m_cArManufact.size(); n2++) {
            ManufacturerList cManList5 = this.m_cArManufact.get(n2);
            ManufacturerList cManList6 = cManList5;
            if (cManList6.m_strName.equalsIgnoreCase(strManufacturer)) {
                for (int m3 = 0; m3 < cManList6.m_cArModels.size(); m3++) {
                    ModelList cModelList6 = cManList6.m_cArModels.get(m3);
                    ModelList cModelList7 = cModelList6;
                    if (cModelList7.m_strModel.length() == 0) {
                        Log.e("VideoReg", "Script apply manufacturer " + cManList6.m_strName + " null model");
                        if (cResModList.m_strScript.length() == 0) {
                            cResModList.m_strScript = cModelList7.m_strScript;
                        } else {
                            cResModList.m_strScript = String.valueOf(cResModList.m_strScript) + ";" + cModelList7.m_strScript;
                        }
                        cResModList.m_strLEDPath = cModelList7.m_strLEDPath;
                    }
                }
                for (int m4 = 0; m4 < cManList6.m_cArModels.size(); m4++) {
                    ModelList cModelList8 = cManList6.m_cArModels.get(m4);
                    ModelList cModelList9 = cModelList8;
                    if (cModelList9.m_strModel.equalsIgnoreCase(strModel)) {
                        Log.e("VideoReg", "Script apply manufacturer " + cManList6.m_strName + " model " + cModelList9.m_strModel);
                        if (cResModList.m_strScript.length() == 0) {
                            cResModList.m_strScript = cModelList9.m_strScript;
                        } else {
                            cResModList.m_strScript = String.valueOf(cResModList.m_strScript) + ";" + cModelList9.m_strScript;
                        }
                        cResModList.m_strLEDPath = cModelList9.m_strLEDPath;
                    }
                }
            }
        }
        String[] strArFields = cResModList.m_strScript.split(";");
        if (strArFields != null) {
            StringBuilder cBuilder = new StringBuilder();
            for (int n3 = strArFields.length - 1; n3 >= 0; n3--) {
                String strField = strArFields[n3];
                String[] strParam = strField.split("=");
                if (strParam != null && strParam.length == 2 && cBuilder.indexOf(String.valueOf(strParam[0]) + "=") < 0) {
                    cBuilder.insert(0, ";");
                    cBuilder.insert(0, strParam[1]);
                    cBuilder.insert(0, "=");
                    cBuilder.insert(0, strParam[0]);
                }
            }
            cResModList.m_strScript = cBuilder.toString();
        }
        cResModList.m_strScript = cResModList.m_strScript.replace(";;", ";");
        return new String[]{cResModList.m_strScript, cResModList.m_strLEDPath};
    }
}